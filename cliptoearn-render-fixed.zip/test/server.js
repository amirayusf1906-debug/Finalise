// ClipToEarn Render server
// Serves the existing frontend and mounts the existing API handlers on one Express Web Service.
const path = require('path');
const express = require('express');

const app = express();
const PORT = Number(process.env.PORT || 10000);
const ROOT = __dirname;

app.disable('x-powered-by');
app.set('trust proxy', 1);

// Security headers equivalent to the previous Vercel deployment.
app.use((req, res, next) => {
  res.setHeader('X-Content-Type-Options', 'nosniff');
  res.setHeader('X-Frame-Options', 'DENY');
  res.setHeader('Referrer-Policy', 'strict-origin-when-cross-origin');
  res.setHeader('Permissions-Policy', 'camera=(), microphone=(), geolocation=()');
  if (process.env.NODE_ENV === 'production') {
    res.setHeader('Strict-Transport-Security', 'max-age=63072000; includeSubDomains');
  }
  if (req.path.startsWith('/api/')) res.setHeader('Cache-Control', 'no-store');
  next();
});

// All current API handlers expect req.body to already be parsed.
app.use(express.json({ limit: '1mb' }));
app.use(express.urlencoded({ extended: false, limit: '1mb' }));

function mount(pathname, handler, queryFromParams = () => ({})) {
  app.all(pathname, async (req, res) => {
    req.query = { ...req.query, ...queryFromParams(req) };
    try {
      await handler(req, res);
    } catch (err) {
      console.error(`Unhandled API error ${req.method} ${req.originalUrl}:`, err);
      if (!res.headersSent) res.status(500).json({ success: false, error: 'Something went wrong. Please try again.' });
    }
  });
}

const auth = require('./api/auth/[action].js');
const campaignsIndex = require('./api/campaigns/index.js');
const campaignsId = require('./api/campaigns/[id].js');
const submissions = require('./api/submissions/index.js');
const submissionsApprove = require('./api/submissions/approve.js');
const socials = require('./api/socials.js');
const socialsAction = require('./api/socials/[action]/[platform].js');
const payments = require('./api/payments/[action].js');
const withdrawals = require('./api/withdrawals/index.js');
const withdrawalId = require('./api/withdrawals/[id].js');
const profile = require('./api/profile.js');
const analytics = require('./api/analytics.js');
const notifications = require('./api/notifications.js');
const support = require('./api/support.js');
const weekly = require('./api/reports/weekly.js');

mount('/api/auth/:action', auth, req => ({ action: req.params.action }));
mount('/api/campaigns', campaignsIndex);
mount('/api/campaigns/:id', campaignsId, req => ({ id: req.params.id }));
mount('/api/submissions', submissions);
mount('/api/submissions/approve', submissionsApprove);
mount('/api/socials', socials);
mount('/api/socials/:action/:platform', socialsAction, req => ({ action: req.params.action, platform: req.params.platform }));
mount('/api/payments/:action', payments, req => ({ action: req.params.action }));
mount('/api/withdrawals', withdrawals);
mount('/api/withdrawals/:id', withdrawalId, req => ({ id: req.params.id }));
mount('/api/profile', profile);
mount('/api/analytics', analytics);
mount('/api/notifications', notifications);
mount('/api/support', support);
mount('/api/reports/weekly', weekly);

app.get('/health', (req, res) => res.json({ status: 'ok', service: 'ClipToEarn', runtime: 'render-node' }));

// Static frontend. Existing relative links such as campaign.html and dashboard.html continue to work.
app.use(express.static(ROOT, {
  index: 'index.html',
  extensions: ['html'],
  setHeaders(res, filePath) {
    if (filePath.endsWith('.html')) res.setHeader('Cache-Control', 'no-cache');
  },
}));

// Render's service root should always have a simple response even if static middleware changes later.
app.get('/', (req, res) => res.sendFile(path.join(ROOT, 'index.html')));

app.use((req, res) => {
  if (req.path.startsWith('/api/')) return res.status(404).json({ success: false, error: 'Not found' });
  return res.status(404).sendFile(path.join(ROOT, 'index.html'));
});

app.listen(PORT, '0.0.0.0', () => {
  console.log(`ClipToEarn Render server listening on 0.0.0.0:${PORT}`);
});
