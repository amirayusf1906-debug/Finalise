# ClipToEarn consolidated build

This build is based on the previous personalized-campaign + notification build and adds the agreed changes.

## Included
- TikTok verification profile proof: username, display name, followers, following, likes, video count, profile link and refresh timestamps.
- Personalized campaign recommendations and creator-targeted campaign notifications.
- In-app notifications with weekly reports and view milestone notifications.
- Daily TikTok submission view snapshots and 7/30-day views analytics.
- View-based creator streak/milestones. The streak is based on cumulative views, NOT consecutive days, and does not automatically pay cash.
- Approval/payment separation: approval reserves the reward and moves it to pending creator earnings; a separate admin payment action moves it to available balance and writes the final reward ledger row.
- Brand wallet deposits through NOWPayments hosted checkout. Provider confirmation is required before the wallet is credited.
- Brand campaign funding can use a confirmed ClipToEarn brand wallet balance; if the wallet is insufficient, the existing NOWPayments campaign invoice flow remains available.
- Duplicate webhook/payment protections remain in place.

## Important deployment notes
1. Keep `CRON_SECRET` configured. It protects TikTok refresh and weekly report cron routes.
2. Keep the existing NOWPayments API/IPN environment variables configured.
3. Run `npm run sync-indexes` after deployment.
4. Test payment webhooks in staging before using real funds.
5. Existing creator records will have `pendingEarnings: 0` and existing paid earnings remain in `balance`/`totalEarned`.
6. Existing brand records will have `brandBalance: 0`; direct campaign payments remain supported.

## NOWPayments bank/fiat note
The brand wallet uses the NOWPayments hosted checkout. Which bank/fiat payment methods are offered to a payer depends on the payment methods available to the NOWPayments checkout/account/region. ClipToEarn credits the wallet only after the verified NOWPayments callback.
