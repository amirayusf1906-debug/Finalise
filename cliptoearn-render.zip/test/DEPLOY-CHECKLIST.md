# ClipToEarn: before going live

## One-time setup
1. In Vercel > Project Settings > Environment Variables (Production), set:
   `MONGO_URI`, `JWT_SECRET` (32+ random characters), `APP_BASE_URL` (your https:// domain, no trailing slash),
   `SCRAPECREATORS_API_KEY`, `CRON_SECRET`, `GMAIL_USER` + `GMAIL_APP_PASSWORD` (testing) or `RESEND_API_KEY` + `EMAIL_FROM` (own domain; production). Never commit a real `.env`.
2. TikTok accounts are verified by a code in the creator's bio and videos are checked, both with ScrapeCreators. No TikTok developer app or OAuth redirect is needed.
3. With `MONGO_URI` set on your machine, run `npm install` then `npm run sync-indexes`.
   This builds the unique indexes (one join per creator + campaign, one creator per TikTok account,
   one submission per video) and copies existing campaign participants into the new membership collection.
   If it prints FAILED for an index, duplicate rows exist: remove them and run it again.
4. Add `CRON_SECRET` (long random string) in Vercel env vars and redeploy: this lets the twice-daily job refresh TikTok follower and view counts.
5. Payments: follow `PAYMENTS-SETUP.md` (NOWPayments keys, webhooks, `npm run sync-indexes`). Test in sandbox first.
6. Create your admin account: register normally, then in MongoDB set that user's `role` to `admin`.
   Admin accounts cannot join campaigns, submit clips or withdraw.

## Checks after deploying
- Site loads over https:// only, and the login cookie has `Secure` (browser dev tools > Application > Cookies).
- A creator visiting `/admin.html` is sent back to the dashboard; an admin visiting `/dashboard.html` is sent to admin.
- Verify TikTok through the bio code, join a campaign, submit a video from that same account (works, also via a vt.tiktok.com link); submit someone else's link (rejected); submit the same video again by another link form (rejected as duplicate).

## Still not built (needs outside services)
- Automated PayPal payouts (PayPal Payouts API; needs PayPal approval).
- Views are refreshed twice a day through ScrapeCreators (uses credits). An admin still enters the view count when approving.
- PayPal payouts are still paid manually and marked paid in the admin page (crypto is automated through NOWPayments).
- Privacy policy and terms of service pages (TikTok requires them for app review).

## Vercel free (Hobby) plan: 12 serverless functions maximum
Every `.js` file inside `api/` counts as one function, and this project uses 12 (the limit). Related routes are
served by one file through a dispatcher (for example `api/auth/[action].js` handles login, register,
logout, password and username), and their code lives in `lib/handlers/`. Do not add new files under
`api/` without merging something first, or the deploy will fail with "No more than 12 Serverless Functions".


## After the fee update
- [ ] `npm run sync-indexes` (new models: CampaignMember, SupportTicket, OAuthState, RateLimit; new fields on Payment and Withdrawal)
- [ ] Sandbox test: fund a $1,000 campaign (invoice must be $1,100, campaign funded $1,000), approve a clip, withdraw $50 (balance -$50, payout $49, ledger -$49 and -$1), then `npm run reconcile`
- [ ] Vercel function count is 12 of 12 on the free plan: do not add another file under `api/`

## Plan note
Vercel Hobby is for non-commercial use and limits crons to once per day. A site that holds balances and pays out should run on Vercel Pro.

## Email checks
- [ ] `npm run sync-indexes` (new EmailToken collection)
- [ ] Register: a confirmation email arrives; the banner disappears after clicking the link; withdrawing before confirming is refused
- [ ] Forgot password: reset link works once, expires after 1 hour, and signs out other sessions
- [ ] Existing accounts start unverified: they see the banner and must confirm before withdrawing or funding
