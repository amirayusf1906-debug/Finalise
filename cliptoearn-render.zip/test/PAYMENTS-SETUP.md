# Payments setup (NOWPayments)

## The money rule the code enforces
Brand pays -> NOWPayments confirms by signed webhook -> campaign `fundedAmount` increases -> campaign can go Active ->
creator joins -> submission approved -> reward credited **only if it fits inside the funded money that is left** ->
creator withdraws -> payout. A reward can never be paid from money that was not received.

## Fees (all calculated in `lib/fees.js`, the only place that knows the percentages)
- **Campaign:** brand pays budget + 10% platform fee (budget $1,000 -> fee $100 -> pays $1,100). Only the $1,000 is credited to the campaign (`fundedAmount`). The Payment record stores `creatorBudget`, `platformFee` and `amount` (the total). The fee is not refunded if the campaign is cancelled.
- **Withdrawal:** 2% fee, minimum withdrawal $10, maximum fee $10 ($50 -> fee $1 -> creator receives $49). The full $50 leaves the balance. The Withdrawal record stores `amount` (gross), `feeAmount`, `netAmount`. The ledger gets a `withdrawal` row (-$49) and a `withdrawal_fee` row (-$1). NOWPayments and manual PayPal payouts send the NET amount. A failed payout returns the gross amount.
- `js/dashboard-ui.js` (withdrawal preview) and `js/brand.js` (campaign preview) read the percentages from `/api/profile` (`user.fees`, built from `lib/fees.js`), so changing `lib/fees.js` is enough. The browser values are display only; the server always calculates the real fee.
- Admin-created campaigns are funded by the platform for their full budget (a `campaign_funding` ledger row with `platformFunded: true`), so creators can see and join them.
- Payments run with a 30 second limit (`vercel.json`). A crypto payout that was requested but never answered (no batch id after 5 minutes) can be failed or completed by hand from Admin > Withdrawals, after checking the NOWPayments dashboard.

## 1. Environment variables (Vercel > Settings > Environment Variables, then redeploy)
`NOWPAYMENTS_ENV` (`sandbox` first), `NOWPAYMENTS_API_KEY`, `NOWPAYMENTS_IPN_SECRET`, `NOWPAYMENTS_EMAIL`,
`NOWPAYMENTS_PASSWORD`, `APP_BASE_URL`, `JWT_SECRET`, `MONGO_URI`, `CRON_SECRET`.
Use a **sandbox** account/keys for testing (api-sandbox.nowpayments.io). Keys are only read in `lib/nowpayments.js`.

## 2. NOWPayments dashboard
- Generate the API key and the **IPN secret** (Store settings).
- Webhook URLs are sent per request by the app:
  brand payments -> `APP_BASE_URL/api/payments/webhook`, payouts -> `APP_BASE_URL/api/payments/payout-webhook`.
- Payout account: set your outcome wallet, and complete 2FA (payouts need a 2FA code, see below).
- **IP whitelisting:** NOWPayments asks you to whitelist the server IP that calls the payout API. Vercel does not give
  your functions a fixed outbound IP on the free plan. Options: Vercel's static-IP feature (paid plans), or run the
  payout calls (`lib/nowpayments.js` payout functions) from a small server with a fixed IP. Keep that decision outside
  the application code, as required. Brand payments (invoices) do not need whitelisting.

## 3. Database
`npm run sync-indexes` (adds the Payment model and the unique indexes that stop duplicate credits).
`npm run reconcile` any time: compares every creator balance and campaign spend with the ledger.

## 4. How payouts really work
- **Crypto:** the creator requests a withdrawal (money is deducted and recorded immediately). In **Admin > Payments &
  payouts > Crypto payouts** an admin presses *Send payout*; the server validates the address with NOWPayments, converts USD
  to the coin, and creates the payout. NOWPayments then requires a **2FA code** (email or authenticator): the admin
  types it in and presses *Confirm with 2FA*. This step cannot be automated safely. NOWPayments reports the result by webhook
  (or press *Check status*). Failed payout = the amount is returned to the creator with a ledger row.
- **PayPal:** NOWPayments cannot pay PayPal. PayPal withdrawals are paid by an admin from your PayPal account, then marked
  paid in Admin > Withdrawals. (Automating this needs the PayPal Payouts API, a separate integration.)
- Verify the currency codes in `lib/crypto.js` against `GET /v1/merchant/coins` for your account before going live.

## 5. Things that are decided by people, on purpose
- Refunds to brands are not automatic: cancelling records the unused amount as owed; an admin sends it and records the reference.
- Reward reversals are not automatic: the refresh job flags approved videos that disappeared; an admin decides.
- Campaigns that existed before this update have no funding and are hidden from creators until a brand/admin funds them.

## 6. Test checklist (sandbox, before live)
1. Brand pays an invoice -> webhook -> campaign Funded -> Go live.   2. Brand abandons/expired payment -> Funding Failed.
3. Same webhook sent twice -> campaign funded once (check Ledger).   4. Creator approved -> +reward, remaining budget drops.
5. Two admins approve at once -> only funded money is spent.          6. Withdrawal PayPal and crypto.
7. Withdrawal double-click -> one withdrawal.                         8. Failed payout -> balance restored.
9. Cancel campaign -> refund owed -> record refund.                   10. Reverse a reward -> separate ledger row.
