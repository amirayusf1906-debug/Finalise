# ClipToEarn — Render version

This build runs ClipToEarn as one normal Node/Express Web Service on Render. It keeps the existing frontend, MongoDB models, authentication, campaign, submission, TikTok, payment, withdrawal, notification and analytics code, but removes the Vercel Serverless Function deployment requirement.

## Render Web Service

- Runtime: Node
- Build command: `npm install`
- Start command: `npm start`
- Health check: `/health`
- Root: the existing `index.html`

The API remains under the same browser paths, for example:

- `/api/auth/login`
- `/api/campaigns`
- `/api/submissions`
- `/api/socials`
- `/api/analytics`
- `/api/notifications`
- `/api/payments/...`
- `/api/withdrawals`

## Required environment variables

Copy the variables from `.env.example` into Render Environment Variables. At minimum, production needs:

- `NODE_ENV=production`
- `MONGO_URI`
- `JWT_SECRET` (32+ random characters)
- `APP_BASE_URL=https://YOUR-RENDER-DOMAIN.onrender.com`
- `SCRAPECREATORS_API_KEY`
- `CRON_SECRET`
- NOWPayments variables when payments are enabled
- Email variables when email verification/password reset is enabled

Keep all provider secrets server-side. Do not put them in frontend JavaScript.

## NOWPayments

Use the Render URL in the NOWPayments IPN/webhook configuration. The application only credits a campaign or brand wallet after the provider webhook is verified and the payment is checked with NOWPayments. Returning from the hosted checkout page alone does not credit money.

For the first deployment use `NOWPAYMENTS_ENV=sandbox`. Switch to `live` only after the payment checklist passes.

## Scheduled jobs

The project still contains the protected handlers for:

- TikTok profile/video refresh: `GET /api/socials/refresh/all`
- Weekly reports: `GET /api/reports/weekly`

Both require `Authorization: Bearer $CRON_SECRET`.

`vercel.json` has been removed. Configure Render Cron Jobs (or another trusted scheduler) to call those endpoints with the `CRON_SECRET` header. Do not expose either endpoint without that secret.

## Existing separate TikTok API

The existing `https://cliptoearn-tiktok-api.onrender.com/` service can remain separate. This build does not replace it, reducing migration risk.

## Campaign frontend additions

Brand campaign creation now has:

- Campaign brief
- Optional campaign materials URL (Google Drive, Dropbox, website, etc.)
- Natural campaign instructions

Creator campaign details now show those fields, and video submission is presented as a published TikTok video link. Badges remain profile-only.
