# ClipToEarn consolidated feature test checklist

This build combines personalized campaigns/notifications, TikTok profile proof, view analytics, view milestones, weekly reports, brand wallet deposits, and separate approval/payment states.

## 1. TikTok verification + profile proof
- [ ] Enter a real TikTok username/profile URL and confirm the profile is found.
- [ ] Confirm the verification screen shows the username and generated code.
- [ ] Put the code in the TikTok bio and verify.
- [ ] After verification, confirm username, profile name, followers, following, likes, video count, private/verified state and profile link appear.
- [ ] Confirm the stats match the Render TikTok API response.
- [ ] Refresh the page and confirm the stats remain visible.
- [ ] Run the scheduled social refresh and confirm stats update.
- [ ] Verify a second ClipToEarn account cannot claim the same verified TikTok account.
- [ ] If Render/TikTok is temporarily unavailable, confirm the account stays verified and old stats are not erased.

## 2. Personalized campaigns
- [ ] Create a funded campaign targeting a minimum follower count.
- [ ] Confirm an eligible verified creator sees it in “Recommended for you”.
- [ ] Confirm an ineligible creator does not see it as recommended.
- [ ] Confirm the match score/reasons are based only on available account data.
- [ ] Activate a new matching campaign and confirm only eligible creators receive a campaign-match notification.
- [ ] Run the campaign notification trigger twice and confirm the same creator does not receive duplicate campaign notifications.

## 3. Creator view analytics
- [ ] Submit a TikTok video with a known starting view count.
- [ ] Confirm a daily view snapshot is created.
- [ ] Run the social refresh endpoint with the cron secret.
- [ ] Confirm the submission view count changes when TikTok views change.
- [ ] Confirm the same submission/date does not create duplicate snapshots.
- [ ] Confirm `/api/analytics?days=7` returns seven chart points.
- [ ] Confirm the chart shows views gained by day, not the lifetime total repeated each day.
- [ ] Confirm current total views, approved clips and paid earnings are correct.

## 4. View milestone streak
- [ ] Confirm lifetime views across ClipToEarn-submitted clips determine the milestone level.
- [ ] Reach a test milestone such as 1,000 views.
- [ ] Confirm the creator sees the milestone/streak level and progress to the next milestone.
- [ ] Confirm a milestone notification is created.
- [ ] Run the refresh again without crossing a new milestone and confirm no duplicate milestone notification.
- [ ] Cross the next milestone and confirm a new milestone notification is created.
- [ ] Confirm streak rewards are badges/levels/recognition only, not automatic cash.

## 5. Weekly report notification
- [ ] Run `/api/reports/weekly` with the cron secret in staging.
- [ ] Confirm one weekly report notification is created for an active creator.
- [ ] Run it again and confirm no duplicate notification is created.
- [ ] Confirm the report contains views gained, approved clips, pending clips and paid earnings.
- [ ] Confirm it appears in the notification center.
- [ ] Mark it read and confirm the unread count decreases.
- [ ] Mark all read and confirm the unread count clears.

## 6. Approval vs payment separation
- [ ] Submit a clip and approve it as admin.
- [ ] Confirm submission status becomes `approved`.
- [ ] Confirm payment status becomes `pending`.
- [ ] Confirm the creator's available balance does NOT increase at approval.
- [ ] Confirm the creator's pending payment balance increases by the approved amount.
- [ ] Confirm the campaign budget is reserved once, so another approval cannot spend the same budget.
- [ ] Open Admin → Payments → Creator payments.
- [ ] Mark the approved payment as paid.
- [ ] Confirm payment status becomes `paid`.
- [ ] Confirm pending payment decreases and available balance increases.
- [ ] Confirm exactly one `campaign_reward` ledger row exists.
- [ ] Confirm a duplicate pay request is rejected and cannot credit twice.
- [ ] Confirm the creator sees separate “Approved” and “Paid/Payment Pending” states.

## 7. Brand wallet + NOWPayments
- [ ] Open Brand dashboard and confirm wallet balance is separate from creator balances.
- [ ] Start a deposit of at least $20.
- [ ] Confirm the hosted NOWPayments checkout opens.
- [ ] Return without paying and confirm the brand balance is unchanged.
- [ ] Complete a test payment and wait for the verified NOWPayments webhook.
- [ ] Confirm the brand wallet increases only after the verified provider confirmation.
- [ ] Confirm duplicate webhooks do not credit the wallet twice.
- [ ] Fund a campaign using the wallet balance.
- [ ] Confirm wallet balance decreases by budget + platform fee.
- [ ] Confirm only the creator budget is recorded as campaign funded money.
- [ ] If the wallet is insufficient, confirm the existing NOWPayments campaign-funding checkout still works.

## 8. Withdrawals
- [ ] Confirm withdrawals can only use available balance, not pending creator payments.
- [ ] Confirm insufficient available balance is rejected.
- [ ] Confirm duplicate withdrawal requests cannot create two withdrawals.
- [ ] Confirm failed withdrawals return held funds correctly.
- [ ] Confirm successful crypto payouts update only after provider confirmation.

## 9. Regression tests
- [ ] Login/logout still works.
- [ ] TikTok bio verification still works.
- [ ] Campaign joining still works.
- [ ] Clip submission still enforces connected-account ownership.
- [ ] Rejection reasons still reach creators.
- [ ] Brand campaign creation/editing still works.
- [ ] Campaign funding/refunds still work.
- [ ] Admin campaign/submission pages still work.
- [ ] Admin ledger/reconcile still works.
- [ ] Run `npm run sync-indexes` after deployment.
