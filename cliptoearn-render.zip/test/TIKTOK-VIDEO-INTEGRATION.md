# TikTok video verification

Submissions are checked server-side with ScrapeCreators (`lib/tiktokVideo.js`) before a submission is created.
The response is read from `aweme_detail` (author `unique_id`, `aweme_id`, `statistics.play_count`...).
Ownership is checked against the creator's verified TikTok handle. Short `vt.`/`vm.tiktok.com` links are accepted.

- The stored link and the duplicate hash come from the provider's video id, so the same video can never be paid twice through different link forms.
- The twice-daily refresh job uses the same lookup.
- `SCRAPECREATORS_API_KEY` must be set in Vercel (server-side only).
