const connectDB = require('../lib/db');
const Submission = require('../models/Submission');
const ViewSnapshot = require('../models/ViewSnapshot');
const Transaction = require('../models/Transaction');
const { ok, fail, methodNotAllowed } = require('../lib/response');
const { requireAuth } = require('../lib/auth');

function dayKey(d) { return new Date(d).toISOString().slice(0, 10); }
function addDays(date, amount) { const d = new Date(date); d.setUTCDate(d.getUTCDate() + amount); return d; }
function startOfDay(d) { const x = new Date(d); x.setUTCHours(0, 0, 0, 0); return x; }

async function handler(req, res) {
  if (req.method !== 'GET') return methodNotAllowed(res, ['GET']);
  await connectDB();

  const days = Math.min(30, Math.max(7, Number(req.query.days) || 7));
  const end = startOfDay(new Date());
  const start = addDays(end, -(days - 1));
  const previous = addDays(start, -1);

  const [snapshots, submissions, earnings, lifetime] = await Promise.all([
    ViewSnapshot.find({ creator: req.user.id, dateKey: { $gte: dayKey(previous), $lte: dayKey(end) } }).sort({ dateKey: 1 }).lean(),
    Submission.find({ creator: req.user.id }).select('status views createdAt').lean(),
    Transaction.find({ user: req.user.id, type: { $in: ['earning', 'campaign_reward'] }, amount: { $gt: 0 }, createdAt: { $gte: start } }).select('amount createdAt').lean(),
    Submission.aggregate([{ $match: { creator: req.user.id } }, { $group: { _id: null, total: { $sum: '$views' } } }]),
  ]);

  const byDay = new Map();
  for (const s of snapshots) byDay.set(s.dateKey, (byDay.get(s.dateKey) || 0) + Number(s.views || 0));

  let previousTotal = byDay.get(dayKey(previous)) || 0;
  const chart = [];
  for (let i = 0; i < days; i += 1) {
    const date = addDays(start, i);
    const key = dayKey(date);
    const total = byDay.has(key) ? byDay.get(key) : previousTotal;
    const gained = Math.max(0, total - previousTotal);
    chart.push({ date: key, totalViews: total, viewsGained: gained });
    previousTotal = total;
  }

  const approved = submissions.filter((s) => s.status === 'approved');
  const pending = submissions.filter((s) => s.status === 'pending');
  const views = chart.reduce((sum, d) => sum + d.viewsGained, 0);
  const earned = earnings.reduce((sum, t) => sum + Number(t.amount || 0), 0);
  const lifetimeViews = Number(lifetime[0]?.total || 0);
  const milestones = [1000, 5000, 10000, 25000, 50000, 100000, 250000, 500000, 1000000, 2500000, 5000000, 10000000];
  let level = 0, nextMilestone = milestones[0];
  for (let i = 0; i < milestones.length; i += 1) { if (lifetimeViews >= milestones[i]) level = i + 1; else { nextMilestone = milestones[i]; break; } if (i === milestones.length - 1) nextMilestone = milestones[i]; }
  const previousMilestone = level > 0 ? milestones[level - 1] : 0;
  const progress = nextMilestone > previousMilestone ? Math.min(100, Math.round(((lifetimeViews - previousMilestone) / (nextMilestone - previousMilestone)) * 100)) : 100;

  return ok(res, {
    period: { start: dayKey(start), end: dayKey(end), days },
    summary: { views, currentTotalViews: previousTotal, approvedClips: approved.length, pendingClips: pending.length, earned },
    streak: { level, lifetimeViews, previousMilestone, nextMilestone, progress },
    chart,
  });
}

module.exports = (req, res) => requireAuth(handler)(req, res);
