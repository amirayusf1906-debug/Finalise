// api/auth/[action].js - ONE serverless function for the whole sign-in family (Vercel's free plan allows 12 functions).
//   POST /api/auth/login     {identifier, password}   POST /api/auth/register  (lib/handlers/register.js)
//   POST /api/auth/logout                             GET  /api/auth/username?username=
//   POST /api/auth/password  {currentPassword, newPassword}  (signed in)
//   POST /api/auth/forgot | reset | verify | resend-verification   (lib/handlers/emailAuth.js)
const bcrypt = require('bcryptjs');
const connectDB = require('../../lib/db');
const User = require('../../models/User');
const { ok, fail, methodNotAllowed } = require('../../lib/response');
const { requireAuth, signToken, setAuthCookie, clearAuthCookie } = require('../../lib/auth');
const { allow, clientIp } = require('../../lib/rateLimit');
const { isUsername, isStrongEnoughPassword } = require('../../lib/validation');
const register = require('../../lib/handlers/register');
const emailAuth = require('../../lib/handlers/emailAuth');

// A real hash to compare against when the account does not exist, so response time does not reveal which accounts exist.
const DUMMY_HASH = '$2a$10$CwTycUXWue0Thq9StjUM0uJ8.XQ3Z0vZc3Qm0lH2mVQY3m8oQe1Gy';

const publicUser = (u) => ({ id: u._id, username: u.username, email: u.email, displayName: u.displayName, role: u.role, balance: u.balance, emailVerified: !!u.emailVerified });

async function login(req, res) {
  if (req.method !== 'POST') return methodNotAllowed(res, ['POST']);
  try {
    await connectDB();
    const { identifier, password } = req.body || {};
    if (typeof identifier !== 'string' || typeof password !== 'string' || !identifier.trim() || !password) {
      return fail(res, 'Enter your username or email and your password.');
    }
    const id = identifier.trim().toLowerCase().slice(0, 254);
    if (!(await allow(req, res, { name: 'login-ip', id: clientIp(req), max: 30, windowSec: 900, message: 'Too many login attempts. Try again in a few minutes.' }))) return undefined;
    if (!(await allow(req, res, { name: 'login-id', id: `${id}|${clientIp(req)}`, max: 10, windowSec: 900, message: 'Too many login attempts for this account. Try again in a few minutes.' }))) return undefined;

    const user = await User.findOne({ $or: [{ username: id }, { email: id }] });
    const good = await bcrypt.compare(password.slice(0, 200), user ? user.passwordHash : DUMMY_HASH);
    if (!user || !good) return fail(res, 'Wrong username/email or password.', 401);
    if (user.status === 'suspended') return fail(res, 'This account has been suspended. Contact support.', 403);

    setAuthCookie(res, signToken({ id: user._id, username: user.username, role: user.role }));
    return ok(res, { user: publicUser(user) });
  } catch (err) {
    console.error('Login error:', err);
    return fail(res, 'Login failed. Please try again.', 500);
  }
}

async function logout(req, res) {
  if (req.method !== 'POST') return methodNotAllowed(res, ['POST']);
  clearAuthCookie(res);
  return ok(res, {});
}

async function username(req, res) {
  if (req.method !== 'GET') return methodNotAllowed(res, ['GET']);
  try {
    await connectDB();
    const name = String(req.query.username || '').trim();
    if (!(await allow(req, res, { name: 'username-check', id: clientIp(req), max: 60, windowSec: 600 }))) return undefined;
    if (!isUsername(name)) return ok(res, { available: false });
    const taken = await User.exists({ username: name.toLowerCase() });
    return ok(res, { available: !taken });
  } catch (err) {
    console.error('Username check error:', err);
    return fail(res, 'Could not check the username.', 500);
  }
}

// Changing the password signs out every other session (passwordChangedAt); this session gets a fresh cookie.
async function password(req, res) {
  if (req.method !== 'POST') return methodNotAllowed(res, ['POST']);
  return requireAuth(async (rq, rs) => {
    await connectDB();
    const { currentPassword, newPassword } = rq.body || {};
    if (typeof currentPassword !== 'string' || !currentPassword) return fail(rs, 'Enter your current password.');
    if (!isStrongEnoughPassword(newPassword)) return fail(rs, 'The new password must be 8 to 72 characters.');
    if (!(await allow(rq, rs, { name: 'password-change', id: rq.user.id, max: 8, windowSec: 3600, message: 'Too many attempts. Try again later.' }))) return undefined;
    const user = await User.findById(rq.user.id);
    if (!user || !(await bcrypt.compare(currentPassword.slice(0, 200), user.passwordHash))) return fail(rs, 'Your current password is not correct.', 400);
    if (currentPassword === newPassword) return fail(rs, 'Choose a password different from the current one.');
    user.passwordHash = await bcrypt.hash(newPassword, 10);
    user.passwordChangedAt = new Date();
    await user.save();
    setAuthCookie(rs, signToken({ id: user._id, username: user.username, role: user.role }));
    return ok(rs, {});
  })(req, res);
}

const handlers = { login, register, logout, username, password, forgot: emailAuth.forgot, reset: emailAuth.reset, verify: emailAuth.verify, 'resend-verification': emailAuth.resend };

module.exports = (req, res) => {
  const h = Object.prototype.hasOwnProperty.call(handlers, req.query.action) ? handlers[req.query.action] : null;
  if (!h) return fail(res, 'Not found', 404);
  return h(req, res);
};
