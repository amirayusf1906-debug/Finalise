// api/campaigns/[id].js
// GET   -> campaign detail (signed-in users; drafts are admin-only)
// PATCH -> update campaign (admin only)
const connectDB = require('../../lib/db');
const Campaign = require('../../models/Campaign');
const { ok, fail, methodNotAllowed, dollars } = require('../../lib/response');
const { requireAuth, requireAdmin } = require('../../lib/auth');
const { isObjectId, validateCampaignInput } = require('../../lib/validation');
const { serializeCampaign } = require('../../lib/campaigns');
const joinCampaign = require('../../lib/handlers/campaignJoin');
const brandCampaigns = require('../../lib/handlers/campaignBrand');

async function getCampaign(req, res) {
  await connectDB();
  const { id } = req.query;
  if (!isObjectId(id)) return fail(res, 'Campaign not found', 404);
  const campaign = await Campaign.findById(id).lean();
  const isOwnerBrand = req.user.role === 'brand' && String(campaign && campaign.brand) === req.user.id;
  const visible = campaign && (req.user.role === 'admin' || isOwnerBrand || (campaign.status !== 'draft' && campaign.fundingStatus === 'funded'));
  if (!visible) return fail(res, 'Campaign not found', 404);
  return ok(res, { campaign: serializeCampaign(campaign, req.user.id) });
}

async function updateCampaign(req, res) {
  await connectDB();
  const { id } = req.query;
  if (!isObjectId(id)) return fail(res, 'Campaign not found', 404);

  const { errors, value } = validateCampaignInput(req.body, { partial: true });
  if (errors.length) return fail(res, errors[0], 400, { errors });
  if (!Object.keys(value).length) return fail(res, 'Nothing to update');

  const current = await Campaign.findById(id).lean();
  if (!current) return fail(res, 'Campaign not found', 404);

  if (current.status === 'completed') {
    return fail(res, 'A completed campaign cannot be changed. Create a new campaign instead.');
  }
  // Once a payment exists, the money terms are frozen: they are what the brand actually paid for.
  if (['pending', 'funded', 'refund_owed', 'refunded'].includes(current.fundingStatus) && (value.budgetTotal !== undefined || value.payoutPerThousandViews !== undefined)) {
    return fail(res, 'The budget and rewards of a campaign cannot be changed after funding has started.');
  }
  const rate = value.payoutPerThousandViews ?? current.payoutPerThousandViews;
  const budget = value.budgetTotal ?? current.budgetTotal;
  if (rate > budget) return fail(res, 'Payout per 1,000 views cannot exceed the total budget.');
  if (value.budgetTotal !== undefined && value.budgetTotal < current.budgetSpent) {
    return fail(res, `Total budget cannot be lower than the ${dollars(current.budgetSpent)} already paid out.`);
  }
  // Creators join expecting the advertised rate: it can go up, never down, once someone has joined.
  if (
    value.payoutPerThousandViews !== undefined &&
    value.payoutPerThousandViews < current.payoutPerThousandViews &&
    (current.participants || []).length > 0
  ) {
    return fail(res, 'The payout rate cannot be lowered after creators have joined.');
  }

  // The budget floor is re-checked inside the update, so a payout approved a moment ago cannot slip under it.
  const filter = { _id: id };
  if (value.budgetTotal !== undefined) filter.budgetSpent = { $lte: value.budgetTotal };
  const campaign = await Campaign.findOneAndUpdate(filter, { $set: value }, { new: true, runValidators: true }).lean();
  if (!campaign) return fail(res, 'This campaign changed while you were saving. Reload and try again.', 409);
  return ok(res, { campaign: serializeCampaign(campaign, req.user.id) });
}

module.exports = async (req, res) => {
  if (req.query.id === 'join') return joinCampaign(req, res); // POST /api/campaigns/join
  if (req.method === 'GET') return requireAuth(getCampaign)(req, res);
  if (req.method === 'PATCH') {
    return requireAuth((rq, rs) => (rq.user.role === 'brand' ? brandCampaigns.update(rq, rs) : rq.user.role === 'admin' ? updateCampaign(rq, rs) : fail(rs, 'Admin or brand access required', 403)))(req, res);
  }
  return methodNotAllowed(res, ['GET', 'PATCH']);
};
