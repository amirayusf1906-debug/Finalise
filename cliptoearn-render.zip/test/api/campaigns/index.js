// api/campaigns/index.js
// GET  -> list active campaigns (marketplace). Admins can pass ?all=1 to see every status.
// POST -> create a campaign (admin only)
const connectDB = require('../../lib/db');
const Campaign = require('../../models/Campaign');
const { ok, fail, methodNotAllowed } = require('../../lib/response');
const { requireAuth, requireAdmin, requireBrand } = require('../../lib/auth');
const brandCampaigns = require('../../lib/handlers/campaignBrand');
const { validateCampaignInput } = require('../../lib/validation');
const { serializeCampaign } = require('../../lib/campaigns');
const Transaction = require('../../models/Transaction');
const { inTransaction } = require('../../lib/ledger');
const { getRecommendedCampaigns, notifyMatchingCreators } = require('../../lib/campaignMatching');

async function listCampaigns(req, res) {
  await connectDB();
  if (req.user.role === 'brand') return brandCampaigns.mine(req, res);
  // Creators only ever see campaigns that are live AND paid for by the brand.
  const filter = req.user.role === 'admin' && req.query.all === '1' ? {} : { status: 'active', fundingStatus: 'funded' };
  const campaigns = await Campaign.find(filter).sort({ createdAt: -1 }).limit(200).lean();
  const serialized = campaigns.map((c) => serializeCampaign(c, req.user.id));
  const recommended = req.user.role === 'creator' ? await getRecommendedCampaigns(req.user.id, campaigns) : [];
  return ok(res, { campaigns: serialized, recommendedCampaigns: recommended });
}

async function createCampaign(req, res) {
  await connectDB();
  const { errors, value } = validateCampaignInput(req.body, { partial: false });
  if (errors.length) return fail(res, errors[0], 400, { errors });

  // An admin campaign is paid by the platform itself: it is marked funded for its full budget (with a ledger row), otherwise
  // creators could never see, join or be paid from it.
  const campaign = await inTransaction(async (session) => {
    const [c] = await Campaign.create([{ ...value, status: 'active', createdBy: req.user.id, fundingStatus: 'funded', fundedAmount: value.budgetTotal }], { session });
    await Transaction.create([{
      user: req.user.id, type: 'campaign_funding', amount: value.budgetTotal, currency: 'USD', description: `Platform-funded campaign: ${c.title}`,
      provider: 'manual', providerTransactionId: `admin-funded:${c._id}`, campaign: c._id, metadata: { platformFunded: true },
    }], { session });
    return c;
  });
  notifyMatchingCreators(campaign.toObject ? campaign.toObject() : campaign).catch(() => {});
  return ok(res, { campaign: serializeCampaign(campaign, req.user.id) }, 201);
}

module.exports = async (req, res) => {
  if (req.method === 'GET') return requireAuth(listCampaigns)(req, res);
  if (req.method === 'POST') return requireAuth((rq, rs) => (rq.user.role === 'brand' ? brandCampaigns.create(rq, rs) : rq.user.role === 'admin' ? createCampaign(rq, rs) : fail(rs, 'Admin or brand access required', 403)))(req, res);
  return methodNotAllowed(res, ['GET', 'POST']);
};
