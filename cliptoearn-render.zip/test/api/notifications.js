const connectDB = require('../lib/db');
const Notification = require('../models/Notification');
const { ok, fail, methodNotAllowed } = require('../lib/response');
const { requireAuth } = require('../lib/auth');

async function handler(req, res) {
  await connectDB();
  if (req.method === 'GET') {
    const limit = Math.min(50, Math.max(1, Number(req.query.limit) || 30));
    const notifications = await Notification.find({ user: req.user.id }).sort({ createdAt: -1 }).limit(limit).lean();
    const unread = await Notification.countDocuments({ user: req.user.id, readAt: null });
    return ok(res, { notifications, unread });
  }

  if (req.method === 'PATCH') {
    const id = String(req.body?.id || '');
    if (id === 'all') {
      await Notification.updateMany({ user: req.user.id, readAt: null }, { $set: { readAt: new Date() } });
      return ok(res, { updated: 'all' });
    }
    if (!/^[a-f\d]{24}$/i.test(id)) return fail(res, 'A valid notification id is required.', 400);
    const updated = await Notification.findOneAndUpdate({ _id: id, user: req.user.id }, { $set: { readAt: new Date() } }, { new: true }).lean();
    if (!updated) return fail(res, 'Notification not found.', 404);
    return ok(res, { notification: updated });
  }

  return methodNotAllowed(res, ['GET', 'PATCH']);
}

module.exports = (req, res) => requireAuth(handler)(req, res);
