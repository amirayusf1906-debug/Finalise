// api/payments/[action].js - ONE serverless function for everything payment-related (Vercel's free
// plan allows 12 functions; the project already used 11).
//   public (verified by signature, not by login):  webhook, payout-webhook
//   brand:  fund (POST), list (GET)
//   admin:  ledger, reconcile, brands, unavailable (GET) ; brand-status, refund-complete, reverse-reward,
//           payout-send, payout-verify, payout-sync (POST)
const { requireAuth, requireBrand, requireAdmin } = require('../../lib/auth');
const { methodNotAllowed, fail } = require('../../lib/response');
const brandPay = require('../../lib/handlers/paymentsBrand');
const hooks = require('../../lib/handlers/paymentsWebhooks');
const admin = require('../../lib/handlers/paymentsAdmin');

const ADMIN_GET = ['ledger', 'reconcile', 'brands', 'unavailable', 'pending-rewards'];
const ADMIN_POST = ['brand-status', 'refund-complete', 'reverse-reward', 'pay-reward', 'payout-send', 'payout-verify', 'payout-sync'];

module.exports = async (req, res) => {
  const { action } = req.query;
  if (action === 'webhook') return hooks.paymentWebhook(req, res);
  if (action === 'payout-webhook') return hooks.payoutWebhook(req, res);
  if (action === 'fund') return req.method === 'POST' ? requireBrand(brandPay.fund)(req, res) : methodNotAllowed(res, ['POST']);
  if (action === 'deposit') return req.method === 'POST' ? requireBrand(brandPay.deposit)(req, res) : methodNotAllowed(res, ['POST']);
  if (action === 'list') return req.method === 'GET' ? requireAuth((rq, rs) => (['brand', 'admin'].includes(rq.user.role) ? brandPay.list(rq, rs) : fail(rs, 'Not allowed', 403)))(req, res) : methodNotAllowed(res, ['GET']);
  if (ADMIN_GET.includes(action)) return req.method === 'GET' ? requireAdmin(admin[action])(req, res) : methodNotAllowed(res, ['GET']);
  if (ADMIN_POST.includes(action)) return req.method === 'POST' ? requireAdmin(admin[action])(req, res) : methodNotAllowed(res, ['POST']);
  return fail(res, 'Not found', 404);
};
