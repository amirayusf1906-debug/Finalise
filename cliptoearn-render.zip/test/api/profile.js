// api/profile.js
// GET   -> current user's profile + balance
// PATCH -> update editable profile fields
const connectDB = require('../lib/db');
const User = require('../models/User');
const Withdrawal = require('../models/Withdrawal');
const { ok, fail, methodNotAllowed } = require('../lib/response');
const { requireAuth } = require('../lib/auth');
const { isHttpUrl } = require('../lib/validation');
const transactions = require('../lib/handlers/transactions');
const fees = require('../lib/fees');

async function getProfile(req, res) {
  await connectDB();
  const user = await User.findById(req.user.id).select('-passwordHash').lean();
  if (!user) return fail(res, 'User not found', 404);
  // Available = what can be withdrawn now (user.balance). Pending = money already taken out of the
  // balance for withdrawals that have not finished yet. Both come from the ledger-backed records.
  const open = await Withdrawal.aggregate([{ $match: { user: user._id, status: { $in: ['pending', 'processing'] } } }, { $group: { _id: null, total: { $sum: '$amount' } } }]);
  user.pendingWithdrawalBalance = open.length ? open[0].total : 0;
  user.pendingPaymentBalance = user.pendingEarnings || 0;
  user.pendingBalance = user.pendingPaymentBalance;
  // Brand wallet is separate from creator earnings. It is never mixed into creator withdrawals.
  if (user.role !== 'brand') delete user.brandBalance;
  // Fee settings for the screens that show a preview. The real fees are always calculated on the server with lib/fees.js.
  user.fees = { campaignFeePercent: fees.CAMPAIGN_FEE_PERCENT, withdrawalFeePercent: fees.WITHDRAWAL_FEE_PERCENT, minWithdrawal: fees.MIN_WITHDRAWAL, maxWithdrawalFee: fees.MAX_WITHDRAWAL_FEE };
  return ok(res, { user });
}

async function updateProfile(req, res) {
  await connectDB();
  const { displayName, avatarUrl } = req.body || {};
  const patch = {};
  if (displayName !== undefined) {
    if (typeof displayName !== 'string' || displayName.trim().length > 50) {
      return fail(res, 'Display name can be up to 50 characters.');
    }
    patch.displayName = displayName.trim();
  }
  if (avatarUrl !== undefined) {
    if (typeof avatarUrl !== 'string' || avatarUrl.length > 500 || (avatarUrl && !isHttpUrl(avatarUrl))) {
      return fail(res, 'Avatar link must be a web address starting with https://');
    }
    patch.avatarUrl = avatarUrl.trim();
  }

  const user = await User.findByIdAndUpdate(req.user.id, { $set: patch }, { new: true }).select('-passwordHash');
  return ok(res, { user });
}

module.exports = async (req, res) => {
  if (req.query.view === 'transactions') return transactions(req, res); // earnings history
  if (req.method === 'GET') return requireAuth(getProfile)(req, res);
  if (req.method === 'PATCH') return requireAuth(updateProfile)(req, res);
  return methodNotAllowed(res, ['GET', 'PATCH']);
};
