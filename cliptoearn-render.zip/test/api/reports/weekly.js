const crypto = require('crypto');
const connectDB = require('../../lib/db');
const User = require('../../models/User');
const Submission = require('../../models/Submission');
const ViewSnapshot = require('../../models/ViewSnapshot');
const Transaction = require('../../models/Transaction');
const Notification = require('../../models/Notification');
const { ok, fail, methodNotAllowed } = require('../../lib/response');

function authorized(req) {
  const secret = process.env.CRON_SECRET;
  if (!secret) return false;
  const given = Buffer.from(String(req.headers.authorization || ''));
  const want = Buffer.from(`Bearer ${secret}`);
  return given.length === want.length && crypto.timingSafeEqual(given, want);
}
function dayKey(d) { return new Date(d).toISOString().slice(0, 10); }
function addDays(date, amount) { const d = new Date(date); d.setUTCDate(d.getUTCDate() + amount); return d; }
function startOfDay(d) { const x = new Date(d); x.setUTCHours(0, 0, 0, 0); return x; }
function weekKey(d) { const x = startOfDay(d); const day = x.getUTCDay() || 7; const monday = addDays(x, 1 - day); return dayKey(monday); }

async function buildForUser(userId, weekStart) {
  const endExclusive = addDays(weekStart, 7);
  const previousDay = addDays(weekStart, -1);
  const [snapshots, submissions, earnings] = await Promise.all([
    ViewSnapshot.find({ creator: userId, dateKey: { $gte: dayKey(previousDay), $lt: dayKey(endExclusive) } }).sort({ dateKey: 1 }).lean(),
    Submission.find({ creator: userId, createdAt: { $gte: weekStart, $lt: endExclusive } }).select('status').lean(),
    Transaction.find({ user: userId, type: { $in: ['earning', 'campaign_reward'] }, amount: { $gt: 0 }, createdAt: { $gte: weekStart, $lt: endExclusive } }).select('amount').lean(),
  ]);
  const byDay = new Map();
  for (const s of snapshots) byDay.set(s.dateKey, (byDay.get(s.dateKey) || 0) + Number(s.views || 0));
  let prev = byDay.get(dayKey(previousDay)) || 0;
  let views = 0;
  for (let i = 0; i < 7; i += 1) {
    const total = byDay.get(dayKey(addDays(weekStart, i))) ?? prev;
    views += Math.max(0, total - prev);
    prev = total;
  }
  return {
    views,
    approvedClips: submissions.filter((s) => s.status === 'approved').length,
    pendingClips: submissions.filter((s) => s.status === 'pending').length,
    earned: earnings.reduce((n, t) => n + Number(t.amount || 0), 0),
  };
}

module.exports = async (req, res) => {
  if (req.method !== 'GET') return methodNotAllowed(res, ['GET']);
  if (!authorized(req)) return fail(res, 'Unauthorized', 401);
  await connectDB();

  const now = startOfDay(new Date());
  const monday = addDays(now, 1 - (now.getUTCDay() || 7));
  const key = weekKey(monday);
  const creators = await User.find({ role: 'creator', status: 'active' }).select('_id').limit(1000).lean();
  let created = 0;

  for (const creator of creators) {
    const report = await buildForUser(creator._id, monday);
    const dedupeKey = `weekly:${key}`;
    const notification = await Notification.findOneAndUpdate(
      { user: creator._id, dedupeKey },
      {
        $setOnInsert: {
          user: creator._id,
          type: 'weekly_report',
          title: 'Your weekly ClipToEarn report',
          message: `${report.views.toLocaleString()} views this week · ${report.approvedClips} approved clips · $${(report.earned / 100).toFixed(2)} earned.`,
          data: { weekStart: key, ...report },
          dedupeKey,
        },
      },
      { upsert: true, new: true, setDefaultsOnInsert: true }
    );
    if (notification.createdAt && notification.createdAt.getTime() === notification.updatedAt.getTime()) created += 1;
  }

  return ok(res, { weekStart: key, creatorsChecked: creators.length, reportsCreated: created });
};
