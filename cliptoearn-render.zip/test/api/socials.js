// api/socials.js
//
// GET:
//   List the current user's connected/verified/pending
//   social accounts.
//
// DELETE:
//   Disconnect the current user's account for a platform.
//
// TikTok bio verification state is also returned here.
//
// IMPORTANT:
// verificationNonce is selected explicitly only so that
// present() can expose the pending verification code to
// the same authenticated user who requested it.
//
// accessToken and refreshToken are NEVER returned.

const connectDB = require('../lib/db');

const SocialAccount =
  require('../models/SocialAccount');

const {
  ensureFreshToken
} = require('../lib/oauth');

const {
  ok,
  fail,
  methodNotAllowed
} = require('../lib/response');

const {
  requireAuth
} = require('../lib/auth');

const {
  present
} = require('../lib/handlers/socialsVerify');

/* =========================================================
   LIST ACCOUNTS
========================================================= */

async function list(req, res) {
  await connectDB();

  /*
   * Tokens are select:false by default.
   *
   * We explicitly select verificationNonce because a pending
   * TikTok creator needs to see their own CTE code.
   *
   * IMPORTANT:
   * present() strips this field from the response and only
   * exposes it as verificationCode when status === pending.
   */
  const accounts =
    await SocialAccount.find({
      user: req.user.id
    }).select(
      '+accessToken ' +
      '+refreshToken ' +
      '+tokenExpiresAt ' +
      '+verificationNonce ' +
      '+handleKey'
    );

  /*
   * Keep the existing token-refresh behavior.
   *
   * Bio-verified TikTok accounts don't have OAuth tokens,
   * so ensureFreshToken() simply leaves them alone.
   */
  await Promise.all(
    accounts.map((account) =>
      ensureFreshToken(account).catch((err) => {
        console.error(
          `Token refresh failed for ${account.platform} account ${account._id}:`,
          err.message
        );
      })
    )
  );

  return ok(res, {
    accounts: accounts.map(present)
  });
}

/* =========================================================
   DISCONNECT
========================================================= */

async function disconnect(req, res) {
  await connectDB();

  const platform =
    String(req.query.platform || '')
      .trim()
      .toLowerCase();

  if (!platform) {
    return fail(
      res,
      'platform query param is required',
      400
    );
  }

  const allowedPlatforms = [
    'tiktok',
    'instagram',
    'youtube'
  ];

  if (!allowedPlatforms.includes(platform)) {
    return fail(
      res,
      'Unsupported platform',
      400
    );
  }

  const deleted =
    await SocialAccount.findOneAndDelete({
      user: req.user.id,
      platform
    });

  if (!deleted) {
    return fail(
      res,
      `No ${platform} account is connected.`,
      404
    );
  }

  return ok(res, {
    message:
      `${platform} disconnected`
  });
}

/* =========================================================
   ROUTER
========================================================= */

module.exports = async (req, res) => {
  if (req.method === 'GET') {
    return requireAuth(list)(req, res);
  }

  if (req.method === 'DELETE') {
    return requireAuth(disconnect)(req, res);
  }

  return methodNotAllowed(
    res,
    ['GET', 'DELETE']
  );
};