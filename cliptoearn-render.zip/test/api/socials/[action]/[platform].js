// api/socials/[action]/[platform].js
//
// Dynamic social-action router.
//
// TikTok bio verification:
//   POST /api/socials/verify-start/tiktok
//   POST /api/socials/verify-check/tiktok
//
// OAuth routes remain available for future platforms,
// but TikTok currently uses bio verification.

const { fail } = require('../../../lib/response');
const { requireAuth } = require('../../../lib/auth');

const socialsVerify = require('../../../lib/handlers/socialsVerify');

const handlers = {
  connect: require('../../../lib/handlers/socialsConnect'),

  callback: require('../../../lib/handlers/socialsCallback'),

  refresh: require('../../../lib/handlers/socialsRefresh'),

  'verify-start': socialsVerify.start,

  'verify-check': socialsVerify.check,
};

module.exports = async (req, res) => {
  const action = req.query.action;
  const platform = String(
    req.query.platform || ''
  ).toLowerCase();

  const handler =
    Object.prototype.hasOwnProperty.call(
      handlers,
      action
    )
      ? handlers[action]
      : null;

  if (!handler) {
    return fail(
      res,
      'Not found',
      404
    );
  }

  /*
   * Bio verification must always belong to an
   * authenticated ClipToEarn user.
   */
  if (
    action === 'verify-start' ||
    action === 'verify-check'
  ) {
    if (platform !== 'tiktok') {
      return fail(
        res,
        'Only TikTok bio verification is supported.',
        400
      );
    }

    return requireAuth(handler)(req, res);
  }

  /*
   * Other social handlers retain their existing behavior.
   */
  return handler(req, res);
};