// api/submissions/approve.js
// POST -> admin approves or rejects a submission.
// On approval: computes and reserves the reward, but DOES NOT mark the creator paid.
// Approval and payment are separate states. The creator's pendingEarnings increases until an admin/payment action marks it paid.
//
// Every check that protects money happens inside the database write itself, not in a
// read-then-write sequence, so two admins clicking at once cannot double-pay a clip or push a
// campaign past its budget:
//   - the submission only flips from "pending" if it is still pending
//   - the budget only increases if budgetSpent + payout <= budgetTotal
//
// Requires MongoDB to be running as a replica set (Atlas clusters are, including the free tier).
const mongoose = require('mongoose');
const connectDB = require('../../lib/db');
const Submission = require('../../models/Submission');
const Campaign = require('../../models/Campaign');
const User = require('../../models/User');
const Transaction = require('../../models/Transaction');
const Notification = require('../../models/Notification');
const { ok, fail, methodNotAllowed, httpError, dollars } = require('../../lib/response');
const { requireAdmin } = require('../../lib/auth');
const { isObjectId, MAX_VIEWS } = require('../../lib/validation');
const { isExhausted } = require('../../lib/ledger');

async function review(req, res) {
  await connectDB();
  const { submissionId, decision, views, rejectionReason } = req.body || {};

  if (!isObjectId(submissionId) || !['approve', 'reject'].includes(decision)) {
    return fail(res, 'submissionId and decision ("approve" or "reject") are required');
  }

  const found = await Submission.findById(submissionId).lean();
  if (!found) return fail(res, 'Submission not found', 404);
  if (found.status !== 'pending') return fail(res, 'This submission has already been reviewed', 409);
  if (String(found.creator) === req.user.id) return fail(res, 'You cannot review your own submission', 403);

  if (decision === 'reject') {
    const reason = typeof rejectionReason === 'string' ? rejectionReason.trim().slice(0, 200) : '';
    const submission = await Submission.findOneAndUpdate(
      { _id: submissionId, status: 'pending' },
      { $set: { status: 'rejected', rejectionReason: reason || 'Did not meet campaign requirements', reviewedBy: req.user.id, reviewedAt: new Date() } },
      { new: true }
    );
    if (!submission) return fail(res, 'This submission has already been reviewed', 409);
    return ok(res, { submission });
  }

  if (typeof views !== 'number' || !Number.isSafeInteger(views) || views < 0 || views > MAX_VIEWS) {
    return fail(res, 'Enter the current view count as a whole number (0 or more).');
  }
  const campaign = await Campaign.findById(found.campaign).lean();
  if (!campaign) return fail(res, 'The campaign for this submission no longer exists', 404);

  // Brand campaigns pay a flat reward once per creator. Older campaigns still pay per 1,000 views.
  const flat = campaign.rewardPerCreator > 0;
  const payoutAmount = flat ? campaign.rewardPerCreator : Math.round((views / 1000) * campaign.payoutPerThousandViews);
  // Money rule: nothing is credited unless the brand's payment was confirmed and the campaign is open.
  if (campaign.fundingStatus !== 'funded' || !['active', 'paused'].includes(campaign.status)) {
    return fail(res, 'This campaign is not funded and open, so rewards cannot be paid yet.', 409);
  }

  const session = await mongoose.startSession();
  let submission;
  try {
    await session.withTransaction(async () => {
      submission = await Submission.findOneAndUpdate(
        { _id: submissionId, status: 'pending' },
        { $set: { views, status: 'approved', paymentStatus: payoutAmount > 0 ? 'pending' : 'paid', payoutAmount, reviewedBy: req.user.id, reviewedAt: new Date() } },
        { new: true, session }
      );
      if (!submission) throw httpError('This submission has already been reviewed', 409);

      if (payoutAmount > 0) {
        if (flat && (await Transaction.exists({ campaign: campaign._id, user: submission.creator, type: 'campaign_reward' }).session(session))) {
          throw httpError('This creator has already been rewarded for this campaign.', 409);
        }
        // Atomic budget check + update in one operation: the reward must fit inside the FUNDED amount that is left.
        const updated = await Campaign.findOneAndUpdate(
          {
            _id: campaign._id, fundingStatus: 'funded', status: { $in: ['active', 'paused'] },
            $expr: { $lte: [{ $add: ['$budgetSpent', payoutAmount] }, { $ifNull: ['$fundedAmount', 0] }] },
          },
          { $inc: { budgetSpent: payoutAmount } },
          { new: true, session }
        );
        if (!updated) throw httpError('Payout exceeds remaining campaign budget', 400);

        const creator = await User.findByIdAndUpdate(
          submission.creator,
          { $inc: { pendingEarnings: payoutAmount } },
          { new: true, session }
        );
        if (!creator) throw httpError('The creator account no longer exists', 404);

        // Approval reserves the campaign budget, but the creator is NOT paid yet.
        await Notification.findOneAndUpdate(
          { user: creator._id, dedupeKey: `submission-approved:${submission._id}` },
          { $setOnInsert: { user: creator._id, type: 'submission_update', title: 'Your clip was approved', message: `Your clip for "${campaign.title}" was approved. ${dollars(payoutAmount)} is pending payment.`, data: { submissionId: String(submission._id), payoutAmount }, dedupeKey: `submission-approved:${submission._id}` } },
          { upsert: true, setDefaultsOnInsert: true }
        );

        // Funded money used up (cannot pay another reward): close the campaign.
        if (isExhausted(updated)) {
          await Campaign.updateOne({ _id: campaign._id, status: 'active' }, { $set: { status: 'completed' } }, { session });
        }
      }
    });
  } catch (err) {
    if (err.httpStatus === 400 && /budget/i.test(err.message)) {
      const fresh = await Campaign.findById(campaign._id).lean();
      const remaining = fresh ? Math.max(0, (fresh.fundedAmount || 0) - fresh.budgetSpent) : 0;
      return fail(res, `Payout of ${dollars(payoutAmount)} exceeds the ${dollars(remaining)} of funded budget left in this campaign.`, 400, { remainingBudget: remaining, requestedPayout: payoutAmount });
    }
    throw err;
  } finally {
    await session.endSession();
  }

  return ok(res, { submission });
}

module.exports = async (req, res) => {
  if (req.method !== 'POST') return methodNotAllowed(res, ['POST']);
  return requireAdmin(review)(req, res);
};
