// api/submissions/index.js
// GET  -> list submissions (own, or all if admin + ?all=1)
// POST -> creator submits a video to a campaign they've joined
const crypto = require('crypto');
const connectDB = require('../../lib/db');
const Submission = require('../../models/Submission');
const ViewSnapshot = require('../../models/ViewSnapshot');
const Campaign = require('../../models/Campaign');
const SocialAccount = require('../../models/SocialAccount');
const { ok, fail, methodNotAllowed } = require('../../lib/response');
const { requireAuth } = require('../../lib/auth');
const { isExhausted } = require('../../lib/ledger');
const { allow } = require('../../lib/rateLimit');
const { fetchTikTokVideo } = require('../../lib/tiktokVideo');
const { parseVideoUrl, isObjectId, PLATFORMS, PLATFORM_LABELS } = require('../../lib/validation');

const MAX_PENDING_PER_CAMPAIGN = 20;

// A brand sees the results of its OWN campaigns: platform, link, status and views, not creator details.
async function brandResults(req, res) {
  await connectDB();
  if (!isObjectId(req.query.campaignId)) return fail(res, 'campaignId is required');
  const owned = await Campaign.exists({ _id: req.query.campaignId, brand: req.user.id });
  if (!owned) return fail(res, 'Campaign not found', 404);
  const submissions = await Submission.find({ campaign: req.query.campaignId }).select('platform videoUrl status views payoutAmount createdAt').sort({ createdAt: -1 }).limit(500).lean();
  return ok(res, { submissions });
}

async function listSubmissions(req, res) {
  if (req.user.role === 'brand') return brandResults(req, res);
  await connectDB();
  const isAdminView = req.user.role === 'admin' && req.query.all === '1';
  const filter = isAdminView ? {} : { creator: req.user.id };
  if (['pending', 'approved', 'rejected', 'reversed'].includes(req.query.status)) filter.status = req.query.status;

  let query = Submission.find(filter)
    .populate('campaign', 'title brandName payoutPerThousandViews')
    .sort({ createdAt: -1 })
    .limit(500);
  if (isAdminView) query = query.populate('creator', 'username');
  const submissions = await query.lean();

  return ok(res, { submissions });
}

async function createSubmission(req, res) {
  await connectDB();
  const { campaignId, platform, videoUrl } = req.body || {};

  if (!isObjectId(campaignId) || typeof platform !== 'string' || typeof videoUrl !== 'string') {
    return fail(res, 'campaignId, platform and videoUrl are required');
  }
  if (!PLATFORMS.includes(platform)) {
    return fail(res, 'platform must be tiktok, instagram, or youtube');
  }
  if (req.user.role !== 'creator') return fail(res, 'Only creator accounts can submit videos', 403);

  if (!(await allow(req, res, { name: 'submit', id: req.user.id, max: 40, windowSec: 3600, message: 'You are submitting too fast. Try again in a few minutes.' }))) return undefined;

  const campaign = await Campaign.findById(campaignId);
  if (!campaign) return fail(res, 'Campaign not found', 404);
  if (campaign.status !== 'active') return fail(res, 'This campaign is not currently active');
  if (campaign.fundingStatus !== 'funded') return fail(res, 'This campaign is not funded yet');
  if (isExhausted(campaign)) return fail(res, 'This campaign has used its full budget');
  if (campaign.deadline && campaign.deadline < new Date()) return fail(res, 'This campaign has ended');

  const isParticipant = campaign.participants.some((p) => p.toString() === req.user.id);
  if (!isParticipant) return fail(res, 'Join this campaign before submitting a video', 403);

  // 1. The campaign must accept this platform (an empty list on an old campaign means any platform)
  const label = PLATFORM_LABELS[platform];
  if (campaign.platforms && campaign.platforms.length && !campaign.platforms.includes(platform)) {
    return fail(res, `This campaign does not accept ${label} clips.`);
  }

  // 2. The creator must have that platform connected
  const account = await SocialAccount.findOne({ user: req.user.id, platform, verified: true }).lean();
  if (!account) return fail(res, `Connect your ${label} account in Socials before submitting a ${label} clip.`, 403);

  // 3. The link must be a real video link for that platform...
  const parsed = parseVideoUrl(platform, videoUrl);
  if (parsed.error) return fail(res, parsed.error);

  // ...and a TikTok video must come from the connected TikTok account, not someone else's.
  let tiktokData = null;

  if (platform === 'tiktok') {
    const connected = String(account.handle || '').replace(/^@/, '').toLowerCase();
    const check = await fetchTikTokVideo(parsed.url);

    if (check.status === 'not_found') {
      return fail(res, 'We could not find that TikTok video. Check the link and try again.', 422);
    }
    if (check.status === 'unreachable') {
      return fail(res, check.error || 'TikTok verification is temporarily unavailable. Please try again.', 503);
    }

    const returnedUsername = String(check.username || '').replace(/^@/, '').toLowerCase();
    if (!returnedUsername) {
      return fail(res, 'TikTok did not return the video owner, so ownership could not be verified.', 422);
    }
    if (returnedUsername !== connected) {
      return fail(res, `This video is from @${returnedUsername}, but your connected TikTok account is @${connected}. You can only submit your own videos.`, 403);
    }
    if (!check.videoId) return fail(res, 'Could not identify that TikTok video. Try the full link.', 422);
    tiktokData = check;
  }

  // The hash identifies the VIDEO, not the link used to paste it, so a canonical link and any short
  // link to the same TikTok video count as the same clip.
  const canonicalUrl = tiktokData ? tiktokData.canonicalUrl : parsed.url;
  const hashSource = tiktokData ? `tiktok:${tiktokData.videoId}` : parsed.url;
  const videoUrlHash = crypto.createHash('sha256').update(hashSource).digest('hex');

  // The same video cannot be paid by two campaigns, or twice by one.
  const duplicate = await Submission.findOne({
    videoUrlHash,
    $or: [{ campaign: campaignId }, { status: { $in: ['pending', 'approved'] } }],
  }).lean() || (tiktokData && await Submission.findOne({
    tiktokVideoId: tiktokData.videoId,
    $or: [{ campaign: campaignId }, { status: { $in: ['pending', 'approved'] } }],
  }).lean());
  if (duplicate) return fail(res, 'This video has already been submitted.', 409);

  // Brand campaigns pay one flat reward per creator, so a second clip could never be paid.
  if (campaign.rewardPerCreator > 0 && await Submission.exists({ campaign: campaignId, creator: req.user.id, status: { $in: ['pending', 'approved'] } })) {
    return fail(res, 'You already have a clip in this campaign. This campaign pays one reward per creator.', 409);
  }

  const pending = await Submission.countDocuments({ campaign: campaignId, creator: req.user.id, status: 'pending' });
  if (pending >= MAX_PENDING_PER_CAMPAIGN) {
    return fail(res, `You already have ${MAX_PENDING_PER_CAMPAIGN} clips waiting for review in this campaign. Wait for some to be reviewed first.`, 429);
  }

  try {
    const submission = await Submission.create({
      campaign: campaignId,
      creator: req.user.id,
      platform,
      videoUrl: canonicalUrl,
      videoUrlHash,
      ...(tiktokData ? {
        tiktokUsername: tiktokData.username || '',
        tiktokVideoId: tiktokData.videoId || '',
        views: tiktokData.views ?? 0,
        likes: tiktokData.likes ?? 0,
        comments: tiktokData.comments ?? 0,
        shares: tiktokData.shares ?? 0,
        description: tiktokData.description || '',
        videoCheckedAt: new Date(),
      } : {}),
      status: 'pending',
    });
    if (tiktokData) {
      await ViewSnapshot.findOneAndUpdate(
        { submission: submission._id, dateKey: new Date().toISOString().slice(0, 10) },
        { $set: { creator: req.user.id, views: tiktokData.views ?? 0, capturedAt: new Date() } },
        { upsert: true, new: true, setDefaultsOnInsert: true }
      );
    }
    return ok(res, { submission }, 201);
  } catch (err) {
    // Unique index race condition fallback
    if (err.code === 11000) return fail(res, 'This video has already been submitted.', 409);
    throw err;
  }
}

module.exports = async (req, res) => {
  if (req.method === 'GET') return requireAuth(listSubmissions)(req, res);
  if (req.method === 'POST') return requireAuth(createSubmission)(req, res);
  return methodNotAllowed(res, ['GET', 'POST']);
};
