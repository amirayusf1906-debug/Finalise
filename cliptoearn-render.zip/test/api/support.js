// api/support.js - support tickets (every signed-in role can use it; admins see and answer all of them)
//   GET   /api/support            -> own tickets (admin: ?all=1 for every ticket)
//   GET   /api/support?id=        -> one ticket with its messages
//   POST  /api/support {subject, category, message}  -> new ticket
//   POST  /api/support {ticketId, message}           -> reply
//   PATCH /api/support {ticketId, status}            -> admin changes the ticket status
const connectDB = require('../lib/db');
const SupportTicket = require('../models/SupportTicket');
const { ok, fail, methodNotAllowed } = require('../lib/response');
const { requireAuth } = require('../lib/auth');
const { allow } = require('../lib/rateLimit');
const { isObjectId, isNonEmptyString } = require('../lib/validation');

const STATUSES = ['open', 'in_progress', 'resolved', 'closed'];
const CATEGORIES = ['payment', 'account', 'campaign', 'technical', 'other'];
const isAdmin = (req) => req.user.role === 'admin';
const cleanText = (v, max) => (typeof v === 'string' ? v.trim().slice(0, max) : '');

async function load(req, id) {
  if (!isObjectId(id)) return null;
  const filter = isAdmin(req) ? { _id: id } : { _id: id, user: req.user.id };
  return SupportTicket.findOne(filter);
}

async function list(req, res) {
  await connectDB();
  if (req.query.id) {
    const t = await load(req, String(req.query.id));
    if (!t) return fail(res, 'Ticket not found', 404);
    await t.populate('user', 'username');
    return ok(res, { ticket: t.toObject() });
  }
  const filter = isAdmin(req) && req.query.all === '1' ? {} : { user: req.user.id };
  if (STATUSES.includes(req.query.status)) filter.status = req.query.status;
  let q = SupportTicket.find(filter).select('-messages').sort({ updatedAt: -1 }).limit(200);
  if (filter.user === undefined) q = q.populate('user', 'username');
  return ok(res, { tickets: await q.lean() });
}

async function create(req, res) {
  await connectDB();
  const { ticketId } = req.body || {};
  if (ticketId !== undefined) return reply(req, res);
  const subject = cleanText(req.body && req.body.subject, 120);
  const message = cleanText(req.body && req.body.message, 4000);
  const category = CATEGORIES.includes(req.body && req.body.category) ? req.body.category : 'other';
  if (!isNonEmptyString(subject) || !isNonEmptyString(message)) return fail(res, 'Enter a subject and a message.');
  if (!(await allow(req, res, { name: 'ticket-create', id: req.user.id, max: 10, windowSec: 3600, message: 'You opened too many tickets. Try again later.' }))) return undefined;
  const t = await SupportTicket.create({ user: req.user.id, subject, category, messages: [{ sender: 'user', author: req.user.id, body: message }] });
  return ok(res, { ticket: t.toObject() }, 201);
}

async function reply(req, res) {
  const message = cleanText(req.body.message, 4000);
  if (!isNonEmptyString(message)) return fail(res, 'Write a message first.');
  if (!(await allow(req, res, { name: 'ticket-reply', id: req.user.id, max: 60, windowSec: 3600, message: 'You are sending messages too fast.' }))) return undefined;
  const t = await load(req, req.body.ticketId);
  if (!t) return fail(res, 'Ticket not found', 404);
  if (t.status === 'closed' && !isAdmin(req)) return fail(res, 'This ticket is closed. Open a new ticket if you still need help.', 409);
  t.messages.push({ sender: isAdmin(req) ? 'admin' : 'user', author: req.user.id, body: message });
  if (!isAdmin(req) && ['resolved'].includes(t.status)) t.status = 'open'; // a new message from the user re-opens it
  await t.save();
  return ok(res, { ticket: t.toObject() });
}

async function setStatus(req, res) {
  await connectDB();
  if (!isAdmin(req)) return fail(res, 'Admin access required', 403);
  const { ticketId, status } = req.body || {};
  if (!STATUSES.includes(status)) return fail(res, 'status must be open, in_progress, resolved or closed');
  const t = isObjectId(ticketId) ? await SupportTicket.findByIdAndUpdate(ticketId, { $set: { status } }, { new: true }).lean() : null;
  if (!t) return fail(res, 'Ticket not found', 404);
  return ok(res, { ticket: t });
}

module.exports = async (req, res) => {
  if (req.method === 'GET') return requireAuth(list)(req, res);
  if (req.method === 'POST') return requireAuth(create)(req, res);
  if (req.method === 'PATCH') return requireAuth(setStatus)(req, res);
  return methodNotAllowed(res, ['GET', 'POST', 'PATCH']);
};
