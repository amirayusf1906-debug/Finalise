// api/withdrawals/[id].js
// PATCH -> admin moves a withdrawal along: pending -> processing -> completed, or failed/cancelled.
// On "failed" or "cancelled" the held amount is refunded to the user's balance. The status change
// only happens if the withdrawal is still open, so two admins clicking at once cannot refund
// the same withdrawal twice.
const mongoose = require('mongoose');
const connectDB = require('../../lib/db');
const Withdrawal = require('../../models/Withdrawal');
const Transaction = require('../../models/Transaction');
const User = require('../../models/User');
const { ok, fail, methodNotAllowed, httpError } = require('../../lib/response');
const { requireAdmin } = require('../../lib/auth');
const { isObjectId } = require('../../lib/validation');
const { returnWithdrawalFunds } = require('../../lib/ledger');

// Which current statuses each target status may come from
const ALLOWED_FROM = {
  processing: ['pending'],
  completed: ['pending', 'processing'],
  failed: ['pending', 'processing'],
  cancelled: ['pending', 'processing'],
};

async function updateStatus(req, res) {
  await connectDB();
  const { id } = req.query;
  const { status, failureReason } = req.body || {};

  if (!isObjectId(id)) return fail(res, 'Withdrawal not found', 404);
  if (!ALLOWED_FROM[status]) {
    return fail(res, 'status must be processing, completed, failed, or cancelled');
  }

  const existing = await Withdrawal.findById(id).lean();
  if (!existing) return fail(res, 'Withdrawal not found', 404);
  if (!ALLOWED_FROM[status].includes(existing.status)) {
    return fail(res, `This withdrawal is already ${existing.status}.`, 409);
  }

  // A crypto payout that NOWPayments has been asked to send cannot be completed or refunded by hand:
  // its real outcome comes from NOWPayments (webhook or the Sync button). Otherwise a refund here
  // could be paid out a second time by the provider. The only exception is a payout flagged for review.
  // A payout claimed more than 5 minutes ago that never got an answer from NOWPayments (no batch id) is treated like "needs review".
  const stuck = !existing.providerBatchId && existing.payoutRequestedAt && Date.now() - new Date(existing.payoutRequestedAt).getTime() > 5 * 60 * 1000;
  existing.needsReview = existing.needsReview || !!stuck;
  if (existing.method === 'crypto' && existing.provider === 'nowpayments' && (existing.payoutRequestedAt || existing.providerBatchId) && !existing.needsReview) {
    return fail(res, 'This crypto payout is handled by NOWPayments. Use the Payments page to send, verify or sync it.', 409);
  }
  if (existing.method === 'crypto' && ['completed', 'processing'].includes(status) && !existing.needsReview) {
    return fail(res, 'Crypto withdrawals are sent and completed through NOWPayments (Payments page), not by hand.', 409);
  }

  const reason = typeof failureReason === 'string' ? failureReason.trim().slice(0, 200) : '';
  const isRefund = status === 'failed' || status === 'cancelled';
  const set = {
    status,
    processedBy: req.user.id,
    processedAt: new Date(),
    failureReason: status === 'failed' ? reason || 'Processing failed' : '',
  };

  if (!isRefund) {
    const withdrawal = await Withdrawal.findOneAndUpdate(
      { _id: id, status: { $in: ALLOWED_FROM[status] } },
      { $set: set },
      { new: true }
    );
    if (!withdrawal) return fail(res, 'This withdrawal was just updated by someone else. Reload the list.', 409);
    return ok(res, { withdrawal });
  }

  const withdrawal = await returnWithdrawalFunds(id, status, { reason, adminId: req.user.id });
  if (!withdrawal) return fail(res, 'This withdrawal was just updated by someone else. Reload the list.', 409);
  return ok(res, { withdrawal });
}

module.exports = async (req, res) => {
  if (req.method !== 'PATCH') return methodNotAllowed(res, ['PATCH']);
  return requireAdmin(updateStatus)(req, res);
};
