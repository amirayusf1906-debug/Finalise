// api/withdrawals/index.js
// GET  -> list withdrawals (own, or all if admin + ?all=1)
// POST -> request a withdrawal. Debits balance, creates the Withdrawal record, and writes a
//         matching Transaction entry as one MongoDB transaction.
//
// The debit is a single conditional update ("only if balance >= amount"), so two requests sent
// at the same moment cannot both spend the same money.
const mongoose = require('mongoose');
const connectDB = require('../../lib/db');
const Withdrawal = require('../../models/Withdrawal');
const Transaction = require('../../models/Transaction');
const User = require('../../models/User');
const { ok, fail, methodNotAllowed, httpError } = require('../../lib/response');
const { requireAuth } = require('../../lib/auth');
const { allow } = require('../../lib/rateLimit');
const { isCents, isEmail } = require('../../lib/validation');
const { resolveCrypto } = require('../../lib/crypto');
const { calculateWithdrawalFees, MIN_WITHDRAWAL } = require('../../lib/fees');

const MIN_WITHDRAWAL_CENTS = Math.round(MIN_WITHDRAWAL * 100); // minimum payout, from lib/fees.js
const MAX_WITHDRAWAL_CENTS = 100000000; // $1,000,000
const MAX_OPEN_WITHDRAWALS = 3;

async function list(req, res) {
  await connectDB();
  const isAdminView = req.user.role === 'admin' && req.query.all === '1';
  const filter = isAdminView ? {} : { user: req.user.id };
  if (['pending', 'processing', 'completed', 'failed', 'cancelled'].includes(req.query.status)) {
    filter.status = req.query.status;
  }

  let query = Withdrawal.find(filter).sort({ createdAt: -1 }).limit(500);
  if (isAdminView) query = query.populate('user', 'username');
  const withdrawals = await query.lean();
  if (!isAdminView) withdrawals.forEach((w) => { delete w.providerBatchId; delete w.providerPayoutId; delete w.clientRequestId; delete w.payoutRequestedAt; delete w.needsReview; delete w.awaiting2fa; });
  return ok(res, { withdrawals });
}

async function requestWithdrawal(req, res) {
  await connectDB();
  const { amount, method, destination, cryptoCurrency, network, clientRequestId } = req.body || {};

  if (req.user.role !== 'creator') return fail(res, 'Only creator accounts can request withdrawals', 403);
  const me = await User.findById(req.user.id).select('emailVerified').lean();
  if (!me || !me.emailVerified) return fail(res, 'Confirm your email address before withdrawing. Use the banner at the top of your dashboard to get a new link.', 403, { needsEmailVerification: true });
  if (!isCents(amount, MIN_WITHDRAWAL_CENTS, MAX_WITHDRAWAL_CENTS)) {
    return fail(res, `Minimum withdrawal is $${(MIN_WITHDRAWAL_CENTS / 100).toFixed(2)}`);
  }
  if (!['paypal', 'crypto'].includes(method)) return fail(res, 'Choose PayPal or Crypto.');
  const dest = typeof destination === 'string' ? destination.trim() : '';
  if (!dest || dest.length > 200) return fail(res, 'Enter where to send the money.');
  const requestId = typeof clientRequestId === 'string' && /^[A-Za-z0-9-]{16,64}$/.test(clientRequestId) ? clientRequestId : undefined;

  let crypto = {};
  if (method === 'paypal') {
    if (!isEmail(dest)) return fail(res, 'Enter the email address of your PayPal account.');
  } else {
    // Never trust that a string is a wallet address: the currency AND network must be chosen, and the format must match.
    const r = resolveCrypto(cryptoCurrency, network, dest);
    if (r.error) return fail(res, r.error);
    crypto = { cryptoCurrency, network, payoutCurrencyCode: r.code };
  }

  // Fee comes from lib/fees.js (which works in dollars); the database stores cents.
  let fees;
  try { fees = calculateWithdrawalFees(amount / 100); } catch (err) { return fail(res, err.message); }
  const feeCents = Math.round(fees.fee * 100);
  const netCents = amount - feeCents; // gross - fee, kept in whole cents

  // Same request sent twice (double tap, retry): return the first withdrawal instead of creating another.
  if (requestId) {
    const again = await Withdrawal.findOne({ user: req.user.id, clientRequestId: requestId }).lean();
    if (again) return ok(res, { withdrawal: again, newBalance: (await User.findById(req.user.id).select('balance').lean()).balance, duplicate: true });
  }
  if (!(await allow(req, res, { name: 'withdraw', id: req.user.id, max: 10, windowSec: 3600, message: 'Too many withdrawal requests. Try again later.' }))) return undefined;

  const open = await Withdrawal.countDocuments({ user: req.user.id, status: { $in: ['pending', 'processing'] } });
  if (open >= MAX_OPEN_WITHDRAWALS) {
    return fail(res, `You already have ${MAX_OPEN_WITHDRAWALS} withdrawals in progress. Wait for one to be paid first.`);
  }

  const session = await mongoose.startSession();
  let withdrawal, newBalance;

  try {
    await session.withTransaction(async () => {
      // Debit only if the money is there. Nothing else can change the balance between check and debit.
      const user = await User.findOneAndUpdate(
        { _id: req.user.id, status: 'active', balance: { $gte: amount } },
        { $inc: { balance: -amount } },
        { new: true, session }
      );
      if (!user) throw httpError('Insufficient balance', 400);
      newBalance = user.balance;

      const created = await Withdrawal.create(
        [{ user: user._id, amount, feeAmount: feeCents, netAmount: netCents, method, destination: dest, status: 'pending', provider: method === 'crypto' ? 'nowpayments' : 'manual', clientRequestId: requestId, ...crypto }],
        { session }
      );
      withdrawal = created[0];

      const via = method === 'crypto' ? `${cryptoCurrency} (${network})` : 'PayPal';
      const rows = [{
        user: user._id,
        type: 'withdrawal',
        amount: -netCents,
        balanceAfter: user.balance + feeCents, // balance after the payout row, before the fee row
        description: `Withdrawal requested via ${via}`,
        provider: 'internal',
        withdrawal: withdrawal._id,
        metadata: { grossAmount: amount, feeAmount: feeCents, netAmount: netCents },
      }];
      if (feeCents > 0) {
        rows.push({
          user: user._id,
          type: 'withdrawal_fee',
          amount: -feeCents,
          balanceAfter: user.balance,
          description: 'Withdrawal fee',
          provider: 'internal',
          withdrawal: withdrawal._id,
          metadata: { grossAmount: amount, feeAmount: feeCents, netAmount: netCents },
        });
      }
      // ordered: true keeps the payout row before the fee row
      await Transaction.create(rows, { session, ordered: true });
    });
  } catch (err) {
    if (err.code === 11000 && requestId) { // two identical requests raced: the loser gets the winner's record
      const first = await Withdrawal.findOne({ user: req.user.id, clientRequestId: requestId }).lean();
      if (first) return ok(res, { withdrawal: first, duplicate: true });
    }
    throw err;
  } finally {
    await session.endSession();
  }

  return ok(res, { withdrawal, newBalance }, 201);
}

module.exports = async (req, res) => {
  if (req.method === 'GET') return requireAuth(list)(req, res);
  if (req.method === 'POST') return requireAuth(requestWithdrawal)(req, res);
  return methodNotAllowed(res, ['GET', 'POST']);
};
