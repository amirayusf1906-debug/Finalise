// js/account-email.js - forgot-password, reset-password and verify-email pages.
(function () {
  var page = document.body.dataset.page;
  var msg = document.getElementById('msg');
  var form = document.getElementById('form');
  var token = new URLSearchParams(location.search).get('token') || '';

  if (page === 'forgot') {
    form.addEventListener('submit', async function (e) {
      e.preventDefault();
      var btn = form.querySelector('button'); setLoading(btn, true, 'Sending…');
      try {
        var d = await apiRequest('/auth/forgot', { method: 'POST', body: { email: document.getElementById('email').value.trim() } });
        showAlert(msg, d.message, 'success'); form.reset();
      } catch (err) { showAlert(msg, err.message); }
      setLoading(btn, false);
    });
  }

  if (page === 'reset') {
    if (!token) { showAlert(msg, 'This reset link is incomplete. Request a new one.'); form.style.display = 'none'; }
    form.addEventListener('submit', async function (e) {
      e.preventDefault();
      var pw = document.getElementById('pw').value;
      if (pw !== document.getElementById('pw2').value) return showAlert(msg, 'The two passwords do not match.');
      var btn = form.querySelector('button'); setLoading(btn, true, 'Saving…');
      try {
        var d = await apiRequest('/auth/reset', { method: 'POST', body: { token: token, newPassword: pw } });
        showAlert(msg, d.message, 'success'); form.style.display = 'none';
        setTimeout(function () { location.href = 'login.html'; }, 1800);
      } catch (err) { showAlert(msg, err.message); setLoading(btn, false); }
    });
  }

  if (page === 'verify') {
    var note = document.getElementById('note'), go = document.getElementById('go');
    if (!token) { note.textContent = ''; showAlert(msg, 'This link is incomplete. Log in and request a new one.'); }
    else apiRequest('/auth/verify', { method: 'POST', body: { token: token } })
      .then(function () { document.querySelector('h1').textContent = 'Email confirmed'; note.textContent = 'Withdrawals and funding are now unlocked.'; go.style.display = 'inline-flex'; })
      .catch(function (err) { document.querySelector('h1').textContent = 'Link not valid'; note.textContent = ''; showAlert(msg, err.message); });
  }
})();
