// js/admin-payments.js - admin money tools. Everything is read-only except the explicit actions on each tab.
const $ = (id) => document.getElementById(id);
const note = (m, t) => showAlert($('pay-alert'), m, t);
const post = (path, body) => apiRequest(`/payments/${path}`, { method: 'POST', body });
const panel = () => $('panel');

const TABS = {
  async ['pending-rewards']() {
    const { submissions } = await apiRequest('/payments/pending-rewards');
    if (!submissions.length) return '<div class="card empty-state">No approved creator payments are waiting.</div>';
    return submissions.map((s) => `<div class="card campaign-card" data-id="${s._id}">
      <div class="top"><div><strong>${escapeHtml(s.campaign?.title || 'Campaign')}</strong><div class="faint">${escapeHtml(whoIs(s.creator))} · approved ${fmtDate(s.reviewedAt)}</div></div>
      <span class="badge badge-pending">Payment Pending</span></div>
      <div class="pay-row"><div><strong class="num">${formatCents(s.payoutAmount)}</strong> · approved clip · ${(s.views || 0).toLocaleString()} views</div></div>
      <div class="card-actions"><button class="btn btn-primary" data-act="pay-reward">Mark as paid</button></div>
    </div>`).join('');
  },
  async payouts() {
    const { withdrawals } = await apiRequest('/withdrawals?all=1');
    const rows = withdrawals.filter((w) => w.method === 'crypto');
    if (!rows.length) return '<div class="card empty-state">No crypto withdrawals.</div>';
    return rows.map((w) => {
      const sent = !!(w.providerBatchId || w.payoutRequestedAt);
      const open = ['pending', 'processing'].includes(w.status);
      const stuck = open && w.payoutRequestedAt && !w.providerBatchId && Date.now() - new Date(w.payoutRequestedAt).getTime() > 5 * 60 * 1000;
      return `<div class="card campaign-card" data-id="${w._id}">
        <div class="top"><div><strong class="num">Send ${formatCents(typeof w.netAmount === 'number' ? w.netAmount : w.amount)}</strong> <span class="faint">(withdrawal ${formatCents(w.amount)} − fee ${formatCents(typeof w.feeAmount === 'number' ? w.feeAmount : 0)})</span> → ${escapeHtml(w.cryptoCurrency)} (${escapeHtml(w.network)})
          <div class="faint">${escapeHtml(whoIs(w.user))} · ${fmtDate(w.createdAt)}</div></div>
          <span class="badge badge-${w.status === 'completed' ? 'approved' : ['failed', 'cancelled'].includes(w.status) ? 'rejected' : 'pending'}">${w.status}${w.providerStatus ? ' · ' + escapeHtml(w.providerStatus) : ''}</span></div>
        <div class="pay-row"><div class="id" style="grid-column:1/-1">Address: ${escapeHtml(w.destination)}${w.cryptoAmount ? ` · sending ${escapeHtml(w.cryptoAmount)} ${escapeHtml(w.payoutCurrencyCode)}` : ''}${w.providerPayoutId ? ` · provider payout ${escapeHtml(w.providerPayoutId)}` : ''}</div></div>
        ${stuck ? '<p class="hint">The payout request was sent more than 5 minutes ago and NOWPayments never answered. Check the NOWPayments dashboard, then fail or complete it manually from the Withdrawals tab in Admin.</p>' : ''}
        ${w.needsReview ? '<p class="hint">Outcome unknown. Check the NOWPayments dashboard, then fail or complete it manually from the Withdrawals tab in Admin.</p>' : ''}
        ${w.failureReason ? `<p class="hint">${escapeHtml(w.failureReason)}</p>` : ''}
        ${open ? `<div class="card-actions">
          ${!sent ? '<button class="btn btn-primary" data-act="payout-send">Send payout</button>' : ''}
          ${w.awaiting2fa ? '<input class="code" inputmode="numeric" placeholder="2FA code" style="flex:1 1 120px"><button class="btn btn-primary" data-act="payout-verify">Confirm with 2FA</button>' : ''}
          ${w.providerPayoutId ? '<button class="btn btn-secondary" data-act="payout-sync">Check status</button>' : ''}
        </div>` : ''}</div>`;
    }).join('');
  },
  async funding() {
    const { payments } = await apiRequest('/payments/list?all=1');
    const f = payments.filter((p) => p.type === 'campaign_funding');
    return f.length ? `<div class="card">${f.map((p) => `<div class="pay-row"><div><strong class="num">${formatCents(p.amount)}</strong>${typeof p.platformFee === 'number' ? ` <span class="faint">(budget ${formatCents(p.creatorBudget)} + fee ${formatCents(p.platformFee)})</span>` : ''} · ${escapeHtml(p.campaign ? p.campaign.title : '')} · ${escapeHtml((p.user && (p.user.brandProfile && p.user.brandProfile.companyName || p.user.username)) || '')}</div>
      <span class="badge badge-${p.status === 'funded' ? 'approved' : ['failed', 'expired'].includes(p.status) ? 'rejected' : 'pending'}">${p.status}${p.needsReview ? ' · REVIEW' : ''}</span>
      <div class="id">${fmtDate(p.createdAt)} · provider status ${escapeHtml(p.providerPaymentStatus || '-')} · payment ${escapeHtml(p.providerPaymentId || '-')} · invoice ${escapeHtml(p.providerInvoiceId || '-')}</div></div>`).join('')}</div>` : '<div class="card empty-state">No brand payments yet.</div>';
  },
  async refunds() {
    const { payments } = await apiRequest('/payments/list?all=1');
    const r = payments.filter((p) => p.type === 'campaign_refund');
    return r.length ? r.map((p) => `<div class="card campaign-card" data-id="${p._id}"><div class="top"><div><strong class="num">${formatCents(p.amount)}</strong> to ${escapeHtml((p.user && (p.user.brandProfile && p.user.brandProfile.companyName || p.user.username)) || '')}
      <div class="faint">${escapeHtml(p.campaign ? p.campaign.title : '')} · ${fmtDate(p.createdAt)}</div></div><span class="badge badge-${p.status === 'completed' ? 'approved' : 'pending'}">${p.status}</span></div>
      ${p.status === 'owed' ? '<p class="hint">Send the money to the brand outside this app, then record the transaction id here.</p><div class="card-actions"><input class="ref" placeholder="Transaction id / note" style="flex:2 1 200px"><button class="btn btn-primary" data-act="refund-complete">Record refund sent</button></div>' : `<div class="faint">Reference: ${escapeHtml(p.reference)}</div>`}</div>`).join('') : '<div class="card empty-state">No refunds owed.</div>';
  },
  async reversals() {
    const { submissions } = await apiRequest('/payments/unavailable');
    const head = '<p class="hint">Approved videos the system could no longer find. Review each one, then reverse the reward if it breaks the campaign rules. Nothing is reversed automatically.</p>';
    return head + (submissions.length ? submissions.map((s) => `<div class="card campaign-card" data-id="${s._id}"><div class="top"><div><a href="${escapeHtml(s.videoUrl)}" target="_blank" rel="noopener noreferrer">${platformLabel(s.platform)} clip</a> · ${escapeHtml(whoIs(s.creator))}
      <div class="faint">${escapeHtml(s.campaign ? s.campaign.title : '')} · missing since ${fmtDate(s.unavailableSince)} · reward ${formatCents(s.payoutAmount)}</div></div></div>
      <div class="card-actions"><input class="why" placeholder="Reason (min 5 characters)" style="flex:2 1 200px"><button class="btn btn-danger" data-act="reverse-reward">Reverse reward</button></div></div>`).join('') : '<div class="card empty-state">No approved videos are flagged.</div>');
  },
  async ledger() {
    const { transactions } = await apiRequest('/payments/ledger');
    return `<div class="card">${transactions.map((t) => `<div class="pay-row"><div><strong class="num">${t.amount < 0 ? '-' : '+'}${formatCents(Math.abs(t.amount))}</strong> · ${escapeHtml(t.type)} · ${escapeHtml(whoIs(t.user))}</div><span class="faint">${fmtDate(t.createdAt)}</span>
      <div class="id">${escapeHtml(t.description || '')}${t.campaign ? ' · ' + escapeHtml(t.campaign.title) : ''}${t.providerTransactionId ? ' · ' + escapeHtml(t.provider) + ' ' + escapeHtml(t.providerTransactionId) : ''}${t.relatedTransaction ? ' · linked to ' + escapeHtml(String(t.relatedTransaction).slice(-6)) : ''}</div></div>`).join('')}</div>`;
  },
  async brands() {
    const { brands } = await apiRequest('/payments/brands');
    return brands.length ? brands.map((b) => `<div class="card campaign-card" data-id="${b._id}"><div class="top"><div><strong>${escapeHtml(b.brandProfile.companyName)}</strong>
      <div class="faint">${escapeHtml(b.brandProfile.contactName)} · ${escapeHtml(b.brandProfile.businessEmail)} · ${escapeHtml(b.brandProfile.country)}${b.brandProfile.website ? ' · ' + escapeHtml(b.brandProfile.website) : ''}</div></div>
      <span class="badge badge-${b.brandProfile.status === 'active' ? 'approved' : 'rejected'}">${b.brandProfile.status}</span></div>
      <div class="card-actions"><button class="btn btn-secondary" data-act="brand-status" data-to="${b.brandProfile.status === 'active' ? 'suspended' : 'active'}">${b.brandProfile.status === 'active' ? 'Suspend' : 'Reactivate'}</button></div></div>`).join('') : '<div class="card empty-state">No brand accounts yet.</div>';
  },
  async check() {
    const r = await apiRequest('/payments/reconcile');
    const lines = [...r.mismatches.map((m) => `Creator @${escapeHtml(m.username)}: balance ${formatCents(m.balance)} but ledger says ${formatCents(m.ledger)}`), ...r.campaignIssues.map((c) => `Campaign “${escapeHtml(c.title)}”: spent ${formatCents(c.budgetSpent)}, ledger rewards ${formatCents(c.ledgerRewards)}, funded ${formatCents(c.fundedAmount)}`)];
    return `<div class="card"><p>${r.creatorsChecked} creator balances compared with the ledger.</p>${lines.length ? `<p class="hint">Problems found:</p>${lines.map((l) => `<div class="pay-row"><div>${l}</div></div>`).join('')}` : '<p><span class="badge badge-approved">All balances match the ledger</span></p>'}</div>`;
  },
};

async function show(name) {
  document.querySelectorAll('.tab').forEach((t) => t.classList.toggle('active', t.dataset.tab === name));
  panel().innerHTML = loadingHtml('Loading…'); panel().dataset.tab = name;
  try { panel().innerHTML = await TABS[name](); } catch (err) { showState(panel(), err, () => show(name)); }
}

async function onClick(e) {
  const btn = e.target.closest('[data-act]'); if (!btn) return;
  const card = btn.closest('[data-id]'); const id = card.dataset.id; const act = btn.dataset.act;
  hideAlert($('pay-alert'));
  let body;
  if (act === 'pay-reward') { if (!confirm('Mark this approved creator payment as paid and move it from Pending to Available balance?')) return; body = { submissionId: id }; }
  if (act === 'payout-send') { if (!confirm('Ask NOWPayments to send this payout now? A 2FA code is needed afterwards.')) return; body = { withdrawalId: id }; }
  if (act === 'payout-verify') { body = { withdrawalId: id, code: card.querySelector('.code').value.trim() }; }
  if (act === 'payout-sync') body = { withdrawalId: id };
  if (act === 'refund-complete') body = { paymentId: id, reference: card.querySelector('.ref').value };
  if (act === 'reverse-reward') { body = { submissionId: id, reason: card.querySelector('.why').value }; if (!confirm('Reverse this reward? The creator balance is reduced (it can go below zero) and the campaign budget is restored.')) return; }
  if (act === 'brand-status') body = { userId: id, status: btn.dataset.to };
  setLoading(btn, true, 'Working…');
  try { await post(act, body); note('Done.', 'success'); await show(panel().dataset.tab); }
  catch (err) { note(err.message); setLoading(btn, false); }
}

document.addEventListener('DOMContentLoaded', async () => {
  const user = await requireLogin();
  if (!user || user.role !== 'admin') return;
  document.querySelectorAll('.tab').forEach((t) => t.addEventListener('click', () => show(t.dataset.tab)));
  panel().addEventListener('click', onClick);
  show('payouts');
});
