// js/admin.js - admin page: tabs, campaign management, withdrawals, support tickets.
// The submission review queue lives in js/submissions.js (loadAdminQueue); payouts and funding are on admin-payments.html.
(function () {
  const $ = (id) => document.getElementById(id);
  const alertEl = () => $('admin-alert');
  const dollarsToCents = (v) => Math.round(parseFloat(v) * 100);
  const loaded = {};

  /* ---------- tabs ---------- */
  const LOADERS = { campaigns: loadCampaigns, submissions: loadAdminQueue, withdrawals: loadWithdrawals, support: loadTickets };

  function showTab(name) {
    if (!LOADERS[name]) name = 'campaigns';
    document.querySelectorAll('.tab[data-tab]').forEach((t) => {
      const on = t.dataset.tab === name;
      t.classList.toggle('active', on);
      t.setAttribute('aria-selected', String(on));
    });
    document.querySelectorAll('.tab-panel').forEach((p) => { p.hidden = p.id !== `tab-${name}`; });
    if (history.replaceState) history.replaceState(null, '', `#${name}`);
    LOADERS[name]();
  }

  /* ---------- campaigns ---------- */
  function buildPlatformChecks() {
    $('c-platforms').innerHTML = CTE_CONFIG.PLATFORMS.map((p, i) =>
      `<label class="consent"><input type="checkbox" name="c-plat" value="${p.value}" ${i === 0 ? 'checked' : ''}><span>${escapeHtml(p.label)}</span></label>`).join('');
  }

  async function loadCampaigns() {
    const list = $('campaign-list');
    list.innerHTML = loadingHtml('Loading campaigns…');
    try {
      const { campaigns } = await apiRequest('/campaigns?all=1');
      if (!campaigns.length) { list.innerHTML = '<div class="empty-state">No campaigns yet.</div>'; return; }
      list.innerHTML = campaigns.map((c) => {
        const open = ['draft', 'active', 'paused'].includes(c.status);
        return `<div class="card campaign-card" data-id="${c._id}">
          <div class="panel-head"><div><strong>${escapeHtml(c.title)}</strong> <span class="faint">· ${escapeHtml(c.brandName || 'Platform')} · ${(c.platforms || []).map(platformLabel).join(', ')}</span></div>
            <span class="badge badge-${c.status === 'active' ? 'approved' : c.status === 'cancelled' ? 'rejected' : 'pending'}">${escapeHtml(c.status)}</span></div>
          <div class="faint">Budget ${formatCents(c.budgetTotal)} · Funded ${formatCents(c.fundedAmount)} (${escapeHtml(c.fundingStatus)}) · Spent ${formatCents(c.budgetSpent)} · ${c.participantCount} joined · ${rewardAmount(c)} ${rewardUnit(c)}</div>
          ${open ? `<div class="card-actions">
            ${c.status === 'active' ? '<button class="btn btn-secondary" data-set="paused">Pause</button>' : '<button class="btn btn-secondary" data-set="active">Set active</button>'}
            <button class="btn btn-secondary" data-set="completed">Mark completed</button></div>` : ''}</div>`;
      }).join('');
      list.querySelectorAll('[data-set]').forEach((btn) => btn.addEventListener('click', async () => {
        const id = btn.closest('[data-id]').dataset.id;
        hideAlert(alertEl());
        setLoading(btn, true, 'Saving…');
        try { await apiRequest(`/campaigns/${id}`, { method: 'PATCH', body: { status: btn.dataset.set } }); await loadCampaigns(); }
        catch (err) { showAlert(alertEl(), err.message); setLoading(btn, false); }
      }));
    } catch (err) { showState(list, err, loadCampaigns); }
  }

  function bindCampaignForm() {
    const form = $('campaign-form');
    form.addEventListener('submit', async (e) => {
      e.preventDefault();
      const btn = form.querySelector('button[type="submit"]');
      const platforms = [...form.querySelectorAll('input[name="c-plat"]:checked')].map((i) => i.value);
      const body = {
        title: $('c-title').value.trim(), brandName: $('c-brand').value.trim(), description: $('c-desc').value.trim(),
        payoutPerThousandViews: dollarsToCents($('c-rate').value), budgetTotal: dollarsToCents($('c-budget').value),
        platforms, requirements: $('c-req').value.trim(),
      };
      hideAlert(alertEl());
      setLoading(btn, true, 'Creating…');
      try {
        await apiRequest('/campaigns', { method: 'POST', body });
        form.reset();
        buildPlatformChecks();
        showAlert(alertEl(), 'Campaign created. It is funded by the platform and live for creators.', 'success');
        await loadCampaigns();
      } catch (err) { showAlert(alertEl(), err.message); }
      finally { setLoading(btn, false); }
    });
  }

  /* ---------- withdrawals ---------- */
  async function loadWithdrawals() {
    const list = $('withdrawal-list');
    list.innerHTML = loadingHtml('Loading withdrawals…');
    try {
      const status = $('w-filter').value;
      const { withdrawals } = await apiRequest(`/withdrawals?all=1${status ? `&status=${status}` : ''}`);
      if (!withdrawals.length) { list.innerHTML = '<div class="empty-state">No withdrawals here.</div>'; return; }
      list.innerHTML = withdrawals.map((w) => {
        const net = typeof w.netAmount === 'number' ? w.netAmount : w.amount;
        const fee = typeof w.feeAmount === 'number' ? w.feeAmount : 0;
        const open = ['pending', 'processing'].includes(w.status);
        const crypto = w.method === 'crypto';
        const stuck = open && w.payoutRequestedAt && !w.providerBatchId && Date.now() - new Date(w.payoutRequestedAt).getTime() > 5 * 60 * 1000;
        const manual = !crypto || w.needsReview || stuck; // crypto payouts are otherwise handled through NOWPayments
        return `<div class="card campaign-card" data-id="${w._id}">
          <div class="panel-head"><div><strong class="num">Send ${formatCents(net)}</strong> <span class="faint">(withdrawal ${formatCents(w.amount)} − fee ${formatCents(fee)})</span>
            <div class="faint">${escapeHtml(whoIs(w.user))} · ${crypto ? `${escapeHtml(w.cryptoCurrency || '')} (${escapeHtml(w.network || '')})` : 'PayPal'} · ${fmtDate(w.createdAt)}</div></div>
            <span class="badge badge-${w.status === 'completed' ? 'approved' : ['failed', 'cancelled'].includes(w.status) ? 'rejected' : 'pending'}">${escapeHtml(w.status)}</span></div>
          <div class="faint" style="overflow-wrap:anywhere">To: ${escapeHtml(w.destination)}</div>
          ${w.failureReason ? `<p class="hint">${escapeHtml(w.failureReason)}</p>` : ''}
          ${open && !manual ? '<p class="hint">Crypto payouts are sent from <a href="admin-payments.html">Payments &amp; payouts</a>.</p>' : ''}
          ${open && manual ? `<div class="card-actions">
            ${w.status === 'pending' && !crypto ? '<button class="btn btn-secondary" data-set="processing">Mark processing</button>' : ''}
            <button class="btn btn-primary" data-set="completed">Mark paid</button>
            <button class="btn btn-danger" data-set="failed">Fail &amp; refund</button>
            <button class="btn btn-secondary" data-set="cancelled">Cancel &amp; refund</button></div>` : ''}</div>`;
      }).join('');
      list.querySelectorAll('[data-set]').forEach((btn) => btn.addEventListener('click', async () => {
        const id = btn.closest('[data-id]').dataset.id;
        const status = btn.dataset.set;
        const body = { status };
        if (status === 'failed') { body.failureReason = (prompt('Reason shown to the creator:') || '').trim(); if (!body.failureReason) return; }
        if (['failed', 'cancelled'].includes(status) && !confirm('The full withdrawal amount (including the fee) is returned to the creator. Continue?')) return;
        hideAlert(alertEl());
        setLoading(btn, true, 'Saving…');
        try { await apiRequest(`/withdrawals/${id}`, { method: 'PATCH', body }); await loadWithdrawals(); }
        catch (err) { showAlert(alertEl(), err.message); setLoading(btn, false); }
      }));
    } catch (err) { showState(list, err, loadWithdrawals); }
  }

  /* ---------- support tickets ---------- */
  let openTicket = null;

  async function loadTickets() {
    const list = $('admin-ticket-list');
    list.innerHTML = loadingHtml('Loading tickets…');
    try {
      const { tickets } = await apiRequest('/support?all=1');
      if (!tickets.length) { list.innerHTML = '<div class="empty-state">No tickets.</div>'; return; }
      list.innerHTML = tickets.map((t) => `<div class="ticket-item${openTicket === t._id ? ' active' : ''}" data-id="${t._id}">
        <div><div class="t-subject">${escapeHtml(t.subject)}</div><div class="t-meta">${escapeHtml(whoIs(t.user))} · ${escapeHtml(t.category)} · ${fmtDate(t.updatedAt)}</div></div>
        <span class="badge badge-${t.status === 'open' ? 'pending' : t.status === 'in_progress' ? 'pending' : 'approved'}">${escapeHtml(t.status.replace('_', ' '))}</span></div>`).join('');
      list.querySelectorAll('.ticket-item').forEach((el) => el.addEventListener('click', () => showTicket(el.dataset.id)));
    } catch (err) { showState(list, err, loadTickets); }
  }

  async function showTicket(id) {
    try {
      const { ticket } = await apiRequest(`/support?id=${encodeURIComponent(id)}`);
      openTicket = ticket._id;
      $('admin-thread').hidden = false;
      $('admin-thread-subject').textContent = ticket.subject;
      $('admin-ticket-status').value = ticket.status;
      $('admin-thread-messages').innerHTML = ticket.messages.map((m) =>
        `<div class="msg ${m.sender === 'admin' ? 'mine' : ''}">${escapeHtml(m.body)}<small>${m.sender === 'admin' ? 'Support' : escapeHtml(whoIs(ticket.user))} · ${fmtDate(m.createdAt)}</small></div>`).join('');
      document.querySelectorAll('#admin-ticket-list .ticket-item').forEach((el) => el.classList.toggle('active', el.dataset.id === id));
    } catch (err) { showAlert(alertEl(), err.message); }
  }

  function bindTicketControls() {
    $('admin-ticket-status').addEventListener('change', async (e) => {
      try { await apiRequest('/support', { method: 'PATCH', body: { ticketId: openTicket, status: e.target.value } }); loadTickets(); }
      catch (err) { showAlert(alertEl(), err.message); }
    });
    $('admin-reply-form').addEventListener('submit', async (e) => {
      e.preventDefault();
      const btn = e.target.querySelector('button[type="submit"]');
      const message = $('admin-reply').value.trim();
      if (!message || !openTicket) return;
      setLoading(btn, true, 'Sending…');
      try { await apiRequest('/support', { method: 'POST', body: { ticketId: openTicket, message } }); $('admin-reply').value = ''; await showTicket(openTicket); }
      catch (err) { showAlert(alertEl(), err.message); }
      finally { setLoading(btn, false); }
    });
  }

  document.addEventListener('DOMContentLoaded', async () => {
    const admin = await requireAdmin();
    if (!admin) return;
    buildPlatformChecks();
    bindCampaignForm();
    bindTicketControls();
    $('w-filter').addEventListener('change', loadWithdrawals);
    document.querySelectorAll('.tab[data-tab]').forEach((t) => t.addEventListener('click', () => showTab(t.dataset.tab)));
    showTab(location.hash.replace('#', '') || 'campaigns');
  });
})();
