(function(){
  const $=id=>document.getElementById(id);
  function short(n){return Number(n||0).toLocaleString(undefined,{notation:'compact',maximumFractionDigits:1});}
  async function loadAnalytics(){
    if(!$('views-chart')) return;
    try{
      const d=await apiRequest('/analytics?days=7');
      $('analytics-views').textContent=`${short(d.summary.currentTotalViews)} total views`;
      $('analytics-gained').textContent=Number(d.summary.views||0).toLocaleString();
      $('analytics-approved').textContent=Number(d.summary.approvedClips||0).toLocaleString();
      $('analytics-earned').textContent=formatCents(d.summary.earned||0);
      if($('view-streak-level')) $('view-streak-level').textContent=`🔥 ${Number(d.streak?.level||0)}`;
      if($('view-streak-text')) $('view-streak-text').textContent=`${short(d.streak?.lifetimeViews||0)} views · next milestone ${short(d.streak?.nextMilestone||0)} (${Number(d.streak?.progress||0)}%)`;
      if($('view-streak-bar')) $('view-streak-bar').style.width=`${Math.max(0,Math.min(100,Number(d.streak?.progress||0)))}%`;
      const rows=d.chart||[]; const max=Math.max(1,...rows.map(x=>Number(x.viewsGained||0)));
      $('views-chart').innerHTML=rows.map(x=>`<div class="view-bar" title="${x.date}: ${Number(x.viewsGained||0).toLocaleString()} views"><span class="view-bar-value">${short(x.viewsGained)}</span><span class="view-bar-fill" style="height:${Math.max(2,Math.round((Number(x.viewsGained||0)/max)*130))}px"></span><span class="view-bar-label">${new Date(`${x.date}T00:00:00Z`).toLocaleDateString(undefined,{weekday:'short'})}</span></div>`).join('');
    }catch(err){ $('views-chart').innerHTML=`<div class="empty-state">Analytics are temporarily unavailable.</div>`; }
  }
  document.addEventListener('DOMContentLoaded',loadAnalytics);
})();
