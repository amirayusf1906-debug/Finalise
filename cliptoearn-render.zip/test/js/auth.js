// js/auth.js - login, register, logout, and route guarding

// One /profile request per page load, shared by every caller.
let _userPromise;
function requireLogin() {
  if (!_userPromise) {
    _userPromise = apiRequest('/profile').then((d) => d.user).catch((e) => {
      if (e.status !== 401) { // network/server problem: keep the session, tell the person
        document.body.style.visibility = '';
        const box = document.createElement('div');
        box.className = 'container';
        box.innerHTML = `<div class="state-error" role="alert"><span>${escapeHtml(e.message)}</span><button class="btn btn-secondary reload-btn" type="button">Reload</button></div>`;
        box.querySelector('.reload-btn').addEventListener('click', () => location.reload());
        document.body.prepend(box);
      }
      return null; // 401 is already handled by apiRequest (clear + redirect)
    });
  }
  return _userPromise;
}

async function requireAdmin() {
  const user = await requireLogin();
  if (user && user.role !== 'admin') { location.replace(homeFor(user)); return null; }
  return user;
}

// Creator pages are for creators: admins and brands who land on one are sent to their own page.
async function requireCreator() {
  const user = await requireLogin();
  if (user && user.role !== 'creator') { location.replace(homeFor(user)); return null; }
  return user;
}

async function requireBrand() {
  const user = await requireLogin();
  if (user && user.role !== 'brand') { location.replace(homeFor(user)); return null; }
  return user;
}

const homeFor = (user) => (user && user.role === 'admin' ? 'admin.html' : user && user.role === 'brand' ? 'brand.html' : 'dashboard.html');

// Login/register pages: someone who is already signed in goes straight to their home page.
function redirectIfSignedIn() {
  apiRequest('/profile').then((d) => location.replace(homeFor(d.user))).catch(() => { /* not signed in: stay */ });
}

// Pages opt in with <body data-guard="creator|admin">; content stays hidden until the session is verified.
function guardPage() {
  const guard = document.body.dataset.guard;
  if (!guard) return;
  document.body.style.visibility = 'hidden';
  (guard === 'admin' ? requireAdmin() : guard === 'brand' ? requireBrand() : guard === 'any' ? requireLogin() : requireCreator()).then((u) => { if (u) { document.body.style.visibility = ''; showVerifyBanner(u); } });
  window.addEventListener('pageshow', (e) => { if (e.persisted) location.reload(); }); // back button after logout
}

// Creators and brands must confirm their email before money can move. Shown on every guarded page until they do.
function showVerifyBanner(user) {
  if (!user || user.role === 'admin' || user.emailVerified) return;
  const bar = document.createElement('div');
  bar.className = 'verify-banner';
  bar.innerHTML = '<span>Confirm your email to unlock withdrawals. We sent a link to <strong></strong>.</span><button type="button" class="btn btn-secondary">Resend link</button>';
  bar.querySelector('strong').textContent = user.email || 'your inbox';
  const btn = bar.querySelector('button');
  btn.addEventListener('click', async () => {
    setLoading(btn, true, 'Sending…');
    try { const d = await apiRequest('/auth/resend-verification', { method: 'POST' }); bar.firstChild.textContent = d.alreadyVerified ? 'Your email is already confirmed. Reload the page.' : 'Link sent. Check your inbox and spam folder. '; }
    catch (e) { bar.firstChild.textContent = e.message + ' '; }
    setLoading(btn, false);
  });
  document.body.prepend(bar);
}

function bindLoginForm() {
  const form = document.getElementById('login-form');
  if (!form) return;
  const alertEl = document.getElementById('login-alert');
  redirectIfSignedIn();

  form.addEventListener('submit', async (e) => {
    e.preventDefault();
    const identifier = document.getElementById('identifier').value.trim();
    const password = document.getElementById('password').value;
    const btn = form.querySelector('button[type="submit"]');
    setLoading(btn, true, 'Logging in…');

    try {
      const { user } = await apiRequest('/auth/login', { method: 'POST', body: { identifier, password } });
      window.location.href = homeFor(user);
    } catch (err) {
      showAlert(alertEl, err.status === 401 ? 'Wrong username/email or password. Check both and try again.' : err.message);
      setLoading(btn, false);
    }
  });
}

function bindRegisterForm() {
  const form = document.getElementById('register-form');
  if (!form) return;
  const alertEl = document.getElementById('register-alert');
  redirectIfSignedIn();
  const termsBox = document.getElementById('accept-terms');
  const privacyBox = document.getElementById('accept-privacy');
  const submitBtn = document.getElementById('register-btn');
  // The button stays disabled until both boxes are ticked (the server checks this too).
  const syncConsent = () => { submitBtn.disabled = !(termsBox.checked && privacyBox.checked); };
  termsBox.addEventListener('change', syncConsent);
  privacyBox.addEventListener('change', syncConsent);
  syncConsent();
  // register.html?type=brand turns the form into a brand sign-up
  const isBrand = new URLSearchParams(location.search).get('type') === 'brand';
  if (isBrand) {
    document.getElementById('brand-fields').hidden = false;
    document.getElementById('reg-title').textContent = 'Create a brand account';
    document.getElementById('reg-sub').textContent = 'Fund campaigns and get clips from creators.';
    document.getElementById('type-switch').innerHTML = '<a href="register.html">Registering as a creator?</a>';
  }
  const usernameInput = document.getElementById('username');
  const usernameCheck = document.getElementById('username-check');

  let debounceTimer;
  usernameInput.addEventListener('input', () => {
    clearTimeout(debounceTimer);
    const val = usernameInput.value.trim();
    if (val.length < 3) {
      usernameCheck.textContent = '';
      return;
    }
    debounceTimer = setTimeout(async () => {
      try {
        const { available } = await apiRequest(`/auth/username?username=${encodeURIComponent(val)}`);
        usernameCheck.textContent = available ? 'Username available' : 'Username already taken';
        usernameCheck.className = `username-check ${available ? 'available' : 'taken'}`;
      } catch (e) {
        usernameCheck.textContent = '';
      }
    }, 350);
  });

  form.addEventListener('submit', async (e) => {
    e.preventDefault();
    const username = usernameInput.value.trim();
    const email = document.getElementById('email').value.trim();
    const password = document.getElementById('password').value;
    const btn = form.querySelector('button[type="submit"]');
    if (!termsBox.checked || !privacyBox.checked) return showAlert(alertEl, 'Please accept the Terms of Service and the Privacy Policy to continue.');
    setLoading(btn, true, 'Creating account…');

    try {
      const body = { username, email, password, acceptTerms: termsBox.checked, acceptPrivacy: privacyBox.checked };
      if (isBrand) {
        body.accountType = 'brand';
        const v = (id) => document.getElementById(id).value.trim();
        body.brand = { companyName: v('b-company'), contactName: v('b-contact'), businessEmail: v('b-email'), country: v('b-country'), website: v('b-website') };
      }
      await apiRequest('/auth/register', { method: 'POST', body });
      window.location.href = isBrand ? 'brand.html' : 'dashboard.html';
    } catch (err) {
      showAlert(alertEl, err.message);
      setLoading(btn, false);
      syncConsent();
    }
  });
}

function bindLogoutButton() {
  const btn = document.getElementById('logout-btn');
  if (!btn) return;
  btn.addEventListener('click', async () => {
    setLoading(btn, true, 'Logging out…');
    await apiRequest('/auth/logout', { method: 'POST' }).catch(() => {});
    clearSession();
    location.replace('login.html');
  });
}

document.addEventListener('DOMContentLoaded', () => {
  bindLoginForm();
  bindRegisterForm();
  bindLogoutButton();
  guardPage();
});
