// js/brand.js - Brand dashboard: create campaigns, fund them, see status, budget and results.
// Money rule shown to the brand: a campaign only goes live after NOWPayments CONFIRMS the payment.
let campaigns = [];
const $ = (id) => document.getElementById(id);
const alertEl = () => $('brand-alert');
const dollarsToCents = (v) => Math.round(parseFloat(v) * 100);
let PLATFORM_FEE_PERCENT = 10; // display only: replaced with the server value (lib/fees.js) when the page loads

function statusInfo(c) {
  if (c.status === 'cancelled') return c.fundingStatus === 'refund_owed' ? ['Cancelled · refund owed', 'pending'] : c.fundingStatus === 'refunded' ? ['Cancelled · refunded', 'closed'] : ['Cancelled', 'closed'];
  if (c.status === 'completed') return ['Closed', 'closed'];
  if (c.status === 'active') return ['Active', 'active'];
  if (c.status === 'paused') return ['Paused', 'pending'];
  if (c.fundingStatus === 'funded') return ['Campaign Funded', 'approved'];
  if (c.fundingStatus === 'pending') return ['Payment Pending', 'pending'];
  if (c.fundingStatus === 'failed') return ['Funding Failed', 'rejected'];
  return ['Draft · Funding Required', 'pending'];
}

async function loadBrandWallet() {
  try {
    const { user } = await apiRequest('/profile');
    const el = $('brand-balance');
    if (el) el.textContent = formatCents(user.brandBalance || 0);
  } catch (_) {}
}

function renderOverview() {
  const live = campaigns.filter((c) => c.status === 'active').length;
  const draft = campaigns.filter((c) => c.status === 'draft').length;
  const funded = campaigns.filter((c) => (c.fundedAmount || 0) > 0).length;
  const totalFunded = campaigns.reduce((s, c) => s + (c.fundedAmount || 0), 0);
  const remaining = campaigns.filter((c) => ['active', 'paused', 'draft'].includes(c.status)).reduce((s, c) => s + (c.remainingBudget || 0), 0);
  const card = (k, v) => `<div class="card stat-card"><div class="label">${k}</div><div class="value num">${v}</div></div>`;
  $('overview').innerHTML = card('Active campaigns', live) + card('Draft campaigns', draft) + card('Funded campaigns', funded) + card('Total funded', formatCents(totalFunded)) + card('Remaining budget', formatCents(remaining));
}

function renderCampaigns() {
  const list = $('campaign-list');
  if (!campaigns.length) { list.innerHTML = '<div class="card empty-state">No campaigns yet. Open “Create campaign” to start.</div>'; return; }
  list.innerHTML = campaigns.map((c) => {
    const [label, tone] = statusInfo(c);
    const unfunded = c.status === 'draft' && ['unfunded', 'failed', 'pending'].includes(c.fundingStatus);
    const editable = c.status === 'draft' && ['unfunded', 'failed'].includes(c.fundingStatus);
    const goLive = ['draft', 'paused'].includes(c.status) && c.fundingStatus === 'funded';
    const cancellable = ['draft', 'active', 'paused'].includes(c.status);
    return `<div class="card campaign-card" data-id="${c._id}">
      <div class="top"><div><h3>${escapeHtml(c.title)}</h3><div class="faint">${(c.platforms || []).map(platformLabel).join(', ')}${c.deadline ? ` · new clips until ${fmtDate(c.deadline)}` : ''}</div></div>
        <span class="badge badge-${tone}">${label}</span></div>
      <div class="cmeta">
        <div><div class="k">Total budget</div><div class="v num">${formatCents(c.budgetTotal)}</div></div>
        ${unfunded ? `<div><div class="k">You pay (budget + ${formatCents(c.platformFee)} fee)</div><div class="v num">${formatCents(c.totalCharge)}</div></div>` : ''}
        <div><div class="k">Reward per creator</div><div class="v num">${formatCents(c.rewardPerCreator)}</div></div>
        <div><div class="k">Rewards supported</div><div class="v num">${c.maxRewards}</div></div>
        <div><div class="k">Funded</div><div class="v num">${formatCents(c.fundedAmount)}</div></div>
        <div><div class="k">Remaining budget</div><div class="v num">${formatCents(c.remainingBudget)}</div></div>
      </div>
      ${c.fundingStatus === 'refund_owed' ? `<p class="hint">Unused funded amount of ${formatCents(c.refundOwed)} is owed back to you. The Clip-to-Earn team will send it and record the reference under Payments.</p>` : ''}
      <div class="card-actions">
        ${unfunded ? `<button class="btn btn-primary" data-act="fund">${c.fundingStatus === 'pending' ? 'Continue payment' : 'Fund Campaign'}</button>` : ''}
        ${goLive ? '<button class="btn btn-primary" data-act="activate">Go live</button>' : ''}
        ${c.status === 'active' ? '<button class="btn btn-secondary" data-act="pause">Pause</button>' : ''}
        ${editable ? '<button class="btn btn-secondary" data-act="edit">Edit draft</button>' : ''}
        <button class="btn btn-secondary" data-act="results">Results</button>
        ${cancellable ? '<button class="btn btn-danger" data-act="cancel">Cancel</button>' : ''}
      </div>
      <div class="subs" hidden></div></div>`;
  }).join('');
}

async function load() {
  try {
    ({ campaigns } = await apiRequest('/campaigns'));
    renderOverview(); renderCampaigns();
    loadBrandWallet();
    // While a payment is being confirmed, keep checking so "Payment Pending" turns into "Campaign Funded" on its own.
    clearTimeout(load.timer);
    if (campaigns.some((c) => c.fundingStatus === 'pending')) load.timer = setTimeout(load, 15000);
  } catch (err) { showState($('campaign-list'), err, load); }
}

async function loadPayments() {
  const el = $('payment-list');
  el.innerHTML = loadingHtml('Loading payments…');
  try {
    const { payments } = await apiRequest('/payments/list');
    if (!payments.length) { el.innerHTML = '<div class="card empty-state">No payments yet.</div>'; return; }
    const nice = { created: 'Payment Pending', pending: 'Payment Pending', funded: 'Funded', failed: 'Funding Failed', expired: 'Expired', partially_paid: 'Partially paid, contact support', refunded: 'Refunded by provider', cancelled: 'Cancelled', owed: 'Refund owed to you', completed: 'Refund sent' };
    const tone = { funded: 'approved', completed: 'approved', failed: 'rejected', expired: 'rejected' };
    el.innerHTML = `<div class="card">${payments.map((p) => `<div class="pay-row">
      <div><strong class="num">${formatCents(p.amount)}</strong> · ${p.type === 'brand_deposit' ? 'Brand deposit' : p.type === 'campaign_refund' ? 'Refund' : 'Campaign funding'} · ${escapeHtml(p.campaign ? p.campaign.title : '')}${typeof p.platformFee === 'number' ? `<div class="faint">Campaign budget ${formatCents(p.creatorBudget)} + platform fee ${formatCents(p.platformFee)}</div>` : ''}</div>
      <span class="badge badge-${tone[p.status] || 'pending'}">${nice[p.status] || p.status}</span>
      <div class="id">${fmtDate(p.createdAt)}${p.providerPaymentId ? ` · Provider transaction ID: ${escapeHtml(p.providerPaymentId)}` : ''}${p.reference ? ` · Refund reference: ${escapeHtml(p.reference)}` : ''}</div></div>`).join('')}</div>`;
  } catch (err) { showState(el, err, loadPayments); }
}

async function showResults(card, id) {
  const box = card.querySelector('.subs');
  if (!box.hidden) { box.hidden = true; return; }
  box.hidden = false; box.innerHTML = loadingHtml('Loading results…');
  try {
    const { submissions } = await apiRequest(`/submissions?campaignId=${id}`);
    box.innerHTML = submissions.length ? submissions.map((s) => `<div class="row"><span>${platformLabel(s.platform)} · <a href="${escapeHtml(s.videoUrl)}" target="_blank" rel="noopener noreferrer">view clip</a></span><span>${s.views || 0} views · ${s.status}</span></div>`).join('') : '<div class="faint">No submissions yet.</div>';
  } catch (err) { box.innerHTML = `<div class="faint">${escapeHtml(err.message)}</div>`; }
}

async function onAction(e) {
  const btn = e.target.closest('[data-act]');
  if (!btn) return;
  const card = btn.closest('[data-id]'); const id = card.dataset.id; const act = btn.dataset.act;
  const c = campaigns.find((x) => x._id === id);
  hideAlert(alertEl());
  if (act === 'results') return showResults(card, id);
  if (act === 'edit') return startEdit(c);
  if (act === 'fund' && !confirm(`You will pay ${formatCents(c.totalCharge)}: the ${formatCents(c.budgetTotal)} campaign budget plus a ${formatCents(c.platformFee)} platform fee. Only the campaign budget goes to creators. Continue?`)) return;
  if (act === 'cancel' && !confirm(c.fundedAmount > 0 ? `Cancel this campaign? The unused ${formatCents(c.remainingBudget)} of the campaign budget will be recorded as owed back to you. The platform fee is not refunded. Rewards already paid to creators stay paid.` : 'Cancel this campaign?')) return;
  setLoading(btn, true, 'Working…');
  try {
    if (act === 'fund') {
      const funded = await apiRequest('/payments/fund', { method: 'POST', body: { campaignId: id } });
      if (funded.fundedFromWallet) { showAlert(alertEl(), 'Campaign funded from your ClipToEarn wallet.', 'success'); await load(); return; }
      window.location.href = funded.invoiceUrl; // NOWPayments hosted payment page. Funding is confirmed by their server message, not by coming back here.
      return;
    }
    await apiRequest(`/campaigns/${id}`, { method: 'PATCH', body: { action: act } });
    await load();
  } catch (err) { showAlert(alertEl(), err.message); setLoading(btn, false); }
}

/* ---------- create / edit draft ---------- */
function updateCalc() {
  const b = dollarsToCents($('f-budget').value), r = dollarsToCents($('f-reward').value);
  const fee = Math.round(b * PLATFORM_FEE_PERCENT / 100); // preview only: the server calculates the real fee with lib/fees.js
  $('calc').innerHTML = b > 0 && r > 0 && r <= b ? `Your budget supports up to <strong>${Math.floor(b / r)}</strong> approved creator rewards (${formatCents(b)} ÷ ${formatCents(r)}). Platform fee (${PLATFORM_FEE_PERCENT}%): ${formatCents(fee)}. You pay <strong>${formatCents(b + fee)}</strong> to fund it.` : 'Enter a budget and a reward to see how many creators you can pay.';
}
function resetForm() { $('campaign-form').reset(); $('edit-id').value = ''; $('save-btn').textContent = 'Save as draft'; $('cancel-edit').hidden = true; updateCalc(); }
function startEdit(c) {
  switchTab('new');
  $('edit-id').value = c._id; $('f-title').value = c.title; $('f-desc').value = c.description || '';
  $('f-brief').value = c.campaignBrief || ''; $('f-materials').value = c.materialsUrl || ''; $('f-instructions').value = c.instructions || '';
  $('f-budget').value = (c.budgetTotal / 100).toFixed(2); $('f-reward').value = (c.rewardPerCreator / 100).toFixed(2);
  $('f-rules').value = c.requirements || '';
  $('f-min-followers').value = c.targeting?.minFollowers || 0;
  $('f-require-verified').checked = !!c.targeting?.requireVerified; $('f-deadline').value = c.deadline ? c.deadline.slice(0, 10) : '';
  document.querySelectorAll('input[name="plat"]').forEach((x) => { x.checked = (c.platforms || []).includes(x.value); });
  $('save-btn').textContent = 'Save changes'; $('cancel-edit').hidden = false; updateCalc();
}
async function saveCampaign(e) {
  e.preventDefault();
  const btn = $('save-btn'); hideAlert(alertEl());
  const body = {
    title: $('f-title').value, description: $('f-desc').value, campaignBrief: $('f-brief').value, materialsUrl: $('f-materials').value.trim(), instructions: $('f-instructions').value, requirements: $('f-rules').value,
    targeting: { minFollowers: Math.max(0, Number($('f-min-followers').value || 0)), requireVerified: $('f-require-verified').checked },
    totalBudget: dollarsToCents($('f-budget').value), rewardPerCreator: dollarsToCents($('f-reward').value),
    platforms: [...document.querySelectorAll('input[name="plat"]:checked')].map((x) => x.value),
  };
  if ($('f-deadline').value) body.deadline = $('f-deadline').value + 'T23:59:59Z'; else if ($('edit-id').value) body.deadline = null;
  setLoading(btn, true, 'Saving…');
  try {
    const id = $('edit-id').value;
    await apiRequest(id ? `/campaigns/${id}` : '/campaigns', { method: id ? 'PATCH' : 'POST', body });
    resetForm(); switchTab('campaigns'); await load();
    showAlert(alertEl(), id ? 'Draft updated.' : 'Draft created. Press “Fund Campaign” to pay for it. It goes live only after the payment is confirmed.', 'success');
  } catch (err) { showAlert(alertEl(), err.message); } finally { setLoading(btn, false); }
}

async function startDeposit() {
  const raw = prompt('Enter deposit amount in USD (minimum $20):');
  if (raw === null) return;
  const amount = Number(raw);
  if (!Number.isFinite(amount) || amount < 20) return showAlert(alertEl(), 'Enter a valid deposit of at least $20.');
  const btn = $('deposit-btn'); setLoading(btn, true, 'Creating payment…');
  try {
    const { invoiceUrl } = await apiRequest('/payments/deposit', { method: 'POST', body: { amount } });
    location.href = invoiceUrl;
  } catch (err) { showAlert(alertEl(), err.message); setLoading(btn, false); }
}

function switchTab(name) {
  document.querySelectorAll('.tab').forEach((t) => t.classList.toggle('active', t.dataset.tab === name));
  document.querySelectorAll('.tab-panel').forEach((p) => { p.hidden = p.id !== `tab-${name}`; });
  if (name === 'payments') loadPayments();
}

document.addEventListener('DOMContentLoaded', async () => {
  const user = await requireLogin();
  if (!user || user.role !== 'brand') return;
  if (user.fees) PLATFORM_FEE_PERCENT = user.fees.campaignFeePercent;
  $('brand-name').textContent = (user.brandProfile && user.brandProfile.companyName) || 'Your campaigns';
  if (user.brandProfile && user.brandProfile.status === 'suspended') showAlert(alertEl(), 'Your brand account is suspended. Contact support.');
  $('live-rule').textContent = LIVE_RULE;
  document.querySelectorAll('.tab').forEach((t) => t.addEventListener('click', () => switchTab(t.dataset.tab)));
  $('campaign-list').addEventListener('click', onAction);
  $('campaign-form').addEventListener('submit', saveCampaign);
  if ($('deposit-btn')) $('deposit-btn').addEventListener('click', startDeposit);
  $('cancel-edit').addEventListener('click', () => { resetForm(); switchTab('campaigns'); });
  $('f-budget').addEventListener('input', updateCalc); $('f-reward').addEventListener('input', updateCalc);
  if (new URLSearchParams(location.search).get('paid')) showAlert(alertEl(), 'Thanks. Your campaign is marked funded only after the payment network confirms it. This can take a few minutes. This page updates by itself.', 'success');
  if (new URLSearchParams(location.search).get('deposit')) showAlert(alertEl(), 'Deposit submitted. Your wallet updates after NOWPayments confirms the payment.', 'success');
  load();
});
