// js/campaign.js - campaign details -> join -> submit video (submission logic lives in submissions.js)
const campaignId = new URLSearchParams(location.search).get('id');
const root = () => document.getElementById('campaign-root');
const alertBox = () => document.getElementById('campaign-alert');

async function loadCampaign() {
  if (!campaignId) { root().innerHTML = '<div class="empty-state">No campaign selected. <a href="dashboard.html">Browse campaigns</a></div>'; return; }
  root().innerHTML = loadingHtml('Loading campaign…');
  try {
    const user = await requireLogin();
    if (!user) return;
    const [{ campaign }, { accounts }] = await Promise.all([
      apiRequest(`/campaigns/${encodeURIComponent(campaignId)}`),
      apiRequest('/socials'),
    ]);
    renderCampaign(campaign, accounts, user);
  } catch (err) {
    showState(root(), new Error(err.status === 404 ? 'This campaign does not exist or was removed.' : err.message), loadCampaign);
  }
}

function renderCampaign(c, accounts, user) {
  document.title = `${c.title} · ClipToEarn`;
  const joined = !!c.joined;
  const active = c.status === 'active';
  const usable = connectedPlatformsFor(c, accounts);
  const pct = c.budgetTotal ? Math.min(100, Math.round((c.budgetSpent / c.budgetTotal) * 100)) : 0;
  const need = c.platforms && c.platforms.length ? c.platforms.map(platformLabel).join(' or ') : 'a social account';

  const step = (done, label) => `<li class="${done ? 'done' : ''}"><span class="dot">${done ? '✓' : ''}</span>${label}</li>`;
  let action;
  if (!active) {
    action = '<p class="hint">This campaign is not accepting new clips right now.</p>';
  } else if (!usable.length) {
    action = `<p class="hint">Connect ${escapeHtml(need)} to ${joined ? 'submit clips to' : 'join'} this campaign.</p>
      <a class="btn btn-primary" href="socials.html">Connect account</a>`;
  } else if (!joined) {
    action = `<button id="join-btn" class="btn btn-primary">Join campaign</button>`;
  } else {
    action = `<form id="submit-form">
      <div class="form-group"><label for="sub-platform">Platform</label>
        <select id="sub-platform">${usable.map((p) => `<option value="${p}">${escapeHtml(platformLabel(p))}</option>`).join('')}</select></div>
      <div class="form-group"><label for="sub-url">Published TikTok video link</label>
        <input type="url" id="sub-url" placeholder="https://www.tiktok.com/@username/video/..." required></div>
      <button type="submit" class="btn btn-primary">Submit video</button></form>`;
  }

  root().innerHTML = `
  <div class="campaign-layout">
    <div class="card campaign-info">
      <div class="brand-name">${escapeHtml(c.brandName || 'Brand')}</div>
      <h1>${escapeHtml(c.title)}</h1>
      <div class="rate num">${rewardAmount(c)}<span class="unit"> ${rewardUnit(c)}</span></div>
      <p class="description">${escapeHtml(c.description || 'No description provided.')}</p>
      ${c.campaignBrief ? `<h3>Campaign Brief</h3><div class="requirements">${escapeHtml(c.campaignBrief)}</div>` : ''}
      ${c.materialsUrl ? `<h3>Campaign Materials</h3><p><a class="btn btn-secondary" href="${escapeHtml(c.materialsUrl)}" target="_blank" rel="noopener noreferrer">Open Campaign Materials</a></p>` : ''}
      ${c.instructions ? `<h3>Campaign Instructions</h3><div class="requirements">${escapeHtml(c.instructions)}</div>` : ''}
      ${c.requirements ? `<h3>Additional Requirements</h3><div class="requirements">${escapeHtml(c.requirements)}</div>` : ''}
      <p class="hint live-rule">${escapeHtml(LIVE_RULE)}</p>
      <h3>Accepted platforms</h3>
      <div class="platforms">${(c.platforms && c.platforms.length ? c.platforms : CTE_CONFIG.PLATFORMS.map((p) => p.value)).map((p) => {
        const on = accounts.some((a) => a.platform === p);
        return `<span class="platform-pill ${on ? 'on' : ''}">${on ? '✓ ' : ''}${escapeHtml(platformLabel(p))}</span>`;
      }).join('')}</div>
      <div class="budget-bar-track"><div class="budget-bar-fill" style="width:${pct}%"></div></div>
      <div class="budget-label">${formatCents(c.budgetSpent)} of ${formatCents(c.budgetTotal)} budget used</div>
    </div>
    <div class="card action-panel">
      <ol class="steps">${step(usable.length > 0, 'Connect an account')}${step(joined, 'Join campaign')}${step(false, 'Submit a video')}</ol>
      ${action}
    </div>
  </div>
  ${joined ? '<h2 class="section-title">Your clips in this campaign</h2><div class="card" id="campaign-submissions"></div>' : ''}`;

  const joinBtn = document.getElementById('join-btn');
  if (joinBtn) joinBtn.addEventListener('click', async () => {
    hideAlert(alertBox());
    setLoading(joinBtn, true, 'Joining…');
    try {
      await apiRequest('/campaigns/join', { method: 'POST', body: { campaignId } });
      await loadCampaign();
      showAlert(alertBox(), 'You joined this campaign. Submit your first clip below.', 'success');
    } catch (err) {
      showAlert(alertBox(), err.message);
      setLoading(joinBtn, false);
    }
  });

  const form = document.getElementById('submit-form');
  if (form) {
    loadCreatorSubmissions({ campaignId, targetId: 'campaign-submissions' });
    form.addEventListener('submit', async (e) => {
      e.preventDefault();
      const btn = form.querySelector('button[type="submit"]');
      hideAlert(alertBox());
      setLoading(btn, true, 'Submitting…');
      try {
        await submitVideo({ campaignId, platform: document.getElementById('sub-platform').value, videoUrl: document.getElementById('sub-url').value.trim() });
        showAlert(alertBox(), 'Clip submitted. It will show as pending until reviewed.', 'success');
        form.reset();
        loadCreatorSubmissions({ campaignId, targetId: 'campaign-submissions' });
      } catch (err) {
        showAlert(alertBox(), err.message);
      } finally {
        setLoading(btn, false);
      }
    });
  } else if (joined) {
    loadCreatorSubmissions({ campaignId, targetId: 'campaign-submissions' });
  }
}

document.addEventListener('DOMContentLoaded', loadCampaign);
