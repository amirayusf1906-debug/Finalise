// js/config.js - shared constants + helpers for the frontend
const CTE_CONFIG = {
  API_BASE: '/api',
  PLATFORMS: [
    { value: 'tiktok', label: 'TikTok' },
    { value: 'instagram', label: 'Instagram' },
    { value: 'youtube', label: 'YouTube' },
  ],
  // Platforms with a working OAuth connection right now (see .env.example).
  LIVE_PLATFORMS: ['tiktok'],
};

function clearSession() {
  try { localStorage.clear(); sessionStorage.clear(); } catch (e) { /* storage blocked */ }
}

// fetch wrapper: sends cookies, parses JSON, throws on !success.
// A 401 anywhere except the auth pages means the session ended: clear local data and go to login.
async function apiRequest(path, { method = 'GET', body } = {}) {
  let res;
  try {
    res = await fetch(`${CTE_CONFIG.API_BASE}${path}`, {
      method,
      headers: body ? { 'Content-Type': 'application/json' } : undefined,
      credentials: 'include',
      body: body ? JSON.stringify(body) : undefined,
    });
  } catch (e) {
    throw new Error('Network error. Check your connection and try again.');
  }
  const data = await res.json().catch(() => ({}));
  if (!res.ok || data.success === false) {
    if (res.status === 401 && !path.startsWith('/auth') && !/(login|register)/.test(location.pathname)) {
      clearSession();
      location.replace('login.html');
    }
    const err = new Error(data.error || 'Request failed');
    err.status = res.status;
    err.data = data;
    throw err;
  }
  return data;
}

function formatCents(cents) { return `$${(Number(cents || 0) / 100).toFixed(2)}`; }

function escapeHtml(str) {
  const div = document.createElement('div');
  div.textContent = str ?? '';
  return div.innerHTML;
}

function showAlert(el, message, type = 'error') {
  if (!el) return;
  el.textContent = message;
  el.className = `alert alert-${type} show`;
  el.setAttribute('role', type === 'error' ? 'alert' : 'status');
  if (el.scrollIntoView) el.scrollIntoView({ block: 'nearest', behavior: 'smooth' }); // keep feedback visible on long/mobile pages
}

function hideAlert(el) { if (el) el.className = el.className.replace(' show', ''); }

// Button loading state: setLoading(btn, true, 'Joining…') then setLoading(btn, false)
function setLoading(btn, on, label) {
  if (!btn) return;
  if (on) {
    if (btn.dataset.label === undefined) btn.dataset.label = btn.innerHTML;
    btn.disabled = true;
    btn.innerHTML = `<span class="spinner"></span> ${escapeHtml(label || 'Working…')}`;
  } else {
    if (btn.dataset.label !== undefined) { btn.innerHTML = btn.dataset.label; delete btn.dataset.label; }
    btn.disabled = false;
  }
}

function loadingHtml(msg = 'Loading…') {
  return `<div class="state-loading" role="status"><span class="spinner"></span> ${escapeHtml(msg)}</div>`;
}

// Puts an error + "Try again" button into el
function showState(el, err, retry) {
  el.innerHTML = `<div class="state-error" role="alert"><span>${escapeHtml(err.message || 'Something went wrong.')}</span><button type="button" class="btn btn-secondary retry-btn">Try again</button></div>`;
  el.querySelector('.retry-btn').onclick = retry;
}

const shortId = (id) => String(id || '').slice(-6);
// Admin lists get { _id, username } for users; fall back to a short ID if only an ID came back.
const whoIs = (u) => (u && u.username ? `@${u.username}` : `user …${shortId(u && u._id ? u._id : u)}`);
const fmtDate = (d) => (d ? new Date(d).toLocaleDateString(undefined, { month: 'short', day: 'numeric', year: 'numeric' }) : '');
const platformLabel = (v) => (CTE_CONFIG.PLATFORMS.find((p) => p.value === v) || {}).label || v;

// Reward text: brand campaigns pay a flat reward per approved creator; older ones pay per 1,000 views.
const rewardAmount = (c) => formatCents(c.rewardPerCreator > 0 ? c.rewardPerCreator : c.payoutPerThousandViews);
const rewardUnit = (c) => (c.rewardPerCreator > 0 ? 'per approved creator' : 'per 1,000 views');
const LIVE_RULE = 'Approved videos may need to stay live for 30 days after the campaign ends. If an approved video is removed or becomes unavailable before then, the reward can be reversed.';
