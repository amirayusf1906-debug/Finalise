// js/dashboard-ui.js
// Presentation only: hamburger menu, tabs, quick-submit sheet,
// Withdraw view, withdrawal method switching and fee preview.
// API/payment data remains in the other JS/backend files.

(function () {

  const $ = (id) => document.getElementById(id);
  const root = document.documentElement;
  let lastFocus = null;


  /* =========================
     LAYOUT / MODALS
  ========================= */

  function lock(on) {
    root.classList.toggle('dx-lock', on);
  }

  function openLayer(layer, overlay, focusEl) {
    if (!layer) return;

    lastFocus = document.activeElement;

    layer.classList.add('is-open');
    layer.setAttribute('aria-hidden', 'false');

    if (overlay) {
      $('dx-overlay').classList.add('is-open');
    }

    lock(true);

    if (focusEl) {
      setTimeout(() => focusEl.focus(), 60);
    }
  }

  function closeLayer(layer) {
    if (!layer) return;

    layer.classList.remove('is-open');
    layer.setAttribute('aria-hidden', 'true');

    $('dx-overlay').classList.remove('is-open');

    lock(false);

    if (lastFocus && lastFocus.focus) {
      lastFocus.focus();
    }
  }


  const drawer = $('dx-drawer');
  const sheet = $('dx-sheet');

  const openMenu = () => {
    $('dx-menu-btn').setAttribute('aria-expanded', 'true');

    openLayer(
      drawer,
      true,
      drawer.querySelector('a,button')
    );
  };

  const closeMenu = () => {
    $('dx-menu-btn').setAttribute(
      'aria-expanded',
      'false'
    );

    closeLayer(drawer);
  };

  const openSheet = () => {
    openLayer(
      sheet,
      true,
      $('submit-url')
    );
  };

  const closeSheet = () => {
    closeLayer(sheet);
  };


  /* =========================
     VIEWS
  ========================= */

  function showView(view) {

    const withdraw = view === 'withdraw';

    $('dx-market').hidden = withdraw;
    $('withdraw-section').hidden = !withdraw;


    if (!withdraw) {

      const subs = view === 'submissions';

      $('campaigns').hidden = subs;
      $('submissions-panel').hidden = !subs;


      [
        ['dx-tab-available', !subs],
        ['dx-tab-submissions', subs]
      ].forEach(([id, on]) => {

        $(id).classList.toggle('is-active', on);

        $(id).setAttribute(
          'aria-selected',
          String(on)
        );

      });

    }


    document
      .querySelectorAll('[data-nav]')
      .forEach((a) => {

        a.classList.toggle(
          'is-active',
          a.dataset.nav === (
            view === 'campaigns'
              ? 'dashboard'
              : view
          )
        );

      });


    window.scrollTo({
      top: 0,
      behavior: 'smooth'
    });
  }


  function fromHash() {

    const h = location.hash.replace('#', '');

    if (
      h === 'withdraw' ||
      h === 'withdraw-section'
    ) {
      return showView('withdraw');
    }

    if (
      h === 'submissions' ||
      h === 'submissions-panel'
    ) {
      return showView('submissions');
    }

    showView('campaigns');
  }


  /* =========================
     MENU / MODAL EVENTS
  ========================= */

  $('dx-menu-btn').addEventListener(
    'click',
    openMenu
  );

  $('dx-menu-close').addEventListener(
    'click',
    closeMenu
  );

  $('dx-quick-btn').addEventListener(
    'click',
    openSheet
  );

  $('dx-sheet-close').addEventListener(
    'click',
    closeSheet
  );


  $('dx-overlay').addEventListener(
    'click',
    () => {

      if (drawer.classList.contains('is-open')) {
        closeMenu();

      } else if (sheet.classList.contains('is-open')) {
        closeSheet();
      }

    }
  );


  document.addEventListener(
    'keydown',
    (e) => {

      if (e.key !== 'Escape') return;

      if (drawer.classList.contains('is-open')) {
        closeMenu();

      } else if (sheet.classList.contains('is-open')) {
        closeSheet();
      }

    }
  );


  /* =========================
     MARKETPLACE TABS
  ========================= */

  $('dx-tab-available').addEventListener(
    'click',
    () => showView('campaigns')
  );

  $('dx-tab-submissions').addEventListener(
    'click',
    () => showView('submissions')
  );


  $('dx-withdraw-back').addEventListener(
    'click',
    () => showView('campaigns')
  );


  /* =========================
     DRAWER LINKS
  ========================= */

  drawer
    .querySelectorAll('[data-nav]')
    .forEach((a) => {

      a.addEventListener(
        'click',
        (e) => {

          e.preventDefault();

          const v =
            a.dataset.nav === 'dashboard'
              ? 'campaigns'
              : a.dataset.nav;


          const hash =
            v === 'campaigns'
              ? ''
              : `#${v}`;


          history.replaceState(
            null,
            '',
            `dashboard.html${hash}`
          );


          closeMenu();

          showView(v);
        }
      );

    });


  window.addEventListener(
    'hashchange',
    fromHash
  );


  /* =========================
     ADD SUBMISSION
  ========================= */

  const addSubmissionBtn =
    $('dx-add-submission');

  if (addSubmissionBtn) {

    addSubmissionBtn.addEventListener(
      'click',
      () => {

        openSheet();

      }
    );

  }


  /* =========================
     WITHDRAWAL
  ========================= */

  const withdrawMethod =
    $('withdraw-method');

  const cryptoFields =
    $('crypto-fields');

  const withdrawCrypto =
    $('withdraw-crypto');

  const withdrawNetwork =
    $('withdraw-network');

  const destination =
    $('withdraw-destination');

  const destinationLabel =
    $('withdraw-destination-label');

  const amountInput =
    $('withdraw-amount');


  /*
   * Fee settings
   *
   * Loaded from the server (lib/fees.js via /api/profile) as soon as the
   * page's session check finishes. Preview only: the server always
   * calculates the real fee.
   */
  let WITHDRAWAL_FEE_PERCENT = 2;
  let MAX_WITHDRAWAL_FEE = 10;
  let MIN_WITHDRAWAL = 10;


  /*
   * Coin → network mapping.
   *
   * IMPORTANT:
   * These networks must also be supported
   * by the backend/NOWPayments configuration.
   */
  const cryptoNetworks = {

    USDT: [
      {
        value: 'trc20',
        label: 'TRC20'
      },
      {
        value: 'erc20',
        label: 'ERC20'
      },
      {
        value: 'bep20',
        label: 'BEP20'
      }
    ],

    BNB: [
      {
        value: 'bep20',
        label: 'BEP20'
      }
    ],

    ETH: [
      {
        value: 'erc20',
        label: 'ERC20'
      }
    ],

    BTC: [
      {
        value: 'bitcoin',
        label: 'Bitcoin'
      }
    ]

  };


  /*
   * Update network dropdown
   */
  function updateNetworks() {

    if (
      !withdrawCrypto ||
      !withdrawNetwork
    ) {
      return;
    }


    const coin =
      withdrawCrypto.value;


    const networks =
      cryptoNetworks[coin] || [];


    withdrawNetwork.innerHTML = '';


    networks.forEach(
      (network) => {

        const option =
          document.createElement('option');

        option.value =
          network.value;

        option.textContent =
          network.label;

        withdrawNetwork.appendChild(
          option
        );

      }
    );

  }


  /*
   * PayPal ↔ Crypto
   */
  function updateWithdrawalMethod() {

    if (
      !withdrawMethod ||
      !cryptoFields ||
      !destination
    ) {
      return;
    }


    const method =
      withdrawMethod.value;


    if (method === 'crypto') {

      /* Show crypto fields */

      cryptoFields.hidden = false;


      /* Wallet address */

      destinationLabel.textContent =
        'Wallet address';

      destination.type =
        'text';

      destination.placeholder =
        'Enter your wallet address';

      destination.autocomplete =
        'off';


      /*
       * Populate networks
       */
      updateNetworks();


    } else {

      /* Show PayPal fields */

      cryptoFields.hidden = true;


      destinationLabel.textContent =
        'PayPal email';

      destination.type =
        'email';

      destination.placeholder =
        'Enter your PayPal email';

      destination.autocomplete =
        'email';

    }

  }


  /* =========================
     FEE CALCULATION
  ========================= */

  function calculateWithdrawalFee(amount) {

    const value =
      Number(amount);


    if (
      !Number.isFinite(value) ||
      value < MIN_WITHDRAWAL
    ) {

      return {
        valid: false,
        amount: 0,
        fee: 0,
        netAmount: 0
      };

    }


    const calculatedFee =
      value *
      WITHDRAWAL_FEE_PERCENT /
      100;


    const fee =
      Math.min(
        calculatedFee,
        MAX_WITHDRAWAL_FEE
      );


    const netAmount =
      value - fee;


    return {

      valid: true,

      amount:
        Number(value.toFixed(2)),

      fee:
        Number(fee.toFixed(2)),

      netAmount:
        Number(netAmount.toFixed(2))

    };

  }


  /* =========================
     FEE PREVIEW
  ========================= */

  let feePreview =
    $('withdraw-fee-preview');


  if (
    !feePreview &&
    amountInput
  ) {

    feePreview =
      document.createElement('div');

    feePreview.id =
      'withdraw-fee-preview';

    feePreview.className =
      'withdraw-fee-preview';


    amountInput.insertAdjacentElement(
      'afterend',
      feePreview
    );

  }


  function updateFeePreview() {

    if (
      !amountInput ||
      !feePreview
    ) {
      return;
    }


    const amount =
      Number(amountInput.value);


    if (!amount) {

      feePreview.innerHTML =
        '';

      return;

    }


    const result =
      calculateWithdrawalFee(
        amount
      );


    if (!result.valid) {

      feePreview.innerHTML = `
        <div class="withdraw-fee-error">
          Minimum withdrawal is $${MIN_WITHDRAWAL.toFixed(2)}.
        </div>
      `;

      return;

    }


    feePreview.innerHTML = `

      <div class="withdraw-fee-row">
        <span>Withdrawal</span>
        <strong>
          $${result.amount.toFixed(2)}
        </strong>
      </div>

      <div class="withdraw-fee-row">
        <span>Withdrawal fee (${WITHDRAWAL_FEE_PERCENT}%)</span>
        <strong>
          -$${result.fee.toFixed(2)}
        </strong>
      </div>

      <div class="withdraw-fee-row withdraw-fee-total">
        <span>You receive</span>
        <strong>
          $${result.netAmount.toFixed(2)}
        </strong>
      </div>

    `;

  }


  /* =========================
     WITHDRAWAL EVENTS
  ========================= */

  if (withdrawMethod) {

    withdrawMethod.addEventListener(
      'change',
      updateWithdrawalMethod
    );

  }


  if (withdrawCrypto) {

    withdrawCrypto.addEventListener(
      'change',
      updateNetworks
    );

  }


  if (amountInput) {

    amountInput.addEventListener(
      'input',
      updateFeePreview
    );

  }


  /* =========================
     INITIAL WITHDRAW STATE
  ========================= */

  updateWithdrawalMethod();

  updateFeePreview();

  requireLogin().then((user) => {
    if (!user || !user.fees) return;
    WITHDRAWAL_FEE_PERCENT = user.fees.withdrawalFeePercent;
    MAX_WITHDRAWAL_FEE = user.fees.maxWithdrawalFee;
    MIN_WITHDRAWAL = user.fees.minWithdrawal;
    if (amountInput) amountInput.min = String(MIN_WITHDRAWAL);
    const note = document.querySelector('#withdraw-section .withdraw-min-note');
    if (note) note.textContent = note.textContent.replace(/\$[\d.,]+/, '$' + MIN_WITHDRAWAL.toFixed(2));
    updateFeePreview();
  });


  /* =========================
     ALERTS
  ========================= */

  const alertEl =
    $('dashboard-alert');

  let timer;


  new MutationObserver(
    () => {

      clearTimeout(timer);


      if (
        !alertEl.classList.contains('show')
      ) {
        return;
      }


      if (
        alertEl.classList.contains(
          'alert-success'
        )
      ) {

        if (
          sheet.classList.contains(
            'is-open'
          )
        ) {

          closeSheet();

          showView(
            'submissions'
          );

        }


        timer =
          setTimeout(
            () => {
              alertEl.className =
                'alert';
            },
            6000
          );

      }

    }
  ).observe(
    alertEl,
    {
      attributes: true,
      attributeFilter: ['class']
    }
  );


  alertEl.addEventListener(
    'click',
    () => {
      alertEl.className = 'alert';
    }
  );


  /* =========================
     INITIAL VIEW
  ========================= */

  fromHash();

})();