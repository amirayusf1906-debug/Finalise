// js/dashboard.js - creator dashboard controller: balance, quick submit, submissions, withdrawals.
// (Campaign cards are in js/marketplace.js; menu/tabs/fee preview are in js/dashboard-ui.js.)
(function () {
  const $ = (id) => document.getElementById(id);
  const alertEl = () => $('dashboard-alert');

  async function loadBalance() {
    const user = await requireLogin();
    if (!user) return null;
    if ($('display-name')) $('display-name').textContent = user.displayName || user.username;
    $('balance-value').textContent = formatCents(user.balance);
    $('pending-value').textContent = formatCents(user.pendingPaymentBalance || 0);
    $('pending-value').removeAttribute('aria-hidden');
    $('pending-balance').textContent = `Pending payment: ${formatCents(user.pendingPaymentBalance || 0)}`;
    return user;
  }

  /* ---------- withdrawal history ---------- */
  const STATUS_TONE = { completed: 'approved', failed: 'rejected', cancelled: 'rejected' };

  async function loadWithdrawals() {
    const box = $('withdrawal-history');
    if (!box) return;
    box.innerHTML = loadingHtml('Loading withdrawals…');
    try {
      const { withdrawals } = await apiRequest('/withdrawals');
      if (!withdrawals.length) { box.innerHTML = '<div class="empty-state">No withdrawals yet.</div>'; return; }
      box.innerHTML = withdrawals.map((w) => {
        const net = typeof w.netAmount === 'number' ? w.netAmount : w.amount; // older records had no fee
        const fee = typeof w.feeAmount === 'number' ? w.feeAmount : 0;
        const via = w.method === 'crypto' ? `${escapeHtml(w.cryptoCurrency || '')} (${escapeHtml(w.network || '')})` : 'PayPal';
        return `<div class="submission-row"><div class="row-main">
            <div><strong class="num">${formatCents(w.amount)}</strong> <span class="faint">· ${via} · ${fmtDate(w.createdAt)}</span></div>
            <div class="faint">Fee ${formatCents(fee)} · You receive ${formatCents(net)}</div>
            ${w.status === 'failed' && w.failureReason ? `<div class="reject-reason">${escapeHtml(w.failureReason)} The amount was returned to your balance.</div>` : ''}
          </div><div class="meta"><span class="badge badge-${STATUS_TONE[w.status] || 'pending'}">${escapeHtml(w.status)}</span></div></div>`;
      }).join('');
    } catch (err) { showState(box, err, loadWithdrawals); }
  }

  /* ---------- request a withdrawal ---------- */
  let requestId = null; // the same id is re-sent on a retry or double tap, so only one withdrawal can be created

  function bindWithdrawForm() {
    const form = $('withdraw-form');
    if (!form) return;
    form.addEventListener('submit', async (e) => {
      e.preventDefault();
      const btn = form.querySelector('button[type="submit"]');
      const method = $('withdraw-method').value;
      const amount = Math.round(parseFloat($('withdraw-amount').value) * 100);
      const destination = $('withdraw-destination').value.trim();
      hideAlert(alertEl());
      const me = await requireLogin();
      const minCents = Math.round(((me && me.fees && me.fees.minWithdrawal) || 10) * 100);
      if (!Number.isFinite(amount) || amount < minCents) return showAlert(alertEl(), `Minimum withdrawal is ${formatCents(minCents)}.`);
      if (!destination) return showAlert(alertEl(), method === 'crypto' ? 'Enter your wallet address.' : 'Enter your PayPal email.');
      const body = { amount, method, destination, clientRequestId: requestId || (requestId = crypto.randomUUID()) };
      if (method === 'crypto') {
        body.cryptoCurrency = $('withdraw-crypto').value;
        body.network = $('withdraw-network').value.toUpperCase(); // the API expects TRC20, ERC20, BEP20, BITCOIN
      }
      setLoading(btn, true, 'Requesting…');
      try {
        const data = await apiRequest('/withdrawals', { method: 'POST', body });
        requestId = null;
        const w = data.withdrawal || {};
        const net = typeof w.netAmount === 'number' ? w.netAmount : w.amount;
        showAlert(alertEl(), `Withdrawal requested: ${formatCents(w.amount)} taken from your balance, ${formatCents(net)} will be sent to you.`, 'success');
        form.reset();
        $('withdraw-amount').dispatchEvent(new Event('input')); // refresh the fee preview
        $('withdraw-method').dispatchEvent(new Event('change'));
        await Promise.all([loadBalance(), loadWithdrawals()]);
      } catch (err) {
        showAlert(alertEl(), err.message);
      } finally {
        setLoading(btn, false);
      }
    });
  }

  document.addEventListener('DOMContentLoaded', async () => {
    if (!$('balance-value')) return;
    try {
      const user = await loadBalance();
      if (!user) return;
    } catch (err) {
      $('balance-value').textContent = '—';
      showAlert(alertEl(), err.message);
    }
    bindQuickSubmitForm();
    populateCampaignSelect();
    loadCreatorSubmissions();
    bindWithdrawForm();
    loadWithdrawals();
  });
})();
