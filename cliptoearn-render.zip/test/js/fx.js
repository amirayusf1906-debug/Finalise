// js/fx.js - scroll reveal for landing sections + pointer glow on cards. Purely cosmetic.
(function () {
  var items = document.querySelectorAll('.lp-section .lp-wrap > *, .lp-steps li, .lp-benefits > *');
  if ('IntersectionObserver' in window && items.length) {
    var io = new IntersectionObserver(function (entries) {
      entries.forEach(function (e) { if (e.isIntersecting) { e.target.classList.add('fx-in'); io.unobserve(e.target); } });
    }, { threshold: 0.15 });
    items.forEach(function (el, i) { el.classList.add('fx-reveal'); el.style.transitionDelay = (i % 5) * 70 + 'ms'; io.observe(el); });
  }
  document.addEventListener('pointermove', function (e) {
    var c = e.target.closest && e.target.closest('.card');
    if (!c) return;
    var r = c.getBoundingClientRect();
    c.style.backgroundImage = 'radial-gradient(260px circle at ' + (e.clientX - r.left) + 'px ' + (e.clientY - r.top) + 'px, rgba(236,72,153,.14), transparent 70%)';
  });
})();
