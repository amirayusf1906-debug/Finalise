// js/landing.js - if the visitor is already signed in, swap the sign-up buttons for a Dashboard link.
// Uses plain fetch (not apiRequest) so a logged-out visitor is never redirected to the login page.
(async () => {
  try {
    const res = await fetch('/api/profile', { credentials: 'include' });
    if (!res.ok) return;
    const { user } = await res.json();
    const home = user && user.role === 'admin' ? 'admin.html' : 'dashboard.html';
    const auth = document.getElementById('lp-auth');
    if (auth) auth.innerHTML = `<a class="btn btn-primary" href="${home}">Go to dashboard</a>`;
    document.querySelectorAll('[data-cta="register"]').forEach((a) => { a.href = home; a.textContent = 'Go to dashboard'; });
  } catch (e) { /* not signed in: leave the page as is */ }
})();
