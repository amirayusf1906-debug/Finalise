// js/marketplace.js - campaign cards; joining happens on campaign.html
async function loadMarketplace() {
  const grid = document.getElementById('campaigns-grid');
  grid.innerHTML = loadingHtml('Loading campaigns…');
  try {
    const user = await requireLogin();
    if (!user) return;
    const { campaigns, recommendedCampaigns } = await apiRequest('/campaigns');
    renderCampaigns(campaigns, user, recommendedCampaigns || []);
  } catch (err) {
    showState(grid, err, loadMarketplace);
  }
}

let _dxCampaigns = [];
let _dxRecommended = [];

function renderCampaigns(campaigns, user, recommended) {
  _dxCampaigns = campaigns || []; _dxRecommended = recommended || []; paintRecommended(); paintCampaigns();
}

function campaignCard(c, i, recommended) {
  const pct=c.budgetTotal?Math.min(100,Math.round((c.budgetSpent/c.budgetTotal)*100)):0;
  const joined=!!c.joined, flat=c.rewardPerCreator>0;
  const initial=escapeHtml((c.brandName||c.title||'?').trim().charAt(0).toUpperCase());
  const stat=(label,val,cls='')=>`<div class="dx-stat"><span class="dx-label">${label}</span><b class="num ${cls}">${val}</b></div>`;
  return `<article class="dx-ccard fade-in-item"><div class="dx-chead"><div class="dx-logo" aria-hidden="true">${initial}</div><div class="dx-ctitle"><div class="dx-brandname">${escapeHtml(c.brandName||'Brand')}</div><h3>${escapeHtml(c.title)}</h3></div></div>${recommended?`<div class="dx-match-badge">${escapeHtml(String(c.matchScore||0))}% match</div>`:''}<div class="dx-pills">${(c.platforms||[]).map(p=>`<span class="dx-pill">${escapeHtml(platformLabel(p))}</span>`).join('')}</div><div class="dx-stats">${stat(flat?'Reward':'Per 1K views',rewardAmount(c),'gold')}${flat&&c.payoutPerThousandViews>0?stat('Per 1K views',formatCents(c.payoutPerThousandViews),'blue'):''}${c.maxRewardPerVideo>0?stat('Max / video',formatCents(c.maxRewardPerVideo),'gold'):''}${stat('Remaining',formatCents(campaignLeft(c)))}</div><div class="dx-unit">${escapeHtml(rewardUnit(c))}</div><div class="dx-bar"><span style="width:${pct}%"></span></div><div class="dx-barlabel">${pct}% used · ${formatCents(c.budgetSpent)} of ${formatCents(c.budgetTotal)}</div><a class="dx-join ${joined?'is-joined':''}" href="campaign.html?id=${encodeURIComponent(c._id)}">${joined?'Joined · View':'Join Campaign'}</a></article>`;
}
function paintRecommended(){ const s=document.getElementById('recommended-campaigns'),g=document.getElementById('recommended-grid'); if(!s||!g)return; s.hidden=!_dxRecommended.length; g.innerHTML=_dxRecommended.map((c,i)=>campaignCard(c,i,true)).join(''); }

const campaignReward = (c) => (c.rewardPerCreator > 0 ? c.rewardPerCreator : c.payoutPerThousandViews) || 0;
const campaignLeft = (c) => (c.remainingBudget !== undefined ? c.remainingBudget : Math.max(0, (c.fundedAmount || 0) - (c.budgetSpent || 0)));

function paintCampaigns() {
  const grid = document.getElementById('campaigns-grid');
  const countEl = document.getElementById('campaign-count');
  if (!_dxCampaigns.length) {
    grid.innerHTML = '<div class="empty-state">No active campaigns right now. Check back soon.</div>';
    if (countEl) countEl.textContent = '';
    return;
  }
  const q = ((document.getElementById('campaign-search') || {}).value || '').trim().toLowerCase();
  const plat = (document.getElementById('campaign-platform-filter') || {}).value || '';
  const sort = (document.getElementById('campaign-sort') || {}).value || 'newest';
  let list = _dxCampaigns.filter((c) =>
    (!plat || (c.platforms || []).includes(plat)) &&
    (!q || [c.title, c.brandName, c.description, c.category, ...(c.platforms || []).map(platformLabel)].join(' ').toLowerCase().includes(q)));
  if (sort === 'reward') list = [...list].sort((a, b) => campaignReward(b) - campaignReward(a));
  if (sort === 'budget') list = [...list].sort((a, b) => campaignLeft(b) - campaignLeft(a));
  if (countEl) countEl.textContent = `${list.length} of ${_dxCampaigns.length} campaign${_dxCampaigns.length === 1 ? '' : 's'}`;
  if (!list.length) {
    grid.innerHTML = '<div class="empty-state">No campaigns match your search or filter.</div>';
    return;
  }
  grid.innerHTML = list.map((c, i) => campaignCard(c, i, false)).join('');
}

function bindCampaignTools() {
  const plat = document.getElementById('campaign-platform-filter');
  if (plat) plat.insertAdjacentHTML('beforeend', CTE_CONFIG.PLATFORMS.map((p) => `<option value="${p.value}">${escapeHtml(p.label)}</option>`).join(''));
  ['campaign-search', 'campaign-platform-filter', 'campaign-sort'].forEach((id) => {
    const el = document.getElementById(id);
    if (el) el.addEventListener(id === 'campaign-search' ? 'input' : 'change', () => { if (_dxCampaigns.length) paintCampaigns(); });
  });
}

document.addEventListener('DOMContentLoaded', () => {
  if (document.getElementById('campaigns-grid')) { bindCampaignTools(); loadMarketplace(); }
});
