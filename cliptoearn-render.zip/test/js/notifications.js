(function(){
  const $=id=>document.getElementById(id);
  let open=false;
  function paint(rows){
    const box=$('notifications-list');
    if(!rows.length){box.innerHTML='<div class="notification-empty">No notifications yet.</div>';return;}
    box.innerHTML=rows.map(n=>`<div class="notification-row ${n.readAt?'':'unread'}" data-id="${escapeHtml(n._id)}"><div><strong>${escapeHtml(n.title)}</strong><p>${escapeHtml(n.message)}</p><small>${fmtDate(n.createdAt)}</small></div><div class="notification-actions">${!n.readAt?'<button type="button" class="btn btn-secondary notif-read">Read</button>':''}${n.data&&n.data.campaignId?`<a class="btn btn-secondary" href="campaign.html?id=${encodeURIComponent(n.data.campaignId)}">View</a>`:''}</div></div>`).join('');
    box.querySelectorAll('.notif-read').forEach(b=>b.addEventListener('click',async()=>{try{await apiRequest('/notifications',{method:'PATCH',body:{id:b.closest('.notification-row').dataset.id}});loadNotifications();}catch(e){}}));
  }
  async function loadNotifications(){
    try{const d=await apiRequest('/notifications'); const count=$('notification-count'); count.textContent=d.unread||0; count.hidden=!d.unread; paint(d.notifications||[]);}catch(e){}
  }
  document.addEventListener('DOMContentLoaded',()=>{
    const btn=$('notification-btn'), panel=$('notifications-panel'), all=$('notifications-read-all'); if(!btn||!panel)return;
    btn.addEventListener('click',()=>{open=!open;panel.hidden=!open;if(open)loadNotifications();});
    if(all)all.addEventListener('click',async()=>{try{await apiRequest('/notifications',{method:'PATCH',body:{id:'all'}});loadNotifications();}catch(e){}});
    loadNotifications(); setInterval(loadNotifications,60000);
  });
})();
