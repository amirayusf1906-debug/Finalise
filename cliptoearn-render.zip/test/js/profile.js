// js/profile.js - creator profile: summary, earnings history (ledger), edit profile, change password.
(function () {
  const $ = (id) => document.getElementById(id);
  let me = null;
  const txState = { filter: 'all', rows: [], next: null };

  const initials = (n) => (String(n || '?').trim().split(/\s+/).map((w) => w[0]).slice(0, 2).join('') || '?').toUpperCase();

  function paintAvatar(imgEl, initEl, url, name) {
    initEl.textContent = initials(name);
    if (url) { imgEl.src = url; imgEl.hidden = false; initEl.hidden = true; } else { imgEl.hidden = true; initEl.hidden = false; imgEl.removeAttribute('src'); }
  }

  function paintHeader() {
    $('pf-name').textContent = me.displayName || me.username;
    $('pf-username').textContent = `@${me.username}`;
    $('pf-email').textContent = me.email || '';
    $('pf-since').textContent = me.createdAt ? `Member since ${fmtDate(me.createdAt)}` : '';
    paintAvatar($('pf-avatar-img'), $('pf-initials'), me.avatarUrl, me.displayName || me.username);
    $('st-balance').textContent = formatCents(me.balance);
    $('st-earned').textContent = formatCents(me.totalEarned);
    $('f-username').value = me.username;
    $('f-email').value = me.email || '';
    $('displayName').value = me.displayName || '';
    $('avatarUrl').value = me.avatarUrl || '';
    $('name-count').textContent = String($('displayName').value.length);
    paintAvatar($('pf-preview-img'), $('pf-preview-initials'), me.avatarUrl, me.displayName || me.username);
  }

  /* ---------- earnings history ---------- */
  const TITLES = { earning: 'Clip payout', campaign_reward: 'Clip payout', reward_reversal: 'Reward reversed', withdrawal: 'Withdrawal', withdrawal_fee: 'Withdrawal fee', refund: 'Withdrawal returned', adjustment: 'Adjustment' };

  function paintTx() {
    const list = $('transactions-list');
    if (!txState.rows.length) { list.innerHTML = '<div class="empty-state">Nothing here yet.</div>'; }
    else {
      list.innerHTML = txState.rows.map((t) => {
        const inn = t.amount > 0;
        return `<div class="pf-tx"><div class="pf-tx-icon ${inn ? 'in' : 'out'}" aria-hidden="true">${inn ? '+' : '−'}</div>
          <div class="pf-tx-main"><div class="pf-tx-title">${escapeHtml(TITLES[t.type] || t.type)}</div>
            <div class="pf-tx-desc">${escapeHtml(t.description || '')}</div><div class="pf-tx-date">${fmtDate(t.createdAt)}</div></div>
          <div class="pf-tx-amount"><strong class="num ${inn ? 'in' : ''}">${inn ? '+' : '−'}${formatCents(Math.abs(t.amount))}</strong>${typeof t.balanceAfter === 'number' ? `<small>Balance ${formatCents(t.balanceAfter)}</small>` : ''}</div></div>`;
      }).join('');
    }
    $('tx-more').hidden = !txState.next;
  }

  async function loadTx(more) {
    const list = $('transactions-list');
    if (!more) { txState.rows = []; txState.next = null; list.innerHTML = loadingHtml('Loading history…'); }
    hideAlert($('tx-alert'));
    try {
      const q = `/profile?view=transactions&filter=${txState.filter}${more && txState.next ? `&before=${txState.next}` : ''}`;
      const data = await apiRequest(q);
      txState.rows = txState.rows.concat(data.transactions);
      txState.next = data.hasMore ? data.nextBefore : null;
      paintTx();
    } catch (err) { if (more) showAlert($('tx-alert'), err.message); else showState(list, err, () => loadTx(false)); }
  }

  function exportCsv() {
    const esc = (v) => `"${String(v ?? '').replace(/"/g, '""')}"`;
    const lines = ['Date,Type,Description,Amount (USD),Balance after (USD)'].concat(txState.rows.map((t) =>
      [new Date(t.createdAt).toISOString(), TITLES[t.type] || t.type, t.description, (t.amount / 100).toFixed(2), typeof t.balanceAfter === 'number' ? (t.balanceAfter / 100).toFixed(2) : ''].map(esc).join(',')));
    const a = document.createElement('a');
    a.href = URL.createObjectURL(new Blob([lines.join('\n')], { type: 'text/csv' }));
    a.download = 'cliptoearn-earnings.csv';
    document.body.appendChild(a); a.click(); a.remove();
    setTimeout(() => URL.revokeObjectURL(a.href), 1000);
  }

  /* ---------- sidebar + stats ---------- */
  function paintSide(subs, accounts) {
    const approved = subs.filter((s) => s.status === 'approved');
    $('st-approved').textContent = approved.length;
    $('st-approved-note').textContent = `${subs.filter((s) => s.status === 'pending').length} waiting for review`;
    $('st-views').textContent = approved.reduce((n, s) => n + (s.views || 0), 0).toLocaleString();
    $('clip-activity').innerHTML = subs.length ? subs.slice(0, 5).map((s) => `<div class="pf-activity-row"><span>${escapeHtml(s.campaign?.title || 'Campaign')}</span><span class="badge badge-${s.status}">${escapeHtml(s.status)}</span></div>`).join('') : '<div class="pf-muted">No clips yet.</div>';
    const tiktok = accounts.find((a) => a.platform === 'tiktok' && a.verified);
    $('pf-tiktok-badge').hidden = !tiktok;
    $('side-socials').innerHTML = accounts.filter((a) => a.verified).length
      ? accounts.filter((a) => a.verified).map((a) => `<div class="pf-acct"><div class="pf-acct-main"><div class="pf-acct-name">${escapeHtml(platformLabel(a.platform))} · @${escapeHtml(a.handle)}</div></div></div>`).join('')
      : '<div class="pf-muted">No verified accounts yet.</div>';
    const items = [
      { label: 'Add a display name', done: !!me.displayName && me.displayName !== me.username, href: '#edit' },
      { label: 'Add a profile photo', done: !!me.avatarUrl, href: '#edit' },
      { label: 'Verify a social account', done: accounts.some((a) => a.verified), href: 'socials.html' },
      { label: 'Submit your first clip', done: subs.length > 0, href: 'dashboard.html' },
    ];
    const pct = Math.round((items.filter((i) => i.done).length / items.length) * 100);
    $('pf-pct').textContent = `${pct}%`;
    $('pf-bar').setAttribute('aria-valuenow', String(pct));
    $('pf-bar').firstElementChild.style.width = `${pct}%`;
    $('pf-checklist').innerHTML = items.map((i) => `<li class="${i.done ? 'done' : ''}"><span class="dot">${i.done ? '✓' : ''}</span>${escapeHtml(i.label)}${i.done ? '' : `<a href="${i.href}" ${i.href === '#edit' ? 'data-goto="edit"' : ''}>Do it</a>`}</li>`).join('');
    $('pf-checklist').querySelectorAll('[data-goto]').forEach((a) => a.addEventListener('click', (e) => { e.preventDefault(); selectTab('edit'); }));
  }

  /* ---------- tabs ---------- */
  function selectTab(name) {
    document.querySelectorAll('.pf-tabs .tab').forEach((t) => {
      const on = t.dataset.tab === name;
      t.classList.toggle('active', on); t.setAttribute('aria-selected', String(on)); t.tabIndex = on ? 0 : -1;
    });
    document.querySelectorAll('.pf-main .tab-panel').forEach((p) => { p.hidden = p.id !== `panel-${name}`; });
  }

  /* ---------- edit profile ---------- */
  function bindEdit() {
    const form = $('profile-form');
    const save = $('profile-save'), reset = $('profile-reset');
    const dirty = () => { const d = $('displayName').value.trim() !== (me.displayName || '') || $('avatarUrl').value.trim() !== (me.avatarUrl || ''); save.disabled = reset.disabled = !d; };
    $('displayName').addEventListener('input', () => { $('name-count').textContent = String($('displayName').value.length); paintAvatar($('pf-preview-img'), $('pf-preview-initials'), $('avatarUrl').value.trim(), $('displayName').value || me.username); dirty(); });
    $('avatarUrl').addEventListener('input', () => { paintAvatar($('pf-preview-img'), $('pf-preview-initials'), $('avatarUrl').value.trim(), $('displayName').value || me.username); dirty(); });
    [$('pf-preview-img'), $('pf-avatar-img')].forEach((img) => img.addEventListener('error', () => { img.hidden = true; img.previousElementSibling.hidden = false; $('avatar-hint').textContent = 'That link could not be loaded as an image.'; }));
    reset.addEventListener('click', () => { paintHeader(); dirty(); });
    form.addEventListener('submit', async (e) => {
      e.preventDefault();
      hideAlert($('profile-alert'));
      setLoading(save, true, 'Saving…');
      try {
        const { user } = await apiRequest('/profile', { method: 'PATCH', body: { displayName: $('displayName').value.trim(), avatarUrl: $('avatarUrl').value.trim() } });
        me = { ...me, ...user };
        paintHeader();
        showAlert($('profile-alert'), 'Profile saved.', 'success');
      } catch (err) { showAlert($('profile-alert'), err.message); }
      finally { setLoading(save, false); dirty(); }
    });
    $('pf-edit-btn').addEventListener('click', () => selectTab('edit'));
  }

  /* ---------- change password ---------- */
  function score(pw) { let s = 0; if (pw.length >= 8) s++; if (pw.length >= 12) s++; if (/[a-z]/.test(pw) && /[A-Z]/.test(pw)) s++; if (/\d/.test(pw) && /[^A-Za-z0-9]/.test(pw)) s++; return pw ? Math.max(1, s) : 0; }

  function bindPassword() {
    document.querySelectorAll('.pf-pw-toggle').forEach((b) => b.addEventListener('click', () => {
      const input = $(b.dataset.target);
      input.type = input.type === 'password' ? 'text' : 'password';
      b.textContent = input.type === 'password' ? 'Show' : 'Hide';
    }));
    $('pw-new').addEventListener('input', () => document.querySelector('.pf-meter').setAttribute('data-score', String(score($('pw-new').value))));
    $('password-form').addEventListener('submit', async (e) => {
      e.preventDefault();
      const btn = $('pw-save');
      const a = $('password-alert');
      hideAlert(a);
      const cur = $('pw-current').value, nw = $('pw-new').value, conf = $('pw-confirm').value;
      if (!cur) return showAlert(a, 'Enter your current password.');
      if (nw.length < 8 || nw.length > 72) return showAlert(a, 'The new password must be 8 to 72 characters.');
      if (nw !== conf) return showAlert(a, 'The new passwords do not match.');
      setLoading(btn, true, 'Updating…');
      try {
        await apiRequest('/auth/password', { method: 'POST', body: { currentPassword: cur, newPassword: nw } });
        e.target.reset();
        document.querySelector('.pf-meter').setAttribute('data-score', '0');
        showAlert(a, 'Password updated. Other devices were signed out.', 'success');
      } catch (err) { showAlert(a, err.message); }
      finally { setLoading(btn, false); }
    });
  }

  document.addEventListener('DOMContentLoaded', async () => {
    me = await requireCreator();
    if (!me) return;
    paintHeader();
    bindEdit();
    bindPassword();
    document.querySelectorAll('.pf-tabs .tab').forEach((t) => t.addEventListener('click', () => selectTab(t.dataset.tab)));
    document.querySelectorAll('.pf-chip').forEach((c) => c.addEventListener('click', () => {
      document.querySelectorAll('.pf-chip').forEach((x) => { const on = x === c; x.classList.toggle('active', on); x.setAttribute('aria-pressed', String(on)); });
      txState.filter = c.dataset.filter; loadTx(false);
    }));
    $('tx-more').addEventListener('click', () => loadTx(true));
    $('tx-export').addEventListener('click', exportCsv);
    loadTx(false);
    try {
      const [{ submissions }, { accounts }] = await Promise.all([apiRequest('/submissions'), apiRequest('/socials')]);
      paintSide(submissions, accounts);
    } catch (err) {
      $('clip-activity').innerHTML = `<div class="pf-muted">${escapeHtml(err.message)}</div>`;
      $('side-socials').innerHTML = '';
    }
  });
})();
