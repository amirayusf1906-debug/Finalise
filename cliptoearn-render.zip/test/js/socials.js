// js/socials.js - connect (OAuth redirect) / disconnect social accounts
async function loadSocials() {
  const list = document.getElementById('socials-list');
  list.innerHTML = loadingHtml('Loading your accounts…');
  showCallbackResult();
  try {
    const user = await requireLogin();
    if (!user) return;
    const { accounts } = await apiRequest('/socials');
    renderSocials(accounts);
  } catch (err) {
    showState(list, err, loadSocials);
  }
}

function renderSocials(accounts) {
  const list = document.getElementById('socials-list');
  const alertEl = document.getElementById('socials-alert');
  const byPlatform = Object.fromEntries(accounts.map((a) => [a.platform, a]));

  list.innerHTML = CTE_CONFIG.PLATFORMS.map(({ value, label }) => {
    const acct = byPlatform[value];
    if (value === 'tiktok') return renderTikTokRow(acct); // bio verification (OAuth stays available for later: see LIVE_PLATFORMS)
    const isLive = CTE_CONFIG.LIVE_PLATFORMS.includes(value);
    let info, action;
    if (acct) {
      info = `<div class="status connected">✓ ${label} Connected</div>
        <div class="handle">@${escapeHtml(acct.handle)}</div>${acct.followerCount ? `<div class="status">${acct.followerCount.toLocaleString()} followers</div>` : ''}`;
      action = `<button type="button" class="btn btn-secondary disconnect-btn" data-platform="${value}">Disconnect</button>`;
    } else {
      info = `<div class="handle">${label}</div><div class="status">${isLive ? 'Not connected' : 'Not available yet'}</div>`;
      action = isLive
        ? `<a class="btn btn-primary connect-btn" href="/api/socials/connect/${value}">Connect ${label}</a>`
        : `<button type="button" class="btn btn-secondary" disabled>Coming soon</button>`;
    }
    return `<div class="social-row" data-platform="${value}">
      <div class="platform-info"><div class="platform-icon">${label[0]}</div><div>${info}</div></div>${action}</div>`;
  }).join('');

  bindBioControls(list, alertEl);

  // The connect control is a real navigation (OAuth redirect); show feedback while the browser leaves.
  list.querySelectorAll('.connect-btn').forEach((a) => a.addEventListener('click', () => {
    a.classList.add('is-loading');
    a.setAttribute('aria-disabled', 'true');
    a.innerHTML = '<span class="spinner"></span> Redirecting…';
  }));

  list.querySelectorAll('.disconnect-btn').forEach((btn) => btn.addEventListener('click', async () => {
    const platform = btn.dataset.platform;
    if (!confirm(`Disconnect ${platformLabel(platform)}? You will not be able to submit ${platformLabel(platform)} clips until you reconnect.`)) return;
    hideAlert(alertEl);
    setLoading(btn, true, 'Disconnecting…');
    try {
      await apiRequest(`/socials?platform=${encodeURIComponent(platform)}`, { method: 'DELETE' });
      const { accounts: fresh } = await apiRequest('/socials');
      renderSocials(fresh);
      showAlert(alertEl, `${platformLabel(platform)} disconnected. Reconnect it any time from this page.`, 'success');
    } catch (err) {
      showAlert(alertEl, err.message);
      setLoading(btn, false);
    }
  }));
}

// The OAuth callback redirects back with ?connected=x or ?error=...; show it once, then clean the URL.
function showCallbackResult() {
  const params = new URLSearchParams(window.location.search);
  const alertEl = document.getElementById('socials-alert');
  if (params.has('connected')) showAlert(alertEl, `${platformLabel(params.get('connected'))} connected. You can now join campaigns that accept it.`, 'success');
  else if (params.has('error')) showAlert(alertEl, params.get('error'));
  else return;
  window.history.replaceState({}, '', window.location.pathname);
}

document.addEventListener('DOMContentLoaded', () => {
  if (document.getElementById('socials-list')) loadSocials();
});

/* ---------- TikTok: verified through bio ---------- */
function renderTikTokRow(acct) {
  const icon = '<div class="platform-icon">T</div>';
  if (acct && acct.verified) {
    const viaBio = acct.verificationMethod === 'bio';
    return `<div class="social-row" data-platform="tiktok">
      <div class="platform-info">${icon}<div>
        <div class="status connected">✓ ${viaBio ? 'Clip-to-Earn verified' : 'TikTok Connected'}</div>
        <div class="handle">@${escapeHtml(acct.handle)}</div>
        ${acct.displayName ? `<div class="status">${escapeHtml(acct.displayName)}</div>` : ''}
        <div class="tiktok-proof-stats">
          <span><strong>${Number(acct.followerCount || 0).toLocaleString()}</strong> followers</span>
          <span><strong>${Number(acct.followingCount || 0).toLocaleString()}</strong> following</span>
          <span><strong>${Number(acct.totalLikes || 0).toLocaleString()}</strong> likes</span>
          <span><strong>${Number(acct.videoCount || 0).toLocaleString()}</strong> videos</span>
        </div>
        <div class="status">Profile checked ${acct.profileSnapshotAt ? fmtDate(acct.profileSnapshotAt) : 'recently'} · <a href="${escapeHtml(acct.profileUrl || `https://www.tiktok.com/@${acct.handle}`)}" target="_blank" rel="noopener noreferrer">View TikTok profile</a></div>
        ${viaBio ? '<div class="status">Verified through your bio. This is our own check, not an official TikTok badge.</div>' : ''}
      </div></div>
      <button type="button" class="btn btn-secondary disconnect-btn" data-platform="tiktok">Disconnect</button></div>`;
  }
  const pending = acct && acct.verificationStatus === 'pending' && acct.verificationCode;
  const failed = acct && (acct.verificationStatus === 'failed' || (acct.verificationStatus === 'pending' && !acct.verificationCode));
  const form = `<form class="bio-form" id="bio-form">
      <input type="text" id="bio-handle" placeholder="@username or profile link" autocomplete="off" autocapitalize="none" required value="${acct ? escapeHtml(acct.handle) : ''}">
      <button type="submit" class="btn btn-primary">${failed ? 'Get a new code' : 'Get verification code'}</button></form>`;

  if (pending) {
    return `<div class="social-row bio-row" data-platform="tiktok">
      <div class="platform-info">${icon}<div><div class="handle">@${escapeHtml(acct.handle)}</div><span class="badge badge-pending">Pending Verification</span></div></div>
      <div class="bio-panel">
        <p>Copy this code, paste it anywhere in your TikTok bio and save. Then tap <strong>Check my bio</strong>.</p>
        <div class="bio-code"><code>${escapeHtml(acct.verificationCode)}</code><button type="button" class="btn btn-secondary" id="bio-copy">Copy</button></div>
        <p class="status">Code expires ${new Date(acct.verificationExpiresAt).toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })}. You can remove it from your bio once verified.</p>
        ${acct.verificationMessage ? `<p class="bio-msg">${escapeHtml(acct.verificationMessage)}</p>` : ''}
        <div class="bio-actions"><button type="button" class="btn btn-primary" id="bio-check">Check my bio</button>
        <button type="button" class="btn btn-secondary" id="bio-cancel">Start over</button></div>
      </div></div>`;
  }
  return `<div class="social-row bio-row" data-platform="tiktok">
    <div class="platform-info">${icon}<div><div class="handle">TikTok</div>
      ${failed ? '<span class="badge badge-rejected">Verification Failed</span>' : '<div class="status">Not connected</div>'}</div></div>
    <div class="bio-panel">
      ${failed ? `<p class="bio-msg">${escapeHtml(acct.verificationMessage || 'This code expired. Start again to get a new one.')}</p>` : '<p>Prove the account is yours by adding a short code to your TikTok bio. No password or login needed.</p>'}
      ${form}</div></div>`;
}

function bindBioControls(list, alertEl) {
  const refresh = async () => renderSocials((await apiRequest('/socials')).accounts);
  const form = list.querySelector('#bio-form');
  if (form) form.addEventListener('submit', async (e) => {
    e.preventDefault();
    const btn = form.querySelector('button');
    hideAlert(alertEl); setLoading(btn, true, 'Creating code…');
    try {
      await apiRequest('/socials/verify-start/tiktok', { method: 'POST', body: { handle: form.querySelector('#bio-handle').value } });
      await refresh();
    } catch (err) { showAlert(alertEl, err.message); setLoading(btn, false); }
  });
  const copy = list.querySelector('#bio-copy');
  if (copy) copy.addEventListener('click', async () => {
    try { await navigator.clipboard.writeText(list.querySelector('.bio-code code').textContent); copy.textContent = 'Copied'; }
    catch (e) { copy.textContent = 'Press and hold the code to copy'; }
  });
  const check = list.querySelector('#bio-check');
  if (check) check.addEventListener('click', async () => {
    hideAlert(alertEl); setLoading(check, true, 'Checking…');
    try {
      let out;
      try { out = await apiRequest('/socials/verify-check/tiktok', { method: 'POST' }); }
      catch (err) { if (err.data && err.data.result) out = err.data; else throw err; }
      await refresh();
      const msg = out.message || '';
      if (out.result === 'verified') showAlert(alertEl, 'TikTok verified through your bio. You can now join campaigns that accept TikTok.', 'success');
      else if (out.result === 'code_not_found') showAlert(alertEl, msg || 'Code not found in your bio yet. Save your bio, wait a moment, then check again.');
      else if (out.result === 'not_found') showAlert(alertEl, msg || 'We could not find that TikTok profile. Check the username and get a new code.');
      else if (out.result === 'expired') showAlert(alertEl, msg || 'This code expired. Get a new code to try again.');
      else if (out.result === 'provider_error') showAlert(alertEl, `${msg || 'TikTok profile verification service is temporarily unavailable.'}${out.errorCode ? ` (Error: ${out.errorCode})` : ''}`);
      else if (msg) showAlert(alertEl, msg);
    } catch (err) { showAlert(alertEl, err.message); setLoading(check, false); }
  });
  const cancel = list.querySelector('#bio-cancel');
  if (cancel) cancel.addEventListener('click', async () => {
    setLoading(cancel, true, 'Resetting…');
    try { await apiRequest('/socials?platform=tiktok', { method: 'DELETE' }); await refresh(); }
    catch (err) { showAlert(alertEl, err.message); setLoading(cancel, false); }
  });
}
