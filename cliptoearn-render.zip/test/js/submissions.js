// js/submissions.js
// All submission logic: submitting a video (dashboard quick-submit + campaign.html),
// the creator's submission list, and the admin review queue.

/* ---------- Shared helpers ---------- */

// Platforms a creator can submit to: allowed by the campaign AND connected on their account.
function connectedPlatformsFor(campaign, accounts) {
  const allowed = campaign.platforms && campaign.platforms.length
    ? campaign.platforms : CTE_CONFIG.PLATFORMS.map((p) => p.value);
  return allowed.filter((p) => accounts.some((a) => a.platform === p && a.verified));
}

async function submitVideo({ campaignId, platform, videoUrl }) {
  let url;
  try { url = new URL(videoUrl); } catch (e) { url = null; }
  if (!url || !/^https?:$/.test(url.protocol)) {
    throw new Error('Paste the full video link, starting with https://');
  }
  return apiRequest('/submissions', { method: 'POST', body: { campaignId, platform, videoUrl } });
}

/* ---------- Creator: submission list ---------- */

async function loadCreatorSubmissions({ campaignId, targetId = 'submissions-list' } = {}) {
  const list = document.getElementById(targetId);
  if (!list) return;
  list.innerHTML = loadingHtml('Loading submissions…');
  try {
    const { submissions } = await apiRequest('/submissions');
    const mine = campaignId
      ? submissions.filter((s) => String(s.campaign && s.campaign._id) === String(campaignId))
      : submissions;
    renderSubmissionStats(submissions);
    renderSubmissionList(mine, list);
    return submissions;
  } catch (err) {
    showState(list, err, () => loadCreatorSubmissions({ campaignId, targetId }));
  }
}

function renderSubmissionStats(submissions) {
  const pending = document.getElementById('stat-pending');
  if (!pending) return;
  pending.textContent = submissions.filter((s) => s.status === 'pending').length;
  document.getElementById('stat-approved').textContent = submissions.filter((s) => s.status === 'approved').length;
  document.getElementById('stat-views').textContent = submissions.reduce((n, s) => n + (s.views || 0), 0).toLocaleString();
}

function renderSubmissionList(submissions, list) {
  if (!submissions.length) {
    list.innerHTML = '<div class="empty-state">No submissions yet. Join a campaign, then submit your first clip.</div>';
    return;
  }
  list.innerHTML = submissions.map((s, i) => `
    <div class="submission-row fade-in-item" style="animation-delay:${i * 40}ms">
      <div class="row-main">
        <div><strong>${escapeHtml(s.campaign?.title || 'Campaign')}</strong> <span class="faint">· ${escapeHtml(platformLabel(s.platform))} · ${fmtDate(s.createdAt)}</span></div>
        <div class="video-url">${escapeHtml(s.videoUrl)}</div>
        ${s.status === 'rejected' && s.rejectionReason ? `<div class="reject-reason">${escapeHtml(s.rejectionReason)}</div>` : ''}
      </div>
      <div class="meta">
        <span>${(s.views || 0).toLocaleString()} views</span>
        <span>${s.status === 'approved' ? formatCents(s.payoutAmount) : '--'}</span>
        <span class="badge badge-${s.status}">${s.status}</span>
        ${s.status === 'approved' ? `<span class="badge badge-${s.paymentStatus === 'paid' ? 'approved' : 'pending'}">${s.paymentStatus === 'paid' ? 'Paid' : 'Payment Pending'}</span>` : ''}
      </div>
    </div>`).join('');
}

/* ---------- Creator: dashboard quick submit (joined campaigns only) ---------- */

let _quick = { campaigns: [], accounts: [] };

function quickHint(html) {
  const el = document.getElementById('quick-submit-hint');
  if (el) { el.innerHTML = html; el.style.display = html ? 'block' : 'none'; }
}

function syncPlatformOptions() {
  const form = document.getElementById('quick-submit-form');
  const btn = form.querySelector('button[type="submit"]');
  const platformSel = document.getElementById('submit-platform');
  const campaign = _quick.campaigns.find((c) => c._id === document.getElementById('submit-campaign').value);
  const ok = campaign ? connectedPlatformsFor(campaign, _quick.accounts) : [];
  platformSel.innerHTML = ok.map((p) => `<option value="${p}">${escapeHtml(platformLabel(p))}</option>`).join('');
  platformSel.disabled = btn.disabled = !ok.length;
  const need = campaign && campaign.platforms.length ? campaign.platforms.map(platformLabel).join(' or ') : 'a social account';
  quickHint(!ok.length && campaign ? `Connect ${escapeHtml(need)} in <a href="socials.html">Socials</a> to submit to this campaign.` : '');
}

async function populateCampaignSelect() {
  const select = document.getElementById('submit-campaign');
  if (!select) return;
  const btn = document.querySelector('#quick-submit-form button[type="submit"]');
  select.innerHTML = '<option value="">Loading…</option>';
  select.disabled = btn.disabled = true;
  try {
    const user = await requireLogin();
    const [{ campaigns }, { accounts }] = await Promise.all([apiRequest('/campaigns'), apiRequest('/socials')]);
    const joined = campaigns.filter((c) => c.joined);
    _quick = { campaigns: joined, accounts };
    if (!joined.length) {
      select.innerHTML = '<option value="">No joined campaigns</option>';
      document.getElementById('submit-platform').innerHTML = '';
      quickHint('Join a campaign below before submitting a clip.');
      return;
    }
    select.innerHTML = joined.map((c) => `<option value="${c._id}">${escapeHtml(c.title)}</option>`).join('');
    select.disabled = false;
    select.onchange = syncPlatformOptions;
    syncPlatformOptions();
  } catch (err) {
    select.innerHTML = '<option value="">Could not load campaigns</option>';
    quickHint(escapeHtml(err.message));
  }
}

function bindQuickSubmitForm() {
  const form = document.getElementById('quick-submit-form');
  if (!form) return;
  const alertEl = document.getElementById('dashboard-alert');
  form.insertAdjacentHTML('beforebegin', '<p id="quick-submit-hint" class="hint" style="display:none"></p>');

  form.addEventListener('submit', async (e) => {
    e.preventDefault();
    const btn = form.querySelector('button[type="submit"]');
    hideAlert(alertEl);
    setLoading(btn, true, 'Submitting…');
    try {
      await submitVideo({
        campaignId: document.getElementById('submit-campaign').value,
        platform: document.getElementById('submit-platform').value,
        videoUrl: document.getElementById('submit-url').value.trim(),
      });
      showAlert(alertEl, 'Clip submitted. It will show as pending until reviewed.', 'success');
      document.getElementById('submit-url').value = '';
      loadCreatorSubmissions();
    } catch (err) {
      showAlert(alertEl, err.message);
    } finally {
      setLoading(btn, false);
    }
  });
}

/* ---------- Admin: review queue ---------- */

async function loadAdminQueue() {
  const list = document.getElementById('review-queue');
  list.innerHTML = loadingHtml('Loading pending clips…');
  try {
    const admin = await requireAdmin();
    if (!admin) return;
    const { submissions } = await apiRequest('/submissions?all=1&status=pending');
    renderQueue(submissions);
  } catch (err) {
    showState(list, err, loadAdminQueue);
  }
}

function renderQueue(submissions) {
  const list = document.getElementById('review-queue');
  const alertEl = document.getElementById('admin-alert');
  if (!submissions.length) {
    list.innerHTML = '<div class="empty-state">No pending submissions. You are all caught up.</div>';
    return;
  }
  list.innerHTML = submissions.map((s, i) => `
    <div class="card review-card fade-in-item" style="animation-delay:${i * 40}ms" data-id="${s._id}">
      <div class="submission-row" style="border:none;padding:0;margin-bottom:10px;">
        <div class="row-main">
          <div><strong>${escapeHtml(s.campaign?.title || 'Campaign')}</strong> · ${escapeHtml(platformLabel(s.platform))}
            <span class="faint">· ${escapeHtml(whoIs(s.creator))} · ${fmtDate(s.createdAt)}</span></div>
          <a class="video-url" href="${escapeHtml(s.videoUrl)}" target="_blank" rel="noopener">${escapeHtml(s.videoUrl)}</a>
        </div>
        <span class="badge badge-pending">pending</span>
      </div>
      <div class="submit-form-inline">
        <input type="number" min="0" step="1" inputmode="numeric" placeholder="Current view count" value="${s.views > 0 ? s.views : ''}" class="views-input" aria-label="Current view count">
        <button class="btn btn-primary approve-btn">Approve</button>
        <button class="btn btn-danger reject-btn">Reject</button>
      </div>
      <div class="submit-form-inline reject-row" hidden>
        <input type="text" maxlength="200" placeholder="Reason shown to the creator (optional)" class="reason-input" aria-label="Rejection reason">
        <button class="btn btn-danger confirm-reject-btn">Confirm rejection</button>
        <button class="btn btn-secondary cancel-reject-btn">Cancel</button>
      </div>
    </div>`).join('');

  const review = async (btn, body, label) => {
    const card = btn.closest('[data-id]');
    hideAlert(alertEl);
    setLoading(btn, true, label);
    try {
      await apiRequest('/submissions/approve', { method: 'POST', body: { submissionId: card.dataset.id, ...body(card) } });
      card.classList.add('fade-out-item');
      setTimeout(() => { card.remove(); if (!list.children.length) renderQueue([]); }, 200);
    } catch (err) {
      showAlert(alertEl, err.message);
      setLoading(btn, false);
    }
  };

  list.querySelectorAll('.approve-btn').forEach((btn) => btn.addEventListener('click', () => {
    const views = btn.closest('[data-id]').querySelector('.views-input').value;
    if (views === '' || !Number.isInteger(Number(views)) || Number(views) < 0) return showAlert(alertEl, 'Enter the current view count as a whole number (0 or more) before approving.');
    review(btn, (card) => ({ decision: 'approve', views: Number(card.querySelector('.views-input').value) }), 'Approving…');
  }));
  list.querySelectorAll('.reject-btn').forEach((btn) => btn.addEventListener('click', () => {
    const row = btn.closest('[data-id]').querySelector('.reject-row');
    row.hidden = false;
    row.querySelector('.reason-input').focus();
  }));
  list.querySelectorAll('.cancel-reject-btn').forEach((btn) => btn.addEventListener('click', () => { btn.closest('.reject-row').hidden = true; }));
  list.querySelectorAll('.confirm-reject-btn').forEach((btn) => btn.addEventListener('click', () => {
    review(btn, (card) => ({ decision: 'reject', rejectionReason: card.querySelector('.reason-input').value.trim() }), 'Rejecting…');
  }));
}
