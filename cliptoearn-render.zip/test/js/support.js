// js/support.js - the support page: open a ticket, see your tickets, read and answer a conversation.
(function () {
  const $ = (id) => document.getElementById(id);
  const alertEl = () => $('support-alert');
  let openId = null;

  async function loadTickets() {
    const list = $('ticket-list');
    list.innerHTML = loadingHtml('Loading your tickets…');
    try {
      const { tickets } = await apiRequest('/support');
      if (!tickets.length) { list.innerHTML = '<div class="empty-state">No tickets yet.</div>'; return; }
      list.innerHTML = tickets.map((t) => `<div class="ticket-item${openId === t._id ? ' active' : ''}" data-id="${t._id}">
        <div><div class="t-subject">${escapeHtml(t.subject)}</div><div class="t-meta">${escapeHtml(t.category)} · ${fmtDate(t.updatedAt)}</div></div>
        <span class="badge badge-${['resolved', 'closed'].includes(t.status) ? 'approved' : 'pending'}">${escapeHtml(t.status.replace('_', ' '))}</span></div>`).join('');
      list.querySelectorAll('.ticket-item').forEach((el) => el.addEventListener('click', () => showTicket(el.dataset.id)));
    } catch (err) { showState(list, err, loadTickets); }
  }

  async function showTicket(id) {
    try {
      const { ticket } = await apiRequest(`/support?id=${encodeURIComponent(id)}`);
      openId = ticket._id;
      $('thread-panel').style.display = '';
      $('thread-subject').textContent = ticket.subject;
      $('thread-messages').innerHTML = ticket.messages.map((m) =>
        `<div class="msg ${m.sender === 'user' ? 'mine' : ''}">${escapeHtml(m.body)}<small>${m.sender === 'user' ? 'You' : 'Support'} · ${fmtDate(m.createdAt)}</small></div>`).join('');
      $('reply-form').hidden = ticket.status === 'closed';
      document.querySelectorAll('#ticket-list .ticket-item').forEach((el) => el.classList.toggle('active', el.dataset.id === id));
    } catch (err) { showAlert(alertEl(), err.message); }
  }

  document.addEventListener('DOMContentLoaded', async () => {
    const user = await requireLogin();
    if (!user) return;
    loadTickets();

    $('new-ticket-form').addEventListener('submit', async (e) => {
      e.preventDefault();
      const btn = e.target.querySelector('button[type="submit"]');
      hideAlert(alertEl());
      setLoading(btn, true, 'Submitting…');
      try {
        const { ticket } = await apiRequest('/support', { method: 'POST', body: {
          subject: $('ticket-subject').value.trim(), category: $('ticket-category').value, message: $('ticket-message').value.trim() } });
        e.target.reset();
        showAlert(alertEl(), 'Ticket submitted. We will reply here.', 'success');
        await loadTickets();
        showTicket(ticket._id);
      } catch (err) { showAlert(alertEl(), err.message); }
      finally { setLoading(btn, false); }
    });

    $('reply-form').addEventListener('submit', async (e) => {
      e.preventDefault();
      const btn = e.target.querySelector('button[type="submit"]');
      const message = $('reply-message').value.trim();
      if (!message || !openId) return;
      hideAlert(alertEl());
      setLoading(btn, true, 'Sending…');
      try { await apiRequest('/support', { method: 'POST', body: { ticketId: openId, message } }); $('reply-message').value = ''; await showTicket(openId); loadTickets(); }
      catch (err) { showAlert(alertEl(), err.message); }
      finally { setLoading(btn, false); }
    });
  });
})();
