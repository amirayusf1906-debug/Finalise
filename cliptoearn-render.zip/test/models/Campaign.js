// models/Campaign.js
const mongoose = require('mongoose');

const isInt = { validator: Number.isSafeInteger, message: '{PATH} must be a whole number of cents' };

const CampaignSchema = new mongoose.Schema(
  {
    title: { type: String, required: true, trim: true, maxlength: 120 },
    description: { type: String, default: '', maxlength: 2000 },
    campaignBrief: { type: String, default: '', maxlength: 5000 },
    materialsUrl: { type: String, default: '', maxlength: 1000 },
    instructions: { type: String, default: '', maxlength: 5000 },
    brandName: { type: String, default: '', maxlength: 80 },
    // Views-based rate (older campaigns). Campaigns created by brands pay a flat rewardPerCreator instead.
    payoutPerThousandViews: { type: Number, required: function () { return !this.rewardPerCreator; }, min: 1, max: 100000, validate: isInt }, // cents per 1000 views
    rewardPerCreator: { type: Number, default: 0, min: 0, max: 100000000, validate: isInt }, // cents, paid once per approved creator
    brand: { type: mongoose.Schema.Types.ObjectId, ref: 'User', index: true },
    // Money rule: creators are only paid from money that was CONFIRMED paid by the brand.
    // budgetTotal = what the brand asked to spend; fundedAmount = what NOWPayments confirmed;
    // budgetSpent = rewards already credited. Remaining budget = fundedAmount - budgetSpent.
    fundedAmount: { type: Number, default: 0, min: 0, validate: isInt },
    fundingStatus: { type: String, enum: ['unfunded', 'pending', 'funded', 'failed', 'refund_owed', 'refunded'], default: 'unfunded' },
    refundOwed: { type: Number, default: 0, min: 0, validate: isInt }, // unused funded cents owed back to the brand after a cancellation
    refundedAmount: { type: Number, default: 0, min: 0, validate: isInt },
    deadline: { type: Date },
    budgetTotal: { type: Number, required: true, min: 100, max: 1000000000, validate: isInt }, // cents
    budgetSpent: { type: Number, default: 0, min: 0, validate: isInt },
    platforms: {
      type: [{ type: String, enum: ['tiktok', 'instagram', 'youtube'] }],
      validate: { validator: (v) => Array.isArray(v) && v.length > 0, message: 'Select at least one platform' },
    },
    requirements: { type: String, default: '', maxlength: 2000 }, // hashtags, sound, mentions, etc
    targeting: {
      minFollowers: { type: Number, default: 0, min: 0, max: 1000000000 },
      requireVerified: { type: Boolean, default: false },
    },
    status: { type: String, enum: ['draft', 'active', 'paused', 'completed', 'cancelled'], default: 'active' },
    createdBy: { type: mongoose.Schema.Types.ObjectId, ref: 'User' },
    participants: [{ type: mongoose.Schema.Types.ObjectId, ref: 'User' }],
  },
  { timestamps: true }
);

module.exports = mongoose.models.Campaign || mongoose.model('Campaign', CampaignSchema);
