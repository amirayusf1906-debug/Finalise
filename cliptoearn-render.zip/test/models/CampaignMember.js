// models/CampaignMember.js - one row per creator per campaign they joined (the unique index stops double joins).
const mongoose = require('mongoose');

const CampaignMemberSchema = new mongoose.Schema(
  {
    campaign: { type: mongoose.Schema.Types.ObjectId, ref: 'Campaign', required: true },
    user: { type: mongoose.Schema.Types.ObjectId, ref: 'User', required: true },
  },
  { timestamps: true }
);
CampaignMemberSchema.index({ campaign: 1, user: 1 }, { unique: true });
CampaignMemberSchema.index({ user: 1 });

module.exports = mongoose.models.CampaignMember || mongoose.model('CampaignMember', CampaignMemberSchema);
