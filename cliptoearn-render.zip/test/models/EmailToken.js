// models/EmailToken.js - one-time links for email verification and password reset.
// Only the SHA-256 hash of the token is stored, so a database leak does not expose usable links.
// MongoDB deletes expired rows by itself (TTL index).
const mongoose = require('mongoose');

const EmailTokenSchema = new mongoose.Schema({
  user: { type: mongoose.Schema.Types.ObjectId, ref: 'User', required: true, index: true },
  type: { type: String, enum: ['verify', 'reset'], required: true },
  tokenHash: { type: String, required: true, unique: true },
  email: { type: String, required: true }, // the address the link was sent to; a verify link only counts for that address
  expiresAt: { type: Date, required: true },
  usedAt: { type: Date },
});
EmailTokenSchema.index({ expiresAt: 1 }, { expireAfterSeconds: 0 });

module.exports = mongoose.models.EmailToken || mongoose.model('EmailToken', EmailTokenSchema);
