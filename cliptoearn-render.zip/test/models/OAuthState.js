// models/OAuthState.js - short-lived "state" values for OAuth redirects (MongoDB deletes them after they expire).
const mongoose = require('mongoose');

const OAuthStateSchema = new mongoose.Schema({
  state: { type: String, required: true, unique: true },
  user: { type: mongoose.Schema.Types.ObjectId, ref: 'User', required: true },
  platform: { type: String, required: true },
  expiresAt: { type: Date, required: true },
});
OAuthStateSchema.index({ expiresAt: 1 }, { expireAfterSeconds: 0 });

module.exports = mongoose.models.OAuthState || mongoose.model('OAuthState', OAuthStateSchema);
