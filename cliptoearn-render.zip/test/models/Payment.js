// models/Payment.js
// A payment attempt with a provider (a brand paying to fund a campaign) or an owed refund.
// This record moves through states; the permanent, unchangeable record of the money is the
// Transaction row written when the payment is confirmed.
const mongoose = require('mongoose');

const PaymentSchema = new mongoose.Schema(
  {
    user: { type: mongoose.Schema.Types.ObjectId, ref: 'User', required: true, index: true }, // the brand
    campaign: { type: mongoose.Schema.Types.ObjectId, ref: 'Campaign', index: true },
    type: { type: String, enum: ['campaign_funding', 'campaign_refund', 'brand_deposit'], required: true },
    provider: { type: String, default: 'nowpayments' },
    providerInvoiceId: { type: String },
    providerPaymentId: { type: String }, // NOWPayments payment_id, set by the webhook
    providerPaymentStatus: { type: String, default: '' }, // raw status from the provider
    invoiceUrl: { type: String, default: '' },
    amount: { type: Number, required: true }, // cents (USD). Funding: the TOTAL the brand pays (creatorBudget + platformFee)
    creatorBudget: { type: Number }, // cents, funding only: the creator budget that is credited to the campaign
    platformFee: { type: Number }, // cents, funding only: platform fee (calculated by lib/fees.js), never added to the campaign budget
    currency: { type: String, default: 'USD' },
    // funding: created -> pending -> funded | failed | expired | partially_paid | refunded ; refund: owed -> completed
    status: { type: String, enum: ['created', 'pending', 'funded', 'failed', 'expired', 'partially_paid', 'refunded', 'cancelled', 'owed', 'completed'], default: 'created' },
    settled: { type: Boolean, default: false }, // true once the money was credited to the campaign (guards double-crediting)
    reference: { type: String, default: '' }, // refund: the transaction id / note of how the brand was repaid
    needsReview: { type: Boolean, default: false },
    events: { type: [{ status: String, providerPaymentId: String, at: Date, _id: false }], default: [] },
    metadata: { type: mongoose.Schema.Types.Mixed },
  },
  { timestamps: true }
);

PaymentSchema.index({ providerPaymentId: 1 }, { unique: true, partialFilterExpression: { providerPaymentId: { $type: 'string' } } });
// One live funding attempt per campaign (failed/expired attempts do not block a new one).
PaymentSchema.index({ campaign: 1, type: 1 }, { unique: true, partialFilterExpression: { type: 'campaign_funding', status: { $in: ['created', 'pending', 'partially_paid', 'funded'] } } });

module.exports = mongoose.models.Payment || mongoose.model('Payment', PaymentSchema);
