// models/RateLimit.js - counters for lib/rateLimit.js. MongoDB removes old rows by itself (TTL index).
const mongoose = require('mongoose');

const RateLimitSchema = new mongoose.Schema({
  key: { type: String, required: true, unique: true },
  count: { type: Number, default: 0 },
  expiresAt: { type: Date, required: true },
});
RateLimitSchema.index({ expiresAt: 1 }, { expireAfterSeconds: 0 });

module.exports = mongoose.models.RateLimit || mongoose.model('RateLimit', RateLimitSchema);
