// models/SocialAccount.js
const mongoose = require('mongoose');

const SocialAccountSchema = new mongoose.Schema(
  {
    user: { type: mongoose.Schema.Types.ObjectId, ref: 'User', required: true },
    platform: { type: String, enum: ['tiktok', 'instagram', 'youtube'], required: true },
    handle: { type: String, required: true, trim: true },
    displayName: { type: String, default: '', maxlength: 120 },
    profileUrl: { type: String, default: '' },
    followerCount: { type: Number, default: 0 },
    followingCount: { type: Number, default: 0 },
    totalLikes: { type: Number, default: 0 },
    videoCount: { type: Number, default: 0 },
    tiktokVerified: { type: Boolean, default: false },
    privateAccount: { type: Boolean, default: false },
    profileSnapshotAt: { type: Date },
    verified: { type: Boolean, default: false },
    connectedAt: { type: Date, default: Date.now },

    // "Verified through bio" (no OAuth). Accounts connected through OAuth leave these empty.
    handleKey: { type: String, default: '', select: false }, // lowercase handle, used for the one-account rule
    verificationMethod: { type: String, enum: ['oauth', 'bio'] },
    verificationStatus: { type: String, enum: ['pending', 'verified', 'failed'] },
    verificationNonce: { type: String, select: false }, // the code is derived from this, never stored
    verificationExpiresAt: { type: Date },
    verificationAttempts: { type: Number, default: 0 },
    verificationMessage: { type: String, default: '' },
    lastCheckedAt: { type: Date },
    verifiedAt: { type: Date },
    statsCheckedAt: { type: Date }, // last successful follower-count refresh
    statsAttemptedAt: { type: Date }, // last try (so unreachable accounts do not starve the queue)

    // The platform's own ID for this account. Used to detect if the same
    // real-world account gets connected under a different Claude user
    // (enforced by the unique index below).
    platformUserId: { type: String, default: '', select: false },

    // OAuth credentials. `select: false` so they're never returned unless a
    // query explicitly asks for them (`.select('+accessToken')`) - the
    // regular GET /api/socials list never needs them.
    accessToken: { type: String, select: false },
    refreshToken: { type: String, select: false },
    tokenExpiresAt: { type: Date, select: false },
  },
  { timestamps: true }
);

// One connection per platform per user
SocialAccountSchema.index({ user: 1, platform: 1 }, { unique: true });

// One ClipToEarn user per real platform account. The database enforces this, so two people
// connecting the same TikTok account at once cannot both succeed. Partial, so accounts
// without a platform ID (none should exist) are not affected.
SocialAccountSchema.index(
  { platform: 1, platformUserId: 1 },
  { unique: true, partialFilterExpression: { platformUserId: { $gt: '' } } }
);

// A handle can be claimed by several people while pending, but only one can ever be VERIFIED.
SocialAccountSchema.index(
  { platform: 1, handleKey: 1 },
  { unique: true, partialFilterExpression: { verified: true, handleKey: { $gt: '' } } }
);

module.exports =
  mongoose.models.SocialAccount || mongoose.model('SocialAccount', SocialAccountSchema);
