// models/Submission.js
const mongoose = require('mongoose');

const SubmissionSchema = new mongoose.Schema(
  {
    campaign: { type: mongoose.Schema.Types.ObjectId, ref: 'Campaign', required: true },
    creator: { type: mongoose.Schema.Types.ObjectId, ref: 'User', required: true },
    platform: { type: String, enum: ['tiktok', 'instagram', 'youtube'], required: true },
    videoUrl: { type: String, required: true },
    videoUrlHash: { type: String, required: true, index: true }, // sha256 of normalized URL
    views: { type: Number, default: 0 },
    likes: { type: Number, default: 0 },
    comments: { type: Number, default: 0 },
    shares: { type: Number, default: 0 },
    description: { type: String, default: '' },
    tiktokUsername: { type: String, default: '' },
    tiktokVideoId: { type: String, default: '', index: true },
    videoCheckedAt: { type: Date },
    reversalReason: { type: String, default: '' },
    unavailableSince: { type: Date }, // set by the refresh job when an approved video can no longer be found
    viewsCheckedAt: { type: Date }, // last successful automatic view refresh
    viewsAttemptedAt: { type: Date },
    status: { type: String, enum: ['pending', 'approved', 'rejected', 'reversed'], default: 'pending' },
    paymentStatus: { type: String, enum: ['not_eligible', 'pending', 'processing', 'paid', 'failed'], default: 'not_eligible' },
    paidAt: { type: Date },
    paymentFailureReason: { type: String, default: '' },
    rejectionReason: { type: String, default: '' },
    payoutAmount: { type: Number, default: 0 }, // cents, set on approval
    reviewedBy: { type: mongoose.Schema.Types.ObjectId, ref: 'User' },
    reviewedAt: { type: Date },
  },
  { timestamps: true }
);

// A creator cannot submit the exact same normalized video URL twice to the same campaign.
SubmissionSchema.index({ campaign: 1, videoUrlHash: 1 }, { unique: true });

module.exports = mongoose.models.Submission || mongoose.model('Submission', SubmissionSchema);
