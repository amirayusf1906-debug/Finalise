// models/Transaction.js
// The money ledger. Every balance change (creator balances) and every confirmed campaign payment
// or refund (brand side) is ONE row here. Rows are append-only: they can never be edited or
// deleted through the app (see the hooks at the bottom). A mistake is fixed by adding a new row
// that points back at the old one (relatedTransaction), never by changing history.
//
// Creator balance = sum of `amount` over that creator's rows (scripts/reconcile-ledger.js checks it).
const mongoose = require('mongoose');

const TYPES = [
  // older types, kept so existing history stays valid
  'earning', 'withdrawal', 'refund', 'adjustment',
  // withdrawal fee, written next to the 'withdrawal' row (net payout + fee = gross deducted)
  'withdrawal_fee',
  // payment system
  'campaign_funding', 'campaign_funding_refund', 'campaign_reward', 'campaign_reward_pending', 'reward_reversal', 'brand_deposit',
];

const TransactionSchema = new mongoose.Schema(
  {
    user: { type: mongoose.Schema.Types.ObjectId, ref: 'User', required: true, index: true }, // creator, or the brand for funding rows
    type: { type: String, enum: TYPES, required: true },
    amount: { type: Number, required: true }, // cents. Creator rows: + credit / - debit. Funding: + paid in. Funding refund: - paid back.
    currency: { type: String, default: 'USD' },
    balanceAfter: { type: Number }, // creator balance snapshot (not used for brand rows)
    description: { type: String, default: '' },
    status: { type: String, enum: ['confirmed'], default: 'confirmed' }, // rows are only written once final
    provider: { type: String, default: 'internal' }, // 'internal' | 'nowpayments' | 'manual'
    providerTransactionId: { type: String },
    relatedTransaction: { type: mongoose.Schema.Types.ObjectId, ref: 'Transaction' },
    rewardKey: { type: String }, // "campaign:creator" for flat rewards: one reward per creator per campaign
    metadata: { type: mongoose.Schema.Types.Mixed },
    submission: { type: mongoose.Schema.Types.ObjectId, ref: 'Submission' },
    campaign: { type: mongoose.Schema.Types.ObjectId, ref: 'Campaign', index: true },
    withdrawal: { type: mongoose.Schema.Types.ObjectId, ref: 'Withdrawal' },
  },
  { timestamps: true }
);

TransactionSchema.index({ user: 1, createdAt: -1 });
// The same provider payment can never produce two ledger rows (duplicate webhooks).
TransactionSchema.index({ provider: 1, providerTransactionId: 1, type: 1 }, { unique: true, partialFilterExpression: { providerTransactionId: { $type: 'string' } } });
// A creator gets a flat campaign reward once.
TransactionSchema.index({ rewardKey: 1 }, { unique: true, partialFilterExpression: { rewardKey: { $type: 'string' } } });
// A reward can be reversed once.
TransactionSchema.index({ relatedTransaction: 1, type: 1 }, { unique: true, partialFilterExpression: { type: 'reward_reversal' } });

// Append-only: block every way of changing or removing a row.
const BLOCKED = ['updateOne', 'updateMany', 'findOneAndUpdate', 'findOneAndReplace', 'replaceOne', 'deleteOne', 'deleteMany', 'findOneAndDelete', 'findOneAndRemove'];
BLOCKED.forEach((op) => TransactionSchema.pre(op, function () { throw new Error('Ledger rows cannot be changed or deleted. Add a new row instead.'); }));
TransactionSchema.pre('save', function () { if (!this.isNew) throw new Error('Ledger rows cannot be changed. Add a new row instead.'); });
TransactionSchema.pre('deleteOne', { document: true, query: false }, function () { throw new Error('Ledger rows cannot be deleted.'); });

module.exports = mongoose.models.Transaction || mongoose.model('Transaction', TransactionSchema);
module.exports.TYPES = TYPES;
