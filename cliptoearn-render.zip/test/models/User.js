// models/User.js
const mongoose = require('mongoose');

const UserSchema = new mongoose.Schema(
  {
    username: { type: String, required: true, unique: true, trim: true, lowercase: true },
    email: { type: String, required: true, unique: true, trim: true, lowercase: true },
    passwordHash: { type: String, required: true },
    role: { type: String, enum: ['creator', 'brand', 'admin'], default: 'creator' },
    brandProfile: {
      companyName: { type: String, trim: true, maxlength: 100 },
      contactName: { type: String, trim: true, maxlength: 80 },
      businessEmail: { type: String, trim: true, lowercase: true, maxlength: 120 },
      country: { type: String, trim: true, maxlength: 60 },
      website: { type: String, trim: true, maxlength: 200 },
      status: { type: String, enum: ['active', 'suspended'], default: 'active' },
    },
    displayName: { type: String, default: '' },
    avatarUrl: { type: String, default: '' },
    balance: { type: Number, default: 0 }, // creator available balance, cents
    pendingEarnings: { type: Number, default: 0 }, // approved creator earnings awaiting payment, cents
    totalEarned: { type: Number, default: 0 }, // creator earnings that have actually been paid, cents
    brandBalance: { type: Number, default: 0 }, // brand deposit balance, cents
    status: { type: String, enum: ['active', 'suspended'], default: 'active' },
    // Proof the person accepted the legal documents at sign-up (versions live in lib/legal.js)
    consent: {
      termsVersion: String,
      termsAcceptedAt: Date,
      privacyVersion: String,
      privacyAcceptedAt: Date,
    },
    emailVerified: { type: Boolean, default: false }, // required before withdrawing or funding a campaign
    emailVerifiedAt: { type: Date },
    passwordChangedAt: { type: Date }, // logins issued before this moment stop working
  },
  { timestamps: true }
);

module.exports = mongoose.models.User || mongoose.model('User', UserSchema);
