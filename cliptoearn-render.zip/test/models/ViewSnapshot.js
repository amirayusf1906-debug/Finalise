const mongoose = require('mongoose');

const ViewSnapshotSchema = new mongoose.Schema(
  {
    submission: { type: mongoose.Schema.Types.ObjectId, ref: 'Submission', required: true },
    creator: { type: mongoose.Schema.Types.ObjectId, ref: 'User', required: true, index: true },
    dateKey: { type: String, required: true }, // UTC YYYY-MM-DD
    views: { type: Number, required: true, min: 0 },
    capturedAt: { type: Date, default: Date.now },
  },
  { timestamps: true }
);

ViewSnapshotSchema.index({ submission: 1, dateKey: 1 }, { unique: true });
ViewSnapshotSchema.index({ creator: 1, dateKey: 1 });

module.exports = mongoose.models.ViewSnapshot || mongoose.model('ViewSnapshot', ViewSnapshotSchema);
