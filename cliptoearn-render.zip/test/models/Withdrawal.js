// models/Withdrawal.js
// A creator's request to cash out their balance.
const mongoose = require('mongoose');

const WithdrawalSchema = new mongoose.Schema(
  {
    user: { type: mongoose.Schema.Types.ObjectId, ref: 'User', required: true, index: true },
    amount: { type: Number, required: true }, // cents, GROSS amount deducted from the creator's balance
    feeAmount: { type: Number }, // cents, withdrawal fee (calculated by lib/fees.js)
    netAmount: { type: Number }, // cents, amount actually paid out (gross - fee). Old records have no value: they were paid in full
    method: {
      type: String,
      enum: ['paypal', 'bank_transfer', 'crypto'], // bank_transfer is only kept for old records
      required: true,
    },
    destination: { type: String, required: true }, // paypal email, IBAN, wallet address, etc
    // Crypto payouts (NOWPayments). The exact network is stored so money never goes to the wrong chain.
    cryptoCurrency: { type: String, enum: ['USDT', 'BNB', 'ETH', 'BTC'] },
    network: { type: String },
    payoutCurrencyCode: { type: String }, // provider currency code, e.g. usdttrc20
    cryptoAmount: { type: String }, // amount sent in the crypto currency (string keeps exact decimals)
    provider: { type: String, enum: ['manual', 'nowpayments'], default: 'manual' }, // paypal payouts are sent by an admin
    providerBatchId: { type: String },
    providerPayoutId: { type: String },
    providerStatus: { type: String, default: '' },
    awaiting2fa: { type: Boolean, default: false }, // NOWPayments needs a 2FA code before it sends
    needsReview: { type: Boolean, default: false }, // payout request outcome unknown: check the provider dashboard
    payoutRequestedAt: { type: Date }, // set once, atomically, right before asking the provider to pay (blocks duplicates)
    clientRequestId: { type: String }, // sent by the form: a double-click or retry cannot create two withdrawals
    status: {
      type: String,
      enum: ['pending', 'processing', 'completed', 'failed', 'cancelled'],
      default: 'pending',
    },
    failureReason: { type: String, default: '' },
    processedBy: { type: mongoose.Schema.Types.ObjectId, ref: 'User' },
    processedAt: { type: Date },
  },
  { timestamps: true }
);

WithdrawalSchema.index({ user: 1, clientRequestId: 1 }, { unique: true, partialFilterExpression: { clientRequestId: { $type: 'string' } } });
WithdrawalSchema.index({ providerPayoutId: 1 }, { sparse: true });
WithdrawalSchema.index({ providerBatchId: 1 }, { sparse: true });

module.exports = mongoose.models.Withdrawal || mongoose.model('Withdrawal', WithdrawalSchema);
