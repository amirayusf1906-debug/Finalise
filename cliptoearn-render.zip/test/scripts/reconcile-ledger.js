// scripts/reconcile-ledger.js - read-only money check. Run: npm run reconcile
// 1. every creator's balance must equal the sum of their ledger rows
// 2. every campaign's spent amount must equal its reward rows, and never exceed the money funded
// Any line printed under MISMATCH means something changed money without writing a ledger row.
const mongoose = require('mongoose');
const User = require('../models/User');
const Campaign = require('../models/Campaign');
const Transaction = require('../models/Transaction');

const CREATOR = ['earning', 'withdrawal', 'withdrawal_fee', 'refund', 'adjustment', 'campaign_reward', 'reward_reversal'];
(async () => {
  if (!process.env.MONGO_URI) throw new Error('Set MONGO_URI first');
  await mongoose.connect(process.env.MONGO_URI);
  let bad = 0;
  const sums = new Map((await Transaction.aggregate([{ $match: { type: { $in: CREATOR } } }, { $group: { _id: '$user', s: { $sum: '$amount' } } }])).map((r) => [String(r._id), r.s]));
  for (const u of await User.find({ role: 'creator' }).select('username balance').lean()) {
    const l = sums.get(String(u._id)) || 0;
    if (l !== (u.balance || 0)) { bad++; console.log(`MISMATCH creator @${u.username}: balance ${u.balance || 0} vs ledger ${l} (cents)`); }
  }
  const spent = new Map((await Transaction.aggregate([{ $match: { type: { $in: ['campaign_reward', 'reward_reversal', 'earning'] }, campaign: { $ne: null } } }, { $group: { _id: '$campaign', s: { $sum: '$amount' } } }])).map((r) => [String(r._id), r.s]));
  for (const c of await Campaign.find({}).select('title budgetSpent fundedAmount').lean()) {
    const l = spent.get(String(c._id)) || 0;
    if (l !== c.budgetSpent) { bad++; console.log(`MISMATCH campaign "${c.title}": spent ${c.budgetSpent} vs ledger ${l}`); }
    if (c.budgetSpent > (c.fundedAmount || 0)) { bad++; console.log(`OVERSPENT campaign "${c.title}": spent ${c.budgetSpent} > funded ${c.fundedAmount || 0}`); }
  }
  console.log(bad ? `${bad} problem(s) found.` : 'Ledger is consistent.');
  await mongoose.disconnect();
  process.exit(bad ? 1 : 0);
})().catch((e) => { console.error(e); process.exit(1); });
