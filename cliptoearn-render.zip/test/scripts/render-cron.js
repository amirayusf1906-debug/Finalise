// Render Cron adapter for the existing protected jobs.
const action = process.argv[2];
const handler = action === 'refresh'
  ? require('../lib/handlers/socialsRefresh')
  : action === 'weekly'
    ? require('../api/reports/weekly')
    : null;

if (!handler) {
  console.error('Usage: node scripts/render-cron.js refresh|weekly');
  process.exit(2);
}

const req = {
  method: 'GET',
  headers: { authorization: `Bearer ${process.env.CRON_SECRET || ''}` },
  query: {},
};

const res = {
  statusCode: 200,
  headersSent: false,
  status(code) { this.statusCode = code; return this; },
  setHeader() {},
  json(body) {
    console.log(JSON.stringify(body));
    process.exit(this.statusCode >= 400 ? 1 : 0);
  },
};

handler(req, res).catch((err) => {
  console.error(err);
  process.exit(1);
});
