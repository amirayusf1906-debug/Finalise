// scripts/sync-indexes.js
// Run once after deploying (and after pulling schema changes): npm run sync-indexes
// Builds the unique indexes that protect the data (one join per creator + campaign, one creator per
// social account, one submission per video). If an index cannot be built because duplicate rows
// already exist, the script prints the error: clean up those rows and run it again.
const mongoose = require('mongoose');
const models = ['User', 'Campaign', 'CampaignMember', 'Submission', 'SocialAccount', 'Transaction', 'Payment', 'Withdrawal', 'SupportTicket', 'OAuthState', 'RateLimit', 'EmailToken', 'ViewSnapshot', 'Notification']
  .map((n) => require(`../models/${n}`));

(async () => {
  if (!process.env.MONGO_URI) throw new Error('Set MONGO_URI first');
  await mongoose.connect(process.env.MONGO_URI);
  for (const m of models) {
    try {
      await m.syncIndexes();
      console.log(`ok      ${m.modelName}`);
    } catch (err) {
      console.error(`FAILED  ${m.modelName}: ${err.message}`);
      process.exitCode = 1;
    }
  }
  // Creators who joined before CampaignMember existed
  const Campaign = require('../models/Campaign');
  const CampaignMember = require('../models/CampaignMember');
  for await (const c of Campaign.find({}, 'participants').lean().cursor()) {
    for (const user of c.participants || []) {
      await CampaignMember.updateOne({ campaign: c._id, user }, { $setOnInsert: { campaign: c._id, user } }, { upsert: true });
    }
  }
  console.log('Existing participants copied to CampaignMember.');
  await mongoose.disconnect();
})().catch((e) => { console.error(e); process.exit(1); });
